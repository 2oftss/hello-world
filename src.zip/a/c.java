package a;

import android.content.Intent;
import android.os.Bundle;

public final class c
{
  public static Bundle a(Intent paramIntent)
  {
    return paramIntent.getBundleExtra("al_applink_data");
  }
  
  public static Bundle b(Intent paramIntent)
  {
    paramIntent = a(paramIntent);
    if (paramIntent == null) {
      return null;
    }
    return paramIntent.getBundle("extras");
  }
}


/* Location:              C:\adcap\Pad2\jd-gui-windows-1.4.0\classes-dex2jar.jar!\a\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */