package a;

import java.util.Locale;

public class e
{
  private final g a;
  
  public boolean a()
  {
    return this.a.a();
  }
  
  public String toString()
  {
    return String.format(Locale.US, "%s@%s[cancellationRequested=%s]", new Object[] { getClass().getName(), Integer.toHexString(hashCode()), Boolean.toString(this.a.a()) });
  }
}


/* Location:              C:\adcap\Pad2\jd-gui-windows-1.4.0\classes-dex2jar.jar!\a\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */