package a;

import java.io.Closeable;

public class f
  implements Closeable
{
  private final Object a;
  private g b;
  private Runnable c;
  private boolean d;
  
  public void close()
  {
    synchronized (this.a)
    {
      if (this.d) {
        return;
      }
      this.d = true;
      this.b.a(this);
      this.b = null;
      this.c = null;
      return;
    }
  }
}


/* Location:              C:\adcap\Pad2\jd-gui-windows-1.4.0\classes-dex2jar.jar!\a\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */