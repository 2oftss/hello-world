package a;

public abstract interface h<TTaskResult, TContinuationResult>
{
  public abstract TContinuationResult then(j<TTaskResult> paramj);
}


/* Location:              C:\adcap\Pad2\jd-gui-windows-1.4.0\classes-dex2jar.jar!\a\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */