package a;

public class i
  extends RuntimeException
{
  public i(Exception paramException)
  {
    super("An exception was thrown by an Executor", paramException);
  }
}


/* Location:              C:\adcap\Pad2\jd-gui-windows-1.4.0\classes-dex2jar.jar!\a\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */