package a;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CancellationException;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;

public class j<TResult>
{
  public static final ExecutorService a = ;
  public static final Executor b = a.b();
  private static final Executor c = d.b();
  private static volatile b d;
  private static j<?> m = new j(null);
  private static j<Boolean> n = new j(Boolean.valueOf(true));
  private static j<Boolean> o = new j(Boolean.valueOf(false));
  private static j<?> p = new j(true);
  private final Object e = new Object();
  private boolean f;
  private boolean g;
  private TResult h;
  private Exception i;
  private boolean j;
  private l k;
  private List<h<TResult, Void>> l = new ArrayList();
  
  j() {}
  
  private j(TResult paramTResult)
  {
    b(paramTResult);
  }
  
  private j(boolean paramBoolean)
  {
    if (paramBoolean)
    {
      i();
      return;
    }
    b(null);
  }
  
  public static b a()
  {
    return d;
  }
  
  public static <TResult> j<TResult> a(Exception paramException)
  {
    k localk = new k();
    localk.b(paramException);
    return localk.a();
  }
  
  public static <TResult> j<TResult> a(TResult paramTResult)
  {
    if (paramTResult == null) {
      return m;
    }
    if ((paramTResult instanceof Boolean))
    {
      if (((Boolean)paramTResult).booleanValue()) {
        return n;
      }
      return o;
    }
    k localk = new k();
    localk.b(paramTResult);
    return localk.a();
  }
  
  public static <TResult> j<TResult>.a b()
  {
    j localj = new j();
    localj.getClass();
    return new a();
  }
  
  private static <TContinuationResult, TResult> void c(final k<TContinuationResult> paramk, final h<TResult, TContinuationResult> paramh, final j<TResult> paramj, Executor paramExecutor, e parame)
  {
    try
    {
      paramExecutor.execute(new Runnable()
      {
        public void run()
        {
          if ((this.a != null) && (this.a.a()))
          {
            paramk.c();
            return;
          }
          try
          {
            Object localObject = paramh.then(paramj);
            paramk.b(localObject);
            return;
          }
          catch (CancellationException localCancellationException)
          {
            paramk.c();
            return;
          }
          catch (Exception localException)
          {
            paramk.b(localException);
          }
        }
      });
      return;
    }
    catch (Exception paramh)
    {
      paramk.b(new i(paramh));
    }
  }
  
  private static <TContinuationResult, TResult> void d(final k<TContinuationResult> paramk, final h<TResult, j<TContinuationResult>> paramh, final j<TResult> paramj, Executor paramExecutor, e parame)
  {
    try
    {
      paramExecutor.execute(new Runnable()
      {
        public void run()
        {
          if ((this.a != null) && (this.a.a()))
          {
            paramk.c();
            return;
          }
          try
          {
            j localj = (j)paramh.then(paramj);
            if (localj == null)
            {
              paramk.b(null);
              return;
            }
          }
          catch (CancellationException localCancellationException)
          {
            paramk.c();
            return;
            localCancellationException.a(new h()
            {
              public Void a(j<TContinuationResult> paramAnonymous2j)
              {
                if ((j.5.this.a != null) && (j.5.this.a.a()))
                {
                  j.5.this.b.c();
                  return null;
                }
                if (paramAnonymous2j.d())
                {
                  j.5.this.b.c();
                  return null;
                }
                if (paramAnonymous2j.e())
                {
                  j.5.this.b.b(paramAnonymous2j.g());
                  return null;
                }
                j.5.this.b.b(paramAnonymous2j.f());
                return null;
              }
            });
            return;
          }
          catch (Exception localException)
          {
            paramk.b(localException);
          }
        }
      });
      return;
    }
    catch (Exception paramh)
    {
      paramk.b(new i(paramh));
    }
  }
  
  public static <TResult> j<TResult> h()
  {
    return p;
  }
  
  private void j()
  {
    for (;;)
    {
      h localh;
      synchronized (this.e)
      {
        Iterator localIterator = this.l.iterator();
        if (!localIterator.hasNext()) {
          break;
        }
        localh = (h)localIterator.next();
      }
      try
      {
        localh.then(this);
      }
      catch (RuntimeException localRuntimeException)
      {
        throw localRuntimeException;
        localObject2 = finally;
        throw ((Throwable)localObject2);
      }
      catch (Exception localException)
      {
        throw new RuntimeException(localException);
      }
    }
    this.l = null;
  }
  
  public <TContinuationResult> j<TContinuationResult> a(h<TResult, TContinuationResult> paramh)
  {
    return a(paramh, c, null);
  }
  
  public <TContinuationResult> j<TContinuationResult> a(h<TResult, j<TContinuationResult>> paramh, Executor paramExecutor)
  {
    return b(paramh, paramExecutor, null);
  }
  
  public <TContinuationResult> j<TContinuationResult> a(final h<TResult, TContinuationResult> paramh, final Executor paramExecutor, final e parame)
  {
    final k localk = new k();
    synchronized (this.e)
    {
      boolean bool = c();
      if (!bool) {
        this.l.add(new h()
        {
          public Void a(j<TResult> paramAnonymousj)
          {
            j.a(localk, paramh, paramAnonymousj, paramExecutor, parame);
            return null;
          }
        });
      }
      if (bool) {
        c(localk, paramh, this, paramExecutor, parame);
      }
      return localk.a();
    }
  }
  
  public <TContinuationResult> j<TContinuationResult> b(h<TResult, TContinuationResult> paramh)
  {
    return c(paramh, c, null);
  }
  
  public <TContinuationResult> j<TContinuationResult> b(final h<TResult, j<TContinuationResult>> paramh, final Executor paramExecutor, final e parame)
  {
    final k localk = new k();
    synchronized (this.e)
    {
      boolean bool = c();
      if (!bool) {
        this.l.add(new h()
        {
          public Void a(j<TResult> paramAnonymousj)
          {
            j.b(localk, paramh, paramAnonymousj, paramExecutor, parame);
            return null;
          }
        });
      }
      if (bool) {
        d(localk, paramh, this, paramExecutor, parame);
      }
      return localk.a();
    }
  }
  
  boolean b(Exception paramException)
  {
    synchronized (this.e)
    {
      if (this.f) {
        return false;
      }
      this.f = true;
      this.i = paramException;
      this.j = false;
      this.e.notifyAll();
      j();
      if ((!this.j) && (a() != null)) {
        this.k = new l(this);
      }
      return true;
    }
  }
  
  boolean b(TResult paramTResult)
  {
    synchronized (this.e)
    {
      if (this.f) {
        return false;
      }
      this.f = true;
      this.h = paramTResult;
      this.e.notifyAll();
      j();
      return true;
    }
  }
  
  public <TContinuationResult> j<TContinuationResult> c(final h<TResult, TContinuationResult> paramh, Executor paramExecutor, final e parame)
  {
    a(new h()
    {
      public j<TContinuationResult> a(j<TResult> paramAnonymousj)
      {
        if ((parame != null) && (parame.a())) {
          return j.h();
        }
        if (paramAnonymousj.e()) {
          return j.a(paramAnonymousj.g());
        }
        if (paramAnonymousj.d()) {
          return j.h();
        }
        return paramAnonymousj.a(paramh);
      }
    }, paramExecutor);
  }
  
  public boolean c()
  {
    synchronized (this.e)
    {
      boolean bool = this.f;
      return bool;
    }
  }
  
  public boolean d()
  {
    synchronized (this.e)
    {
      boolean bool = this.g;
      return bool;
    }
  }
  
  public boolean e()
  {
    for (;;)
    {
      synchronized (this.e)
      {
        if (g() != null)
        {
          bool = true;
          return bool;
        }
      }
      boolean bool = false;
    }
  }
  
  public TResult f()
  {
    synchronized (this.e)
    {
      Object localObject2 = this.h;
      return (TResult)localObject2;
    }
  }
  
  public Exception g()
  {
    synchronized (this.e)
    {
      if (this.i != null)
      {
        this.j = true;
        if (this.k != null)
        {
          this.k.a();
          this.k = null;
        }
      }
      Exception localException = this.i;
      return localException;
    }
  }
  
  boolean i()
  {
    synchronized (this.e)
    {
      if (this.f) {
        return false;
      }
      this.f = true;
      this.g = true;
      this.e.notifyAll();
      j();
      return true;
    }
  }
  
  public class a
    extends k<TResult>
  {
    a() {}
  }
  
  public static abstract interface b
  {
    public abstract void a(j<?> paramj, m paramm);
  }
}


/* Location:              C:\adcap\Pad2\jd-gui-windows-1.4.0\classes-dex2jar.jar!\a\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */