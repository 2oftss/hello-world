package jp.gungho.a;

import android.content.Context;
import android.os.AsyncTask;
import com.google.android.gms.ads.identifier.AdvertisingIdClient;
import com.google.android.gms.ads.identifier.AdvertisingIdClient.Info;
import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import java.io.IOException;

public class a
{
  private static String a = "";
  private static int b = 1;
  private static boolean c = false;
  
  public static int a()
  {
    return b;
  }
  
  public static void a(Context paramContext)
  {
    new a(paramContext).execute(new Void[0]);
  }
  
  public static String b()
  {
    return a;
  }
  
  public static boolean c()
  {
    return c;
  }
  
  private static class a
    extends AsyncTask<Void, Void, Void>
  {
    private Context a;
    
    a(Context paramContext)
    {
      this.a = paramContext;
    }
    
    protected Void a(Void... paramVarArgs)
    {
      for (int i = 1;; i = 0)
      {
        try
        {
          paramVarArgs = AdvertisingIdClient.getAdvertisingIdInfo(this.a);
          a.a(paramVarArgs.getId());
          if (!paramVarArgs.isLimitAdTrackingEnabled()) {
            continue;
          }
          a.a(i);
          a.a(true);
        }
        catch (IOException paramVarArgs)
        {
          for (;;) {}
        }
        catch (GooglePlayServicesRepairableException paramVarArgs)
        {
          for (;;) {}
        }
        catch (GooglePlayServicesNotAvailableException paramVarArgs)
        {
          for (;;) {}
        }
        return null;
      }
    }
  }
}


/* Location:              C:\adcap\Pad2\jd-gui-windows-1.4.0\classes-dex2jar.jar!\jp\gungho\a\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */