package jp.gungho.a;

import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.content.res.AssetManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Handler;
import android.text.TextUtils;
import android.view.ViewGroup;
import com.google.android.exoplayer2.d;
import com.google.android.exoplayer2.e.a;
import com.google.android.exoplayer2.e.e;
import com.google.android.exoplayer2.f;
import com.google.android.exoplayer2.g.a.a;
import com.google.android.exoplayer2.g.g;
import com.google.android.exoplayer2.h.f.a;
import com.google.android.exoplayer2.h.l;
import com.google.android.exoplayer2.i.t;
import com.google.android.exoplayer2.q;
import com.google.android.exoplayer2.r;
import java.io.File;
import java.io.FileInputStream;

public class b
{
  private static com.google.android.exoplayer2.e.c p;
  private MediaPlayer a;
  private int b;
  private String c;
  private boolean d;
  private float e;
  private boolean f;
  private boolean g = false;
  private Handler h;
  private f.a i;
  private com.google.android.exoplayer2.ui.b j;
  private q k;
  private int l;
  private long m;
  private com.google.android.exoplayer2.g.c n;
  private final String o = "ExoPlayer";
  private Context q;
  
  public b()
  {
    this(true);
  }
  
  public b(boolean paramBoolean)
  {
    if ((paramBoolean) && (Build.VERSION.SDK_INT >= 16)) {
      this.g = true;
    }
  }
  
  private e a(Uri paramUri, String paramString)
  {
    if (TextUtils.isEmpty(paramString)) {}
    for (int i1 = t.b(paramUri);; i1 = t.g("." + paramString)) {
      switch (i1)
      {
      default: 
        throw new IllegalStateException("Unsupported type: " + i1);
      }
    }
    return new com.google.android.exoplayer2.e.b(paramUri, this.i, new com.google.android.exoplayer2.c.c(), this.h, null);
  }
  
  private void a(ViewGroup paramViewGroup)
  {
    n();
    this.i = new l(this.q, t.a(this.q, "AudioPlayer"));
    this.h = new Handler();
    this.j = new com.google.android.exoplayer2.ui.b(this.q);
    this.j.setUseController(false);
    b(paramViewGroup);
  }
  
  private void a(e parame, boolean paramBoolean)
  {
    Object localObject = parame;
    if (paramBoolean)
    {
      p = new com.google.android.exoplayer2.e.c(parame);
      localObject = p;
    }
    this.k.a(new e.a()
    {
      public void a() {}
      
      public void a(d paramAnonymousd)
      {
        b.a(b.this).c();
        b.a(b.this).a(b.j());
        b.a(b.this).a(true);
      }
      
      public void a(com.google.android.exoplayer2.e.j paramAnonymousj, g paramAnonymousg) {}
      
      public void a(r paramAnonymousr, Object paramAnonymousObject) {}
      
      public void a(boolean paramAnonymousBoolean) {}
      
      public void a(boolean paramAnonymousBoolean, int paramAnonymousInt) {}
    });
    if (this.l != -1) {}
    for (int i1 = 1;; i1 = 0)
    {
      if (i1 != 0) {
        this.k.a(this.l, this.m);
      }
      this.k.a((e)localObject);
      this.k.a(false);
      return;
    }
  }
  
  private void b(ViewGroup paramViewGroup)
  {
    paramViewGroup.addView(this.j, 0);
  }
  
  private void k()
  {
    if (this.k == null) {}
    for (int i1 = 1; i1 == 0; i1 = 0) {
      return;
    }
    this.n = new com.google.android.exoplayer2.g.c(new a.a(new com.google.android.exoplayer2.h.j()));
    com.google.android.exoplayer2.c localc = new com.google.android.exoplayer2.c();
    this.k = f.a(this.q, this.n, localc);
    this.j.setPlayer(this.k);
  }
  
  private void l()
  {
    if (this.k == null) {
      return;
    }
    m();
    this.k.d();
    this.k = null;
    this.n = null;
  }
  
  private void m()
  {
    this.l = this.k.g();
    this.m = this.k.i();
  }
  
  private void n()
  {
    this.l = -1;
    this.m = -9223372036854775807L;
  }
  
  public void a()
  {
    if (this.g) {
      k();
    }
  }
  
  public void a(float paramFloat)
  {
    if (this.g) {
      if (this.k != null)
      {
        this.k.a(paramFloat);
        this.e = paramFloat;
      }
    }
    while (this.a == null) {
      return;
    }
    this.a.setVolume(paramFloat, paramFloat);
    this.e = paramFloat;
  }
  
  public void a(Context paramContext, ViewGroup paramViewGroup)
  {
    this.q = paramContext;
    if (this.g) {
      a(paramViewGroup);
    }
  }
  
  public void a(String paramString, boolean paramBoolean1, float paramFloat, boolean paramBoolean2)
  {
    for (;;)
    {
      try
      {
        if (this.g)
        {
          if (this.k != null)
          {
            if (this.b != 4116)
            {
              if (this.b != 4115) {
                n();
              }
              this.k.c();
            }
            this.c = null;
            this.d = false;
            this.e = 0.0F;
          }
          if (this.k == null) {
            k();
          }
          this.b = 4113;
          this.c = paramString;
          this.d = paramBoolean1;
          this.e = paramFloat;
          this.f = paramBoolean2;
          if (!this.g) {
            break;
          }
          if (paramBoolean2)
          {
            this.q.getAssets();
            paramString = a(Uri.parse("asset:///" + paramString), null);
            a(paramString, paramBoolean1);
            this.k.a(paramFloat);
          }
        }
        else
        {
          if (this.a != null)
          {
            if (this.b != 4116)
            {
              this.a.stop();
              this.a.reset();
            }
            this.c = null;
            this.d = false;
            this.e = 0.0F;
          }
          if (this.a != null) {
            continue;
          }
          this.a = new MediaPlayer();
          continue;
        }
        paramString = a(Uri.fromFile(new File(paramString)), null);
      }
      catch (Exception paramString)
      {
        paramString.printStackTrace();
        return;
      }
    }
    if (paramBoolean2)
    {
      paramString = this.q.getAssets().openFd(paramString);
      this.a.setDataSource(paramString.getFileDescriptor(), paramString.getStartOffset(), paramString.getLength());
    }
    for (;;)
    {
      this.a.prepare();
      this.a.setLooping(paramBoolean1);
      this.a.setVolume(paramFloat, paramFloat);
      return;
      File localFile = new File(paramString);
      this.a.setDataSource(new FileInputStream(paramString).getFD(), 0L, localFile.length());
    }
  }
  
  public void a(boolean paramBoolean)
  {
    if ((this.b == 4115) || (this.b == 4113))
    {
      if (!paramBoolean) {
        break label172;
      }
      if (!this.g) {
        break label122;
      }
      if ((Build.VERSION.SDK_INT <= 23) || (this.k == null))
      {
        k();
        a(this.c, this.d, this.e, this.f);
        this.k.a(true);
        this.b = 4114;
      }
    }
    else
    {
      return;
    }
    a(this.c, this.d, this.e, this.f);
    this.k.a(true);
    this.b = 4114;
    return;
    label122:
    if (this.a == null)
    {
      a(this.c, this.d, this.e, this.f);
      this.b = 4115;
      return;
    }
    this.a.start();
    this.b = 4114;
    return;
    label172:
    if (this.g)
    {
      if ((Build.VERSION.SDK_INT <= 23) || (this.k == null)) {
        k();
      }
      a(this.c, this.d, this.e, this.f);
      this.k.a(false);
    }
    for (;;)
    {
      this.b = 4115;
      return;
      if (this.a == null) {
        a(this.c, this.d, this.e, this.f);
      }
    }
  }
  
  public void b()
  {
    l();
  }
  
  public void c()
  {
    if (this.g) {
      if (this.k != null)
      {
        m();
        this.k.a(false);
      }
    }
    for (;;)
    {
      this.b = 4112;
      return;
      if (this.a != null)
      {
        this.a.stop();
        this.a.release();
      }
      this.a = null;
    }
  }
  
  public int d()
  {
    int i2 = 0;
    int i1;
    if (this.g)
    {
      i1 = i2;
      if (this.k != null)
      {
        i1 = i2;
        if (this.b == 4114) {
          i1 = (int)this.k.i();
        }
      }
    }
    do
    {
      do
      {
        return i1;
        i1 = i2;
      } while (this.a == null);
      i1 = i2;
    } while (this.b != 4114);
    return this.a.getCurrentPosition();
  }
  
  public boolean e()
  {
    if (this.g)
    {
      if (this.k != null)
      {
        this.k.a(true);
        this.b = 4114;
        return true;
      }
    }
    else if (this.a != null)
    {
      this.a.start();
      boolean bool = this.a.isPlaying();
      this.b = 4114;
      return bool;
    }
    return false;
  }
  
  public boolean f()
  {
    boolean bool = true;
    if ((this.b == 4114) || (this.b == 4115))
    {
      if (!this.g) {
        break label59;
      }
      if (this.k != null)
      {
        m();
        this.k.a(false);
      }
    }
    for (;;)
    {
      this.b = 4116;
      bool = false;
      return bool;
      label59:
      if (this.a != null)
      {
        this.a.stop();
        this.a.reset();
      }
    }
  }
  
  public void g()
  {
    if (this.b == 4114)
    {
      if (!this.g) {
        break label44;
      }
      if (this.k != null)
      {
        m();
        this.k.a(false);
      }
    }
    for (;;)
    {
      this.b = 4115;
      return;
      label44:
      if (this.a != null) {
        this.a.pause();
      }
    }
  }
  
  public boolean h()
  {
    boolean bool2 = false;
    boolean bool1;
    if (this.g)
    {
      bool1 = bool2;
      if (this.k != null) {
        bool1 = this.k.b();
      }
    }
    do
    {
      do
      {
        return bool1;
        bool1 = bool2;
      } while (this.a == null);
      bool1 = bool2;
    } while (this.b != 4114);
    return true;
  }
  
  public boolean i()
  {
    if (this.g)
    {
      if (this.k == null) {}
    }
    else {
      while (this.a != null) {
        return true;
      }
    }
    return false;
  }
}


/* Location:              C:\adcap\Pad2\jd-gui-windows-1.4.0\classes-dex2jar.jar!\jp\gungho\a\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */