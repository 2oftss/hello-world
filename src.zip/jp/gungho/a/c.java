package jp.gungho.a;

public class c
  extends Exception
{
  e a;
  
  public c(int paramInt, String paramString)
  {
    this(new e(paramInt, paramString));
  }
  
  public c(int paramInt, String paramString, Exception paramException)
  {
    this(new e(paramInt, paramString), paramException);
  }
  
  public c(e parame)
  {
    this(parame, null);
  }
  
  public c(e parame, Exception paramException)
  {
    super(parame.b(), paramException);
    this.a = parame;
  }
  
  public e a()
  {
    return this.a;
  }
}


/* Location:              C:\adcap\Pad2\jd-gui-windows-1.4.0\classes-dex2jar.jar!\jp\gungho\a\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */