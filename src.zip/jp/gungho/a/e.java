package jp.gungho.a;

public class e
{
  int a;
  String b;
  
  public e(int paramInt, String paramString)
  {
    this.a = paramInt;
    if ((paramString == null) || (paramString.trim().length() == 0))
    {
      this.b = d.a(paramInt);
      return;
    }
    this.b = (paramString + " (response: " + d.a(paramInt) + ")");
  }
  
  public int a()
  {
    return this.a;
  }
  
  public String b()
  {
    return this.b;
  }
  
  public boolean c()
  {
    return this.a == 0;
  }
  
  public boolean d()
  {
    return !c();
  }
  
  public String toString()
  {
    return "IabResult: " + b();
  }
}


/* Location:              C:\adcap\Pad2\jd-gui-windows-1.4.0\classes-dex2jar.jar!\jp\gungho\a\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */