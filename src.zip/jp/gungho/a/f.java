package jp.gungho.a;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class f
{
  Map<String, i> a = new HashMap();
  Map<String, g> b = new HashMap();
  
  public List<i> a()
  {
    return new ArrayList(this.a.values());
  }
  
  List<String> a(String paramString)
  {
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator = this.b.values().iterator();
    while (localIterator.hasNext())
    {
      g localg = (g)localIterator.next();
      if (localg.a().equals(paramString)) {
        localArrayList.add(localg.b());
      }
    }
    return localArrayList;
  }
  
  void a(g paramg)
  {
    this.b.put(paramg.b(), paramg);
  }
  
  void a(i parami)
  {
    this.a.put(parami.a(), parami);
  }
  
  public List<g> b()
  {
    return new ArrayList(this.b.values());
  }
}


/* Location:              C:\adcap\Pad2\jd-gui-windows-1.4.0\classes-dex2jar.jar!\jp\gungho\a\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */