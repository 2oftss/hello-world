package jp.gungho.a;

public class h
{
  public static boolean a(String paramString1, String paramString2, String paramString3)
  {
    return paramString2 != null;
  }
}


/* Location:              C:\adcap\Pad2\jd-gui-windows-1.4.0\classes-dex2jar.jar!\jp\gungho\a\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */