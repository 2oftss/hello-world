package jp.gungho.padEN;

import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.content.BroadcastReceiver;
import android.content.ClipData;
import android.content.ClipData.Item;
import android.content.ClipDescription;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.AssetFileDescriptor;
import android.content.res.AssetManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.FontMetrics;
import android.graphics.Paint.Style;
import android.graphics.Point;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.media.AudioManager;
import android.media.SoundPool;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.NetworkInfo.State;
import android.net.Uri;
import android.net.Uri.Builder;
import android.os.Build;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.os.StatFs;
import android.os.SystemClock;
import android.text.Editable;
import android.text.InputFilter;
import android.text.InputFilter.LengthFilter;
import android.text.Spanned;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnFocusChangeListener;
import android.view.View.OnKeyListener;
import android.view.View.OnSystemUiVisibilityChangeListener;
import android.view.ViewConfiguration;
import android.view.ViewGroup.LayoutParams;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.FrameLayout.LayoutParams;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;
import com.facebook.AccessToken;
import com.facebook.CallbackManager;
import com.facebook.CallbackManager.Factory;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.Profile;
import com.facebook.appevents.AppEventsLogger;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions.Builder;
import com.google.android.gms.common.GoogleApiAvailability;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;
import com.kochava.base.Tracker;
import com.kochava.base.Tracker.Configuration;
import com.kochava.base.Tracker.Event;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintStream;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.security.KeyStore;
import java.security.MessageDigest;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;
import jp.gungho.a.d.a;
import jp.gungho.a.d.c;
import jp.gungho.a.d.d;
import jp.gungho.a.d.e;
import jp.gungho.a.g;
import org.json.JSONObject;

public class AppDelegate
  extends Activity
{
  private static final String ACCOUNT_TYPE = "com.google";
  private static final String AUTH_TOKEN_TYPE_EMAIL = "oauth2:https://www.googleapis.com/auth/userinfo.email";
  private static final int DF_MAX_SND_BANKS = 256;
  protected static final int FBNetworkReachableNon = 1;
  protected static final int FBNetworkReachableUninitialization = 0;
  protected static final int FBNetworkReachableWWAN = 3;
  protected static final int FBNetworkReachableWiFi = 2;
  private static final int GOOGLE_OAUTH_STATE_CANCEL = 3;
  private static final int GOOGLE_OAUTH_STATE_ERROR = 2;
  private static final int GOOGLE_OAUTH_STATE_PERMISSION_ERROR = 4;
  private static final int GOOGLE_OAUTH_STATE_SUCCESS = 1;
  private static final int GOOGLE_OAUTH_STATE_WAIT = 0;
  private static final int HANDLE_MESSAGE_ADD_NUMBER_FIELD = 1;
  private static final int HANDLE_MESSAGE_ADD_TEXT_FIELD = 0;
  private static final int HANDLE_MESSAGE_ADD_WEB_VIEW = 10;
  private static final int HANDLE_MESSAGE_CHANGE_SECURE = 33;
  private static final int HANDLE_MESSAGE_CHECK_REW_TRANSACTIONS = 40;
  private static final int HANDLE_MESSAGE_CHG_TEXT_FIELD_MAG = 4;
  private static final int HANDLE_MESSAGE_CHG_TEXT_FIELD_POS = 3;
  private static final int HANDLE_MESSAGE_COMPLETE_TRANSACTION = 23;
  private static final int HANDLE_MESSAGE_CONSUME_FINISHED = 22;
  private static final int HANDLE_MESSAGE_DEL_TEXT_FIELD = 2;
  private static final int HANDLE_MESSAGE_DEL_WEB_VIEW = 11;
  private static final int HANDLE_MESSAGE_ERASE_KEY_BOARD = 35;
  private static final int HANDLE_MESSAGE_FADE_TEXT_FIELD = 36;
  private static final int HANDLE_MESSAGE_FAILED_TRANSACTION = 24;
  private static final int HANDLE_MESSAGE_FULLHTML_CLOSE = 19;
  private static final int HANDLE_MESSAGE_FULLHTML_OPEN = 18;
  private static final int HANDLE_MESSAGE_G_PLUS_DISCONNECT = 29;
  private static final int HANDLE_MESSAGE_G_PLUS_SIGN_OUT = 28;
  private static final int HANDLE_MESSAGE_HIDE_TEXT_FIELD = 6;
  private static final int HANDLE_MESSAGE_IMGVIEW_CLOSE = 9;
  private static final int HANDLE_MESSAGE_INIT_WITH_TITLE = 17;
  private static final int HANDLE_MESSAGE_MAILEDIT_CLOSE = 8;
  private static final int HANDLE_MESSAGE_MAILEDIT_OPEN = 7;
  private static final int HANDLE_MESSAGE_NAVIGATION = 38;
  private static final int HANDLE_MESSAGE_OPEN_ALERT_DIALOG = 13;
  private static final int HANDLE_MESSAGE_OPEN_ERROR_DIALOG = 32;
  private static final int HANDLE_MESSAGE_PRODUCTS_REQUEST = 15;
  private static final int HANDLE_MESSAGE_PURCHASE_FINISHED = 21;
  private static final int HANDLE_MESSAGE_RAISE_KEY_BOARD = 31;
  private static final int HANDLE_MESSAGE_RESTORE_REW_TRANSACTIONS = 39;
  private static final int HANDLE_MESSAGE_RESTORE_TRANSACTIONS = 14;
  private static final int HANDLE_MESSAGE_SET_CLIPBOARD = 20;
  private static final int HANDLE_MESSAGE_SET_FULL_SCREEN = 12;
  private static final int HANDLE_MESSAGE_SET_SECURE = 34;
  private static final int HANDLE_MESSAGE_SET_TEXT_FIELD_ENABLE = 30;
  private static final int HANDLE_MESSAGE_SET_TEXT_FIELD_TEXT = 5;
  private static final int HANDLE_MESSAGE_SIGN_BAR_CLOSE = 27;
  private static final int HANDLE_MESSAGE_SIGN_IN = 37;
  private static final int HANDLE_MESSAGE_SIGN_IN_BAR_OPEN = 25;
  private static final int HANDLE_MESSAGE_SIGN_OUT_BAR_OPEN = 26;
  private static final int HANDLE_MESSAGE_SOUND_POOL_PLAY = 16;
  private static final int HANDLE_MESSAGE_START_AD = 99;
  private static final String IAB_REWARD_PREFIX = ".rew";
  private static final float KEYBOARD_DETECT_BOTTOM_THRESHOLD_DP = 100.0F;
  private static final int PERMISSION_REQUEST_GET_ACCOUNTS = 1;
  private static final int PERMISSION_REQUEST_WRITE_EXTERNAL_STORAGE = 2;
  static final int RC_REQUEST = 10001;
  protected static final int RECV_ERROR = 2;
  protected static final int RECV_PERMISSION_ERROR = 3;
  protected static final int RECV_PROCESS = 0;
  protected static final int RECV_SUCCESS = 1;
  private static final int REQUEST_CODE_AUTH = 10002;
  private static final int REQUEST_CODE_GMS = 10003;
  private static final int SNDPOOL_INITIAL = 4113;
  private static final int SNDPOOL_MAX_BANKS = 256;
  private static final int SNDPOOL_PAUSED = 4115;
  private static final int SNDPOOL_PLAYING = 4114;
  private static final int SNDPOOL_SOURCE_STATE = 4112;
  private static final int SNDPOOL_STOPPED = 4116;
  protected static final String SP_BOOT_CHECK_KEY = "bootcheck";
  protected static final String SP_SAVE_ANDROID = "data076";
  protected static final String SP_STACK_TRACE_KEY = "stacktrace";
  private static final int UIKeyboardTypeASCIICapable = 1;
  private static final int UIKeyboardTypeAlphabet = 1;
  private static final int UIKeyboardTypeAndPunctnuation = 2;
  private static final int UIKeyboardTypeDefault = 0;
  private static final int UIKeyboardTypeNsamePhonePad = 6;
  private static final int UIKeyboardTypeNumberPad = 4;
  private static final int UIKeyboardTypePhonePad = 5;
  private static final int UIKeyboardTypeURL = 3;
  private static AppDelegate appDelegate;
  private static Paint.FontMetrics font;
  private static Handler handler;
  private static final boolean isLog = false;
  private static final int kCFStreamEventCanAcceptBytes = 4;
  private static final int kCFStreamEventEndEncountered = 16;
  private static final int kCFStreamEventErrorOccurred = 8;
  private static final int kCFStreamEventHasBytesAvailable = 2;
  private static final int kCFStreamEventNone = 0;
  private static final int kCFStreamEventOpenCompleted = 1;
  private static BroadcastReceiver mReceiver = new BroadcastReceiver()
  {
    public void onReceive(Context paramAnonymousContext, Intent paramAnonymousIntent)
    {
      if (paramAnonymousIntent.getAction().equals("android.intent.action.HEADSET_PLUG"))
      {
        if (paramAnonymousIntent.getIntExtra("state", 0) != 1) {
          break label65;
        }
        AppDelegate.appDelegate._izDevSetHeadSetPlug(true);
      }
      for (;;)
      {
        if (paramAnonymousIntent.getAction().equals("android.media.RINGER_MODE_CHANGED"))
        {
          int i = paramAnonymousIntent.getIntExtra("android.media.EXTRA_RINGER_MODE", -1);
          AppDelegate.appDelegate._izDevSetRingerModeState(i);
        }
        AppDelegate.appDelegate.setBroadcastReceive(true);
        return;
        label65:
        if (paramAnonymousIntent.getIntExtra("state", 0) == 0) {
          AppDelegate.appDelegate._izDevSetHeadSetPlug(false);
        }
      }
    }
  };
  private static final boolean multipleTouchEnabled = false;
  private static final Paint paint = new Paint();
  private static final boolean useFBSDK = true;
  private static final boolean useKochava = true;
  private String ShopStoneUrl = null;
  private String accountName;
  private int appViewHeight;
  jp.gungho.a.b audioPlayer = new jp.gungho.a.b();
  private int authState;
  private String authToken;
  private String authTokenType;
  private boolean bDispKeyboard;
  private boolean bErrorDialog = false;
  private boolean bWebLoaded;
  private ByteArrayOutputStream bos;
  private Canvas canvas;
  private float dispHeight;
  private float dispWidth;
  ArrayList<String> fileArray;
  private FrameLayout frameLayout;
  private boolean hasPermanentMenuKey = true;
  private HttpURLConnection http;
  private InputStream in;
  private boolean inEditing;
  private boolean inNumberOnly;
  private boolean isAlartDialog = false;
  private boolean isBroadcastReceiv = false;
  private boolean isNavibarHide = false;
  private boolean isPlugged = false;
  private int isRingerMode = 2;
  private boolean isSecure = false;
  int latchPtf = 0;
  String latchText = "";
  private AlertDialog.Builder mAlertDialog;
  private AudioManager mAudioManager = null;
  d.e mCheckInventoryListener = new d.e()
  {
    public void a(jp.gungho.a.e paramAnonymouse, jp.gungho.a.f paramAnonymousf)
    {
      if (paramAnonymouse.d()) {}
      for (;;)
      {
        return;
        paramAnonymouse = paramAnonymousf.b().iterator();
        while (paramAnonymouse.hasNext())
        {
          paramAnonymousf = (g)paramAnonymouse.next();
          if (paramAnonymousf.b().endsWith(".rew") == true) {
            AppDelegate.this.consumeFinished(paramAnonymousf);
          }
        }
        for (int i = 1; i == 0; i = 0)
        {
          AppDelegate.this.enableRewardCheck(false);
          AppDelegate.this._completeTransaction();
          return;
        }
      }
    }
  };
  d.e mCheckRewListener = new d.e()
  {
    public void a(jp.gungho.a.e paramAnonymouse, jp.gungho.a.f paramAnonymousf)
    {
      if (paramAnonymouse.d()) {
        return;
      }
      AppDelegate.this.enableRewardCheck(false);
      AppDelegate.this._completeTransaction();
    }
  };
  private int[] mColors;
  d.a mConsumeFinishedListener = new d.a()
  {
    public void a(g paramAnonymousg, jp.gungho.a.e paramAnonymouse)
    {
      if (paramAnonymouse.c())
      {
        AppDelegate.this._completeTransaction();
        return;
      }
      switch (paramAnonymouse.a())
      {
      default: 
        AppDelegate.this._failedTransaction(0, 1);
        return;
      }
      AppDelegate.this._failedTransaction(2, 0);
    }
  };
  private int mContentLength;
  private CountDownLatch mDisptLatch;
  private DialogInterface.OnClickListener mErrorButtonListener;
  private AlertDialog.Builder mErrorDialog;
  private AccessToken mFbAccessToken;
  private CallbackManager mFbCallbackManager;
  private boolean mFocus = false;
  private GoogleSignInClient mGoogleSignInClient;
  d.e mGotInventoryListener = new d.e()
  {
    public void a(jp.gungho.a.e paramAnonymouse, jp.gungho.a.f paramAnonymousf)
    {
      if (paramAnonymouse.d()) {}
      int i;
      do
      {
        return;
        paramAnonymouse = paramAnonymousf.b().iterator();
        i = 0;
        while (paramAnonymouse.hasNext())
        {
          paramAnonymousf = (g)paramAnonymouse.next();
          if (!paramAnonymousf.b().endsWith(".rew"))
          {
            i = 1;
            AppDelegate.this.consumeFinished(paramAnonymousf);
          }
        }
      } while (i != 0);
      AppDelegate.this.enableRewardCheck(false);
      AppDelegate.this._completeTransaction();
    }
  };
  d.e mGotSkuDetailsListener = new d.e()
  {
    public void a(jp.gungho.a.e paramAnonymouse, jp.gungho.a.f paramAnonymousf)
    {
      if (paramAnonymouse.d()) {
        return;
      }
      paramAnonymouse = paramAnonymousf.b().iterator();
      Object localObject1;
      while (paramAnonymouse.hasNext())
      {
        localObject1 = (g)paramAnonymouse.next();
        if (!((g)localObject1).b().endsWith(".rew")) {
          AppDelegate.this.consumeFinished((g)localObject1);
        }
      }
      paramAnonymouse = paramAnonymousf.a();
      if (paramAnonymouse != null)
      {
        paramAnonymousf = new String[paramAnonymouse.size()];
        localObject1 = new String[paramAnonymouse.size()];
        String[] arrayOfString1 = new String[paramAnonymouse.size()];
        String[] arrayOfString2 = new String[paramAnonymouse.size()];
        float[] arrayOfFloat = new float[paramAnonymouse.size()];
        Object localObject2 = paramAnonymouse.iterator();
        int i = 0;
        while (((Iterator)localObject2).hasNext())
        {
          Object localObject3 = (jp.gungho.a.i)((Iterator)localObject2).next();
          paramAnonymousf[i] = ((jp.gungho.a.i)localObject3).a();
          int j = ((jp.gungho.a.i)localObject3).c().indexOf(" (");
          StringBuffer localStringBuffer;
          label234:
          int k;
          if (j < 0)
          {
            localObject1[i] = ((jp.gungho.a.i)localObject3).c();
            arrayOfString1[i] = ((jp.gungho.a.i)localObject3).b();
            arrayOfString2[i] = ((jp.gungho.a.i)localObject3).d();
            localObject3 = new String("0123456789.-");
            localStringBuffer = new StringBuffer("");
            j = 0;
            if (j < arrayOfString1[i].length()) {
              k = 0;
            }
          }
          else
          {
            for (;;)
            {
              if (k < ((String)localObject3).length())
              {
                if (arrayOfString1[i].substring(j, j + 1).equals(((String)localObject3).substring(k, k + 1))) {
                  localStringBuffer.append(arrayOfString1[i].substring(j, j + 1));
                }
              }
              else
              {
                j += 1;
                break label234;
                localObject1[i] = ((jp.gungho.a.i)localObject3).c().substring(0, j);
                break;
              }
              k += 1;
            }
          }
          arrayOfFloat[i] = Float.valueOf(localStringBuffer.toString()).floatValue();
          i += 1;
        }
        localObject2 = AppDelegate.this.getResources().getConfiguration().locale.getLanguage();
        AppDelegate.this.productsRequest(paramAnonymousf, (String[])localObject1, arrayOfString1, arrayOfString2, (String)localObject2, arrayOfFloat, paramAnonymouse.size());
        return;
      }
      AppDelegate.this.requestDidFailWithError();
    }
  };
  private Handler mHandler;
  jp.gungho.a.d mHelper;
  private b mImgView;
  private DialogInterface.OnClickListener mNegativeButtonListener;
  private boolean mPaused = false;
  private String mPayloadContents = null;
  private String mPbuff;
  private int mPermissionsReqNum = 0;
  private boolean mPermissionsResult = false;
  private boolean mPermissionsResultBusy = false;
  private DialogInterface.OnClickListener mPositiveButtonListener;
  private String mPua;
  d.c mPurchaseFinishedListener = new d.c()
  {
    public void a(jp.gungho.a.e paramAnonymouse, g paramAnonymousg)
    {
      if (paramAnonymouse.d())
      {
        switch (paramAnonymouse.a())
        {
        default: 
          AppDelegate.this._failedTransaction(0, 1);
          return;
        }
        AppDelegate.this._failedTransaction(2, 0);
        return;
      }
      AppDelegate.this.consumeFinished(paramAnonymousg);
    }
  };
  private String mPurl;
  private int mSize;
  private byte[] mSysFontBmp;
  private Bitmap.Config mSysFontConfig;
  private int mSysFontHeight;
  private CountDownLatch mSysFontLatch;
  private String mSysFontText;
  private int mSysFontWidth;
  private float mSysFontX;
  private float mSysFontY;
  private String mUrlQuery;
  private String mUrlScheme;
  private e mView;
  private int maxGroup;
  private int[] maxStream;
  private int maxTextLeng;
  private boolean mbBlock;
  private boolean mbGzip;
  private int navigationBarHeight;
  private c notification = null;
  private f pBgDlMan;
  private h pHTMLVIEW;
  private i pMEDIT;
  private CountDownLatch pTextFieldLatch;
  ArrayList<d> pTextFields = new ArrayList();
  private WebView pUiWebView;
  private int recv = 0;
  private long[][] sndPlayTime;
  private SoundPool sndPool;
  private int[][] sndPoolId;
  private int[][] sndPoolState;
  private long[][] sndPoolStopTime;
  private int statusBarHeight;
  final String tag_datainstall = "DataInstall";
  private Thread thread;
  private Rect webBounds;
  private float webViewPos_x;
  private float webViewPos_y;
  private int webViewStartLine;
  private float webViewY;
  private int webViewYtgt;
  
  static
  {
    font = paint.getFontMetrics();
    System.loadLibrary("openal");
    System.loadLibrary("pad");
  }
  
  private void createGoogleClient()
  {
    if (this.mGoogleSignInClient == null) {
      this.mGoogleSignInClient = GoogleSignIn.getClient(this, new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN).requestEmail().build());
    }
  }
  
  private void debugLog(String paramString1, String paramString2) {}
  
  static AppDelegate getInstance()
  {
    return appDelegate;
  }
  
  public static String getStringDigest(String paramString)
  {
    StringBuilder localStringBuilder = new StringBuilder();
    MessageDigest localMessageDigest = MessageDigest.getInstance("MD5");
    localMessageDigest.update(paramString.getBytes());
    paramString = localMessageDigest.digest();
    int i = 0;
    while (i < paramString.length)
    {
      if ((paramString[i] & 0xFF) < 16) {
        localStringBuilder.append("0");
      }
      localStringBuilder.append(Integer.toHexString(paramString[i] & 0xFF));
      i += 1;
    }
    return localStringBuilder.toString();
  }
  
  private void googleSignIn()
  {
    Intent localIntent = this.mGoogleSignInClient.getSignInIntent();
    if (isValidgmsVersion())
    {
      startActivityForResult(localIntent, 10002);
      return;
    }
    this.authState = 2;
  }
  
  private void handleSignInResult(Task<GoogleSignInAccount> paramTask)
  {
    try
    {
      this.accountName = ((GoogleSignInAccount)paramTask.getResult(ApiException.class)).getEmail();
      this.authState = 1;
      return;
    }
    catch (ApiException paramTask)
    {
      this.authState = 2;
    }
  }
  
  private String replaceLanguageAndRegion(String paramString)
  {
    Object localObject;
    if (!paramString.contains("%lang%"))
    {
      localObject = paramString;
      if (!paramString.contains("%region%")) {}
    }
    else
    {
      localObject = Locale.getDefault();
      localObject = paramString.replace("%lang%", ((Locale)localObject).getLanguage().toLowerCase()).replace("%region%", ((Locale)localObject).getCountry().toLowerCase());
    }
    return (String)localObject;
  }
  
  private void updateGoogleAccount()
  {
    GoogleSignInAccount localGoogleSignInAccount = GoogleSignIn.getLastSignedInAccount(this);
    if (localGoogleSignInAccount != null) {
      this.accountName = localGoogleSignInAccount.getEmail();
    }
  }
  
  String CFStringCreateWithCString(String paramString1, String paramString2)
  {
    try
    {
      paramString1 = new String(paramString1.getBytes(), paramString2);
      return paramString1;
    }
    catch (Exception paramString1)
    {
      paramString1.printStackTrace();
    }
    return null;
  }
  
  String CFUUIDCreateString()
  {
    return UUID.randomUUID().toString();
  }
  
  String CFUUIDCreateStringUTF8()
  {
    try
    {
      String str = new String(UUID.randomUUID().toString().getBytes("UTF8"), "UTF8");
      return str;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return null;
  }
  
  public boolean _IzInAsyncOperation()
  {
    if (this.mHelper == null) {
      return false;
    }
    return this.mHelper.d();
  }
  
  void _completeTransaction()
  {
    Message localMessage = handler.obtainMessage();
    localMessage.what = 23;
    handler.sendMessage(localMessage);
  }
  
  void _consumeFinished(final g paramg)
  {
    new Thread(new Runnable()
    {
      public void run()
      {
        Object localObject5 = null;
        Object localObject6 = null;
        Object localObject7 = null;
        Object localObject1 = localObject7;
        Object localObject4 = localObject5;
        Object localObject3 = localObject6;
        int i;
        for (;;)
        {
          try
          {
            if (paramg != null)
            {
              localObject4 = localObject5;
              localObject3 = localObject6;
              bool = paramg.equals("");
              if (!bool) {
                continue;
              }
              localObject1 = localObject7;
            }
          }
          catch (Exception localException)
          {
            boolean bool;
            String str;
            localObject3 = localObject4;
            localException.printStackTrace();
            localObject3 = localObject4;
            AppDelegate.this._failedTransaction(0, 1);
            return;
            localObject4 = localObject5;
            localObject3 = localObject6;
            HttpURLConnection localHttpURLConnection = (HttpURLConnection)localException.openConnection();
            continue;
            localObject4 = localHttpURLConnection;
            localObject3 = localHttpURLConnection;
            localObject6 = ((StringBuilder)localObject6).toString();
            localObject4 = localHttpURLConnection;
            localObject3 = localHttpURLConnection;
            ((InputStream)localObject5).close();
            localObject4 = localHttpURLConnection;
            localObject3 = localHttpURLConnection;
            localObject5 = new JSONObject((String)localObject6);
            localObject4 = localHttpURLConnection;
            localObject3 = localHttpURLConnection;
            i = (int)((JSONObject)localObject5).getDouble("res");
            if ((i != 0) && (i != 22)) {
              break label754;
            }
            localObject4 = localHttpURLConnection;
            localObject3 = localHttpURLConnection;
            i = ((JSONObject)localObject5).getInt("gold");
            localObject4 = localHttpURLConnection;
            localObject3 = localHttpURLConnection;
            if (AppDelegate.this.mHelper.d()) {
              continue;
            }
            localObject4 = localHttpURLConnection;
            localObject3 = localHttpURLConnection;
            localObject6 = AppDelegate.handler.obtainMessage(22, paramg);
            localObject4 = localHttpURLConnection;
            localObject3 = localHttpURLConnection;
            ((Message)localObject6).arg1 = i;
            localObject4 = localHttpURLConnection;
            localObject3 = localHttpURLConnection;
            if (!AppDelegate.this.ShopStoneUrl.contains("action=adr_purchase_reward")) {
              break label739;
            }
            localObject4 = localHttpURLConnection;
            localObject3 = localHttpURLConnection;
            ((Message)localObject6).arg2 = ((JSONObject)localObject5).getInt("mail");
            localObject4 = localHttpURLConnection;
            localObject3 = localHttpURLConnection;
            AppDelegate.handler.sendMessage((Message)localObject6);
            continue;
          }
          finally
          {
            if (localObject3 == null) {
              continue;
            }
            ((HttpURLConnection)localObject3).disconnect();
          }
          if (localObject1 != null) {
            ((HttpURLConnection)localObject1).disconnect();
          }
          return;
          localObject4 = localObject5;
          localObject3 = localObject6;
          bool = AppDelegate.this.getViewInitFlag();
          if (!bool)
          {
            if (0 != 0) {
              throw new NullPointerException();
            }
          }
          else
          {
            localObject4 = localObject5;
            localObject3 = localObject6;
            localObject1 = new URL(AppDelegate.this.ShopStoneUrl);
            localObject4 = localObject5;
            localObject3 = localObject6;
            if (AppDelegate.this.ShopStoneUrl.startsWith("https"))
            {
              localObject4 = localObject5;
              localObject3 = localObject6;
              localObject1 = (HttpsURLConnection)((URL)localObject1).openConnection();
              localObject4 = localObject1;
              localObject3 = localObject1;
              ((HttpURLConnection)localObject1).setRequestMethod("POST");
              localObject4 = localObject1;
              localObject3 = localObject1;
              ((HttpURLConnection)localObject1).setDoInput(true);
              localObject4 = localObject1;
              localObject3 = localObject1;
              ((HttpURLConnection)localObject1).setDoOutput(true);
              localObject4 = localObject1;
              localObject3 = localObject1;
              ((HttpURLConnection)localObject1).setRequestProperty("User-Agent", AppDelegate.appDelegate.getUserAgent());
              localObject4 = localObject1;
              localObject3 = localObject1;
              localObject5 = new Uri.Builder();
              localObject4 = localObject1;
              localObject3 = localObject1;
              ((Uri.Builder)localObject5).appendQueryParameter("signed_data", paramg.d());
              localObject4 = localObject1;
              localObject3 = localObject1;
              ((Uri.Builder)localObject5).appendQueryParameter("signature", paramg.e());
              localObject4 = localObject1;
              localObject3 = localObject1;
              localObject5 = ((Uri.Builder)localObject5).build().getEncodedQuery();
              localObject4 = localObject1;
              localObject3 = localObject1;
              localObject7 = ((HttpURLConnection)localObject1).getOutputStream();
              localObject4 = localObject1;
              localObject3 = localObject1;
              localObject6 = new BufferedWriter(new OutputStreamWriter((OutputStream)localObject7, "UTF-8"));
              localObject4 = localObject1;
              localObject3 = localObject1;
              ((BufferedWriter)localObject6).write((String)localObject5);
              localObject4 = localObject1;
              localObject3 = localObject1;
              ((BufferedWriter)localObject6).flush();
              localObject4 = localObject1;
              localObject3 = localObject1;
              ((BufferedWriter)localObject6).close();
              localObject4 = localObject1;
              localObject3 = localObject1;
              ((OutputStream)localObject7).close();
              localObject4 = localObject1;
              localObject3 = localObject1;
              ((HttpURLConnection)localObject1).setReadTimeout(20000);
              localObject4 = localObject1;
              localObject3 = localObject1;
              ((HttpURLConnection)localObject1).setConnectTimeout(20000);
              localObject4 = localObject1;
              localObject3 = localObject1;
              ((HttpURLConnection)localObject1).connect();
              localObject4 = localObject1;
              localObject3 = localObject1;
              localObject5 = ((HttpURLConnection)localObject1).getInputStream();
              localObject4 = localObject1;
              localObject3 = localObject1;
              localObject7 = new BufferedReader(new InputStreamReader((InputStream)localObject5));
              localObject4 = localObject1;
              localObject3 = localObject1;
              localObject6 = new StringBuilder();
              localObject4 = localObject1;
              localObject3 = localObject1;
              str = ((BufferedReader)localObject7).readLine();
              if (str == null) {
                continue;
              }
              localObject4 = localObject1;
              localObject3 = localObject1;
              ((StringBuilder)localObject6).append(str);
              continue;
            }
            label739:
            localObject4 = localObject2;
            localObject3 = localObject2;
            ((Message)localObject6).arg2 = -1;
            continue;
            label754:
            if (i == 99)
            {
              localObject4 = localObject2;
              localObject3 = localObject2;
              AppDelegate.this._failedTransaction(0, 1);
            }
            else
            {
              if (i != 2) {
                break;
              }
              localObject4 = localObject2;
              localObject3 = localObject2;
              AppDelegate.this._failedTransaction(0, 1);
            }
          }
        }
        for (;;)
        {
          localObject4 = localObject2;
          localObject3 = localObject2;
          if (!AppDelegate.this.mHelper.d())
          {
            localObject4 = localObject2;
            localObject3 = localObject2;
            localObject5 = AppDelegate.handler.obtainMessage(22, paramg);
            localObject4 = localObject2;
            localObject3 = localObject2;
            ((Message)localObject5).arg1 = 0;
            localObject4 = localObject2;
            localObject3 = localObject2;
            if (AppDelegate.this.ShopStoneUrl.contains("action=adr_purchase_reward"))
            {
              localObject4 = localObject2;
              localObject3 = localObject2;
            }
            for (((Message)localObject5).arg2 = 0;; ((Message)localObject5).arg2 = -1)
            {
              localObject4 = localObject2;
              localObject3 = localObject2;
              AppDelegate.handler.sendMessage((Message)localObject5);
              break;
              localObject4 = localObject2;
              localObject3 = localObject2;
            }
            do
            {
              localObject4 = localObject2;
              localObject3 = localObject2;
              AppDelegate.this._failedTransaction(0, 1);
              break;
            } while (i != 59);
          }
        }
      }
    }).start();
  }
  
  String _deleteCR(String paramString)
  {
    int j = paramString.length();
    StringBuilder localStringBuilder = new StringBuilder();
    int i = 0;
    if (i < j)
    {
      int k = paramString.codePointAt(i);
      if (k == 10) {
        localStringBuilder.append(" ");
      }
      for (;;)
      {
        i += Character.charCount(k);
        break;
        localStringBuilder.append(paramString.charAt(i));
      }
    }
    return localStringBuilder.toString();
  }
  
  int _deleteFilesInFolderMain(String paramString)
  {
    int j = 0;
    paramString = new File(paramString);
    int k;
    if (paramString.isDirectory())
    {
      String[] arrayOfString = paramString.list();
      int i = 0;
      k = i;
      if (j < arrayOfString.length)
      {
        i += 1;
        File localFile = new File(paramString, arrayOfString[j]);
        if (localFile.isDirectory()) {
          _deleteFilesInFolderMain(localFile.getPath());
        }
        for (;;)
        {
          j += 1;
          break;
          if (localFile.delete()) {}
        }
      }
    }
    else
    {
      if (!paramString.delete()) {}
      k = 0;
    }
    return k;
  }
  
  byte[] _drawSysFont(String paramString, float paramFloat1, float paramFloat2)
  {
    this.mSysFontBmp = drawSysFont(paramString, paramFloat1, paramFloat2);
    if ((this.mSysFontBmp == null) && (!TextUtils.isEmpty(paramString)) && (!getNavibar()) && (_izDevGetBuild_SDK_INT() >= 19) && (!TextUtils.isEmpty(paramString))) {}
    try
    {
      this.mSysFontText = new String(paramString);
      this.mSysFontX = paramFloat1;
      this.mSysFontY = paramFloat2;
      this.mSysFontLatch = new CountDownLatch(1);
      appDelegate.runOnUiThread(new Runnable()
      {
        public void run()
        {
          AppDelegate.access$2902(AppDelegate.this, AppDelegate.this.drawSysFont(AppDelegate.this.mSysFontText, AppDelegate.this.mSysFontX, AppDelegate.this.mSysFontY));
          AppDelegate.access$3002(AppDelegate.this, null);
          if (AppDelegate.this.mSysFontLatch != null) {
            AppDelegate.this.mSysFontLatch.countDown();
          }
        }
      });
      this.mSysFontLatch.await();
      return this.mSysFontBmp;
    }
    catch (Exception paramString)
    {
      for (;;)
      {
        paramString.printStackTrace();
      }
    }
  }
  
  void _failedTransaction(int paramInt1, int paramInt2)
  {
    Message localMessage = handler.obtainMessage();
    Bundle localBundle = new Bundle();
    localBundle.putInt("state", paramInt1);
    localBundle.putInt("code", paramInt2);
    localMessage.what = 24;
    localMessage.setData(localBundle);
    handler.sendMessage(localMessage);
  }
  
  int _izDevCheckNetConnect()
  {
    try
    {
      Object localObject2 = (ConnectivityManager)getSystemService("connectivity");
      Object localObject1 = ((ConnectivityManager)localObject2).getNetworkInfo(0);
      localObject2 = ((ConnectivityManager)localObject2).getNetworkInfo(1);
      if ((localObject2 != null) && (((NetworkInfo)localObject2).getState() == NetworkInfo.State.CONNECTED)) {
        return 2;
      }
      if (localObject1 != null)
      {
        localObject1 = ((NetworkInfo)localObject1).getState();
        localObject2 = NetworkInfo.State.CONNECTED;
        if (localObject1 == localObject2) {
          return 3;
        }
      }
      return 1;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return 1;
  }
  
  String _izDevGetBuild_BOARD()
  {
    return Build.BOARD;
  }
  
  String _izDevGetBuild_BOOTLOADER()
  {
    return Build.BOOTLOADER;
  }
  
  String _izDevGetBuild_BRAND()
  {
    return Build.BRAND;
  }
  
  String _izDevGetBuild_CODENAME()
  {
    return Build.VERSION.CODENAME;
  }
  
  String _izDevGetBuild_CPU_ABI()
  {
    return Build.CPU_ABI;
  }
  
  String _izDevGetBuild_CPU_ABI2()
  {
    return Build.CPU_ABI2;
  }
  
  String _izDevGetBuild_DEVICE()
  {
    return Build.DEVICE;
  }
  
  String _izDevGetBuild_DISPLAY()
  {
    return Build.DISPLAY;
  }
  
  String _izDevGetBuild_FINGERPRINT()
  {
    return Build.FINGERPRINT;
  }
  
  String _izDevGetBuild_HARDWARE()
  {
    return Build.HARDWARE;
  }
  
  String _izDevGetBuild_HOST()
  {
    return Build.HOST;
  }
  
  String _izDevGetBuild_ID()
  {
    return Build.ID;
  }
  
  String _izDevGetBuild_INCREMENTAL()
  {
    return Build.VERSION.INCREMENTAL;
  }
  
  String _izDevGetBuild_MANUFACTURER()
  {
    return Build.MANUFACTURER;
  }
  
  String _izDevGetBuild_MODEL()
  {
    return Build.MODEL;
  }
  
  String _izDevGetBuild_PRODUCT()
  {
    return Build.PRODUCT;
  }
  
  String _izDevGetBuild_RADIO()
  {
    return Build.RADIO;
  }
  
  String _izDevGetBuild_RELEASE()
  {
    return Build.VERSION.RELEASE;
  }
  
  String _izDevGetBuild_SDK()
  {
    return Integer.toString(Build.VERSION.SDK_INT);
  }
  
  int _izDevGetBuild_SDK_INT()
  {
    return Build.VERSION.SDK_INT;
  }
  
  String _izDevGetBuild_TAGS()
  {
    return Build.TAGS;
  }
  
  long _izDevGetBuild_TIME()
  {
    return Build.TIME;
  }
  
  String _izDevGetBuild_TYPE()
  {
    return Build.TYPE;
  }
  
  String _izDevGetBuild_UNKNOWN()
  {
    return "unknown";
  }
  
  String _izDevGetBuild_USER()
  {
    return Build.USER;
  }
  
  float _izDevGetDensity()
  {
    return 2.0F;
  }
  
  boolean _izDevGetHeadSetPlug()
  {
    return this.isPlugged;
  }
  
  int _izDevGetHeight()
  {
    return ((WindowManager)getSystemService("window")).getDefaultDisplay().getHeight();
  }
  
  public int _izDevGetOsVer()
  {
    return Build.VERSION.SDK_INT;
  }
  
  int _izDevGetOsVerMajor()
  {
    if (Build.VERSION.RELEASE.equals("L")) {
      return 5;
    }
    if (Build.VERSION.RELEASE.equals("M")) {
      return 6;
    }
    if (Build.VERSION.RELEASE.equals("N")) {
      return 7;
    }
    try
    {
      int i = Build.VERSION.RELEASE.indexOf(".");
      if (i < 0) {
        return Integer.valueOf(Build.VERSION.RELEASE).intValue();
      }
      i = Integer.valueOf(Build.VERSION.RELEASE.substring(0, i)).intValue();
      return i;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return 0;
  }
  
  int _izDevGetOsVerMinor()
  {
    if (Build.VERSION.RELEASE.equals("L")) {}
    for (;;)
    {
      return 0;
      if ((!Build.VERSION.RELEASE.equals("M")) && (!Build.VERSION.RELEASE.equals("N"))) {
        try
        {
          int i = Build.VERSION.RELEASE.indexOf(".");
          if (i >= 0)
          {
            i = Integer.valueOf(Build.VERSION.RELEASE.substring(i + 1, i + 2)).intValue();
            return i;
          }
        }
        catch (Exception localException)
        {
          localException.printStackTrace();
        }
      }
    }
    return 0;
  }
  
  boolean _izDevGetRingerMode()
  {
    if (_izDevGetHeadSetPlug()) {
      return false;
    }
    switch (_izDevGetRingerModeState())
    {
    default: 
      return false;
    }
    return true;
  }
  
  int _izDevGetRingerModeState()
  {
    return this.isRingerMode;
  }
  
  int _izDevGetWidth()
  {
    return ((WindowManager)getSystemService("window")).getDefaultDisplay().getWidth();
  }
  
  void _izDevSetHeadSetPlug(boolean paramBoolean)
  {
    this.isPlugged = paramBoolean;
  }
  
  void _izDevSetRingerModeState(int paramInt)
  {
    this.isRingerMode = paramInt;
  }
  
  void _izDeviceExit() {}
  
  void _izDeviceInit() {}
  
  void _izFatalErrorCpp(String paramString1, String paramString2)
  {
    Message localMessage = handler.obtainMessage();
    Bundle localBundle = new Bundle();
    localBundle.putString("title", paramString1);
    localBundle.putString("message", paramString2);
    this.mErrorButtonListener = null;
    localBundle.putString("positive", "OK");
    this.mErrorButtonListener = new DialogInterface.OnClickListener()
    {
      public void onClick(DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt)
      {
        AppDelegate.appDelegate.onTouchEvent(0.0F, 0.0F, 0, 0, 1, 0, 0L, 0);
      }
    };
    this.mErrorDialog = null;
    this.mErrorDialog = new AlertDialog.Builder(this);
    localMessage.what = 32;
    localMessage.setData(localBundle);
    handler.sendMessage(localMessage);
  }
  
  int _izFileArrayContentsOfDirectoryAtPath(String paramString)
  {
    int m = 0;
    int k = 0;
    int i = 0;
    this.fileArray = null;
    int j = m;
    for (;;)
    {
      try
      {
        paramString = new File(paramString);
        j = m;
        if (paramString.isDirectory())
        {
          j = m;
          this.fileArray = new ArrayList();
          j = m;
          String[] arrayOfString = paramString.list();
          m = 0;
          j = i;
          k = i;
          if (m < arrayOfString.length)
          {
            j = i;
            File localFile = new File(paramString, arrayOfString[m]);
            j = i;
            if (localFile.isDirectory()) {
              break label142;
            }
            j = i;
            this.fileArray.add(localFile.getName());
            i += 1;
          }
        }
      }
      catch (Exception paramString)
      {
        paramString.toString();
        paramString.printStackTrace();
        k = j;
      }
      return k;
      label142:
      m += 1;
    }
  }
  
  String _izFileArrayGetFileName(String paramString, int paramInt)
  {
    try
    {
      paramString = new File(paramString).list()[paramInt];
      return paramString;
    }
    catch (Exception paramString)
    {
      paramString.printStackTrace();
    }
    return null;
  }
  
  String _izFileArrayObjectAtIndex(int paramInt)
  {
    try
    {
      if (this.fileArray != null)
      {
        String str = (String)this.fileArray.get(paramInt);
        return str;
      }
    }
    catch (Exception localException)
    {
      localException.toString();
      localException.printStackTrace();
    }
    return null;
  }
  
  boolean _izFileCheckNeed4dl(String paramString, int paramInt, double paramDouble)
  {
    try
    {
      paramString = new File(paramString);
      if (!paramString.exists()) {
        break label65;
      }
      if (paramString.length() != paramInt) {
        return true;
      }
      long l = paramString.lastModified() / 1000L;
      if (l - 978307200L < paramDouble) {
        break label65;
      }
    }
    catch (Exception paramString)
    {
      for (;;)
      {
        paramString.toString();
        paramString.printStackTrace();
      }
    }
    return false;
    label65:
    return true;
  }
  
  void _izFileCreateNewFile(String paramString, int paramInt)
  {
    int i = 0;
    try
    {
      Object localObject = new File(paramString);
      if (!((File)localObject).exists()) {
        ((File)localObject).createNewFile();
      }
      while (i == 0)
      {
        localObject = new byte[paramInt];
        paramString = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(paramString)));
        paramString.write((byte[])localObject, 0, paramInt);
        paramString.flush();
        paramString.close();
        return;
        long l = ((File)localObject).length();
        if (l > 0L) {
          i = 1;
        }
      }
      return;
    }
    catch (Throwable paramString)
    {
      paramString.printStackTrace();
    }
  }
  
  void _izFileCreateNewFileDoc(String paramString, int paramInt)
  {
    _izFileCreateNewFile(_izFileGetPathDoc(paramString), paramInt);
  }
  
  boolean _izFileDelete(String paramString)
  {
    try
    {
      boolean bool = new File(paramString).delete();
      return bool;
    }
    catch (Exception paramString)
    {
      paramString.printStackTrace();
    }
    return false;
  }
  
  int _izFileDeleteExclusions(String paramString, String[] paramArrayOfString)
  {
    int j;
    int i;
    int k;
    label195:
    for (;;)
    {
      try
      {
        paramString = new File(paramString);
        if (paramString.isDirectory())
        {
          arrayOfString = paramString.list();
          j = 0;
          i = 0;
          k = i;
        }
      }
      catch (Exception paramString)
      {
        String[] arrayOfString;
        File localFile;
        boolean bool;
        i = 0;
        paramString.toString();
        paramString.printStackTrace();
        return i;
      }
      try
      {
        if (j < arrayOfString.length)
        {
          localFile = new File(paramString, arrayOfString[j]);
          k = 0;
          int m = 0;
          if (k < paramArrayOfString.length)
          {
            bool = paramArrayOfString[k].equals(arrayOfString[j]);
            int n = m;
            if (bool) {
              n = m + 1;
            }
            k += 1;
            m = n;
            continue;
          }
          if (m != 0) {
            break label195;
          }
          k = i + 1;
        }
      }
      catch (Exception paramString)
      {
        continue;
        j += 1;
      }
      try
      {
        if (localFile.isDirectory())
        {
          i = k;
        }
        else
        {
          bool = localFile.delete();
          i = k;
          if (!bool) {
            i = k;
          }
        }
      }
      catch (Exception paramString)
      {
        i = k;
        continue;
      }
      bool = paramString.delete();
      if (!bool) {}
      k = 0;
      return k;
    }
  }
  
  void _izFileDeleteFilesInFolderOnCache(String paramString)
  {
    for (;;)
    {
      int i;
      try
      {
        paramString = new File(_izFileGetPathCache(paramString));
        if (paramString.isDirectory())
        {
          String[] arrayOfString = paramString.list();
          i = 0;
          if (i < arrayOfString.length)
          {
            File localFile = new File(paramString, arrayOfString[i]);
            if (localFile.isDirectory())
            {
              _deleteFilesInFolderMain(localFile.getPath());
              break label102;
            }
            if (localFile.delete()) {
              break label102;
            }
            break label102;
          }
        }
        else
        {
          boolean bool = paramString.delete();
          if (bool) {}
        }
        return;
      }
      catch (Exception paramString)
      {
        paramString.toString();
        paramString.printStackTrace();
        return;
      }
      label102:
      i += 1;
    }
  }
  
  double _izFileGetFileModTime(String paramString)
  {
    double d = 0.0D;
    try
    {
      paramString = new File(paramString);
      if (paramString.exists())
      {
        long l = paramString.lastModified() / 1000L;
        d = l - 978307200L;
      }
      return d;
    }
    catch (Exception paramString)
    {
      paramString.toString();
      paramString.printStackTrace();
    }
    return 0.0D;
  }
  
  long _izFileGetFileSizeFullPath(String paramString)
  {
    try
    {
      new File(paramString);
      return 0L;
    }
    catch (Exception paramString)
    {
      paramString.toString();
      paramString.printStackTrace();
    }
    return 0L;
  }
  
  boolean _izFileGetLeftSpaceFileSystemForPath()
  {
    boolean bool = false;
    try
    {
      File localFile = Environment.getDataDirectory();
      if (localFile != null) {
        bool = true;
      }
      return bool;
    }
    catch (Exception localException)
    {
      localException.toString();
      localException.printStackTrace();
    }
    return false;
  }
  
  long _izFileGetLeftSpaceSystemFreeSize()
  {
    long l = 0L;
    try
    {
      Object localObject = Environment.getDataDirectory();
      if (localObject != null)
      {
        localObject = new StatFs(((File)localObject).getPath());
        l = ((StatFs)localObject).getBlockSize();
        int i = ((StatFs)localObject).getAvailableBlocks();
        l = i * l;
      }
      return l;
    }
    catch (Exception localException)
    {
      localException.toString();
      localException.printStackTrace();
    }
    return 0L;
  }
  
  long _izFileGetLeftSpaceSystemSize()
  {
    long l = 0L;
    try
    {
      Object localObject = Environment.getDataDirectory();
      if (localObject != null)
      {
        localObject = new StatFs(((File)localObject).getPath());
        l = ((StatFs)localObject).getBlockSize();
        int i = ((StatFs)localObject).getBlockCount();
        l = i * l;
      }
      return l;
    }
    catch (Exception localException)
    {
      localException.toString();
      localException.printStackTrace();
    }
    return 0L;
  }
  
  String _izFileGetPathCache(String paramString)
  {
    try
    {
      str1 = getApplicationContext().getCacheDir().getAbsolutePath() + "/";
      String str2 = str1;
      if (paramString != null) {}
      paramString.toString();
    }
    catch (Exception paramString)
    {
      try
      {
        str2 = str1 + paramString;
        return str2;
      }
      catch (Exception paramString)
      {
        String str1;
        for (;;) {}
      }
      paramString = paramString;
      str1 = null;
    }
    paramString.printStackTrace();
    return str1;
  }
  
  String _izFileGetPathDoc(String paramString)
  {
    try
    {
      str1 = getApplicationContext().getFilesDir().getCanonicalPath() + "/";
      String str2 = str1;
      if (paramString != null) {}
      paramString.toString();
    }
    catch (Exception paramString)
    {
      try
      {
        str2 = str1 + paramString;
        return str2;
      }
      catch (Exception paramString)
      {
        String str1;
        for (;;) {}
      }
      paramString = paramString;
      str1 = null;
    }
    paramString.printStackTrace();
    return str1;
  }
  
  /* Error */
  boolean _izFileIsExistPath(String paramString)
  {
    // Byte code:
    //   0: new 868	java/io/File
    //   3: dup
    //   4: aload_1
    //   5: invokespecial 870	java/io/File:<init>	(Ljava/lang/String;)V
    //   8: astore_1
    //   9: aload_1
    //   10: invokevirtual 1163	java/io/File:exists	()Z
    //   13: istore_2
    //   14: iload_2
    //   15: istore_3
    //   16: iload_2
    //   17: ifeq +8 -> 25
    //   20: aload_1
    //   21: invokevirtual 873	java/io/File:isDirectory	()Z
    //   24: istore_3
    //   25: iload_3
    //   26: ireturn
    //   27: astore_1
    //   28: iconst_0
    //   29: istore_2
    //   30: aload_1
    //   31: invokevirtual 790	java/lang/Exception:printStackTrace	()V
    //   34: iload_2
    //   35: ireturn
    //   36: astore_1
    //   37: goto -7 -> 30
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	40	0	this	AppDelegate
    //   0	40	1	paramString	String
    //   13	22	2	bool1	boolean
    //   15	11	3	bool2	boolean
    // Exception table:
    //   from	to	target	type
    //   0	14	27	java/lang/Exception
    //   20	25	36	java/lang/Exception
  }
  
  boolean _izFileIsExists(String paramString)
  {
    try
    {
      boolean bool = new File(paramString).exists();
      return bool;
    }
    catch (Exception paramString)
    {
      paramString.printStackTrace();
    }
    return false;
  }
  
  String _izFileMakePathForCache(String paramString)
  {
    try
    {
      str1 = getApplicationContext().getCacheDir().getAbsolutePath() + "/";
      String str2 = str1;
      if (paramString != null) {}
      paramString.toString();
    }
    catch (Exception paramString)
    {
      try
      {
        str2 = str1 + paramString;
        return str2;
      }
      catch (Exception paramString)
      {
        String str1;
        for (;;) {}
      }
      paramString = paramString;
      str1 = null;
    }
    paramString.printStackTrace();
    return str1;
  }
  
  boolean _izFilePathMkDir(String paramString)
  {
    try
    {
      boolean bool = new File(paramString).mkdir();
      return bool;
    }
    catch (Exception paramString)
    {
      paramString.toString();
      paramString.printStackTrace();
    }
    return false;
  }
  
  boolean _izFilePathMkDirs(String paramString)
  {
    try
    {
      boolean bool = new File(paramString).mkdirs();
      return bool;
    }
    catch (Exception paramString)
    {
      paramString.toString();
      paramString.printStackTrace();
    }
    return false;
  }
  
  void _izFileSetFileModTime(String paramString, double paramDouble)
  {
    paramString = new File(paramString);
    SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
    if (paramString.exists())
    {
      String str = localSimpleDateFormat.format(new Date(paramString.lastModified()));
      debugLog("file", "変更前の更新日付 : " + str);
      str = localSimpleDateFormat.format(new Date((978307200L + paramDouble) * 1000L));
      debugLog("file", "変更する更新日付 : " + str);
      paramString.setLastModified((978307200L + paramDouble) * 1000L);
      paramString = localSimpleDateFormat.format(new Date(paramString.lastModified()));
      debugLog("file", "変更後の更新日付 : " + paramString);
    }
  }
  
  /* Error */
  boolean _izFileSetFileTime(String paramString, double paramDouble)
  {
    // Byte code:
    //   0: ldc2_w 1171
    //   3: l2d
    //   4: dload_2
    //   5: dadd
    //   6: d2l
    //   7: lstore 4
    //   9: new 868	java/io/File
    //   12: dup
    //   13: aload_1
    //   14: invokespecial 870	java/io/File:<init>	(Ljava/lang/String;)V
    //   17: astore_1
    //   18: aload_1
    //   19: invokevirtual 1163	java/io/File:exists	()Z
    //   22: istore 6
    //   24: iload 6
    //   26: istore 7
    //   28: iload 6
    //   30: ifeq +15 -> 45
    //   33: aload_1
    //   34: ldc2_w 1169
    //   37: lload 4
    //   39: lmul
    //   40: invokevirtual 1298	java/io/File:setLastModified	(J)Z
    //   43: istore 7
    //   45: iload 7
    //   47: ireturn
    //   48: astore_1
    //   49: iconst_0
    //   50: istore 6
    //   52: aload_1
    //   53: invokevirtual 1151	java/lang/Exception:toString	()Ljava/lang/String;
    //   56: pop
    //   57: aload_1
    //   58: invokevirtual 790	java/lang/Exception:printStackTrace	()V
    //   61: iload 6
    //   63: ireturn
    //   64: astore_1
    //   65: goto -13 -> 52
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	68	0	this	AppDelegate
    //   0	68	1	paramString	String
    //   0	68	2	paramDouble	double
    //   7	31	4	l	long
    //   22	40	6	bool1	boolean
    //   26	20	7	bool2	boolean
    // Exception table:
    //   from	to	target	type
    //   9	24	48	java/lang/Exception
    //   33	45	64	java/lang/Exception
  }
  
  boolean _izFileWrite(String paramString, byte[] paramArrayOfByte, int paramInt)
  {
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (paramArrayOfByte != null)
    {
      bool1 = bool2;
      if (paramInt > 0) {
        bool1 = bool2;
      }
    }
    try
    {
      if (paramArrayOfByte.length >= paramInt)
      {
        File localFile = new File(paramString);
        if (!localFile.exists()) {
          localFile.createNewFile();
        }
        paramString = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(paramString)));
        paramString.write(paramArrayOfByte, 0, paramInt);
        paramString.flush();
        paramString.close();
        bool1 = true;
      }
      return bool1;
    }
    catch (Exception paramString)
    {
      paramString.printStackTrace();
    }
    return false;
  }
  
  boolean _izFileWriteCache(String paramString, byte[] paramArrayOfByte, int paramInt)
  {
    return _izFileWrite(_izFileGetPathCache(paramString), paramArrayOfByte, paramInt);
  }
  
  boolean _izFileWriteDoc(String paramString, byte[] paramArrayOfByte, int paramInt)
  {
    return _izFileWrite(_izFileGetPathDoc(paramString), paramArrayOfByte, paramInt);
  }
  
  boolean _izFileWriteDocAbandon(String paramString, byte[] paramArrayOfByte, int paramInt)
  {
    return _izFileWriteDoc(paramString, paramArrayOfByte, paramInt);
  }
  
  void _izFontExit()
  {
    this.canvas = null;
    this.bos = null;
  }
  
  void _izFontInit()
  {
    this.canvas = null;
    this.bos = null;
  }
  
  void _izFontInitCGBitmapContextCreate(byte[] paramArrayOfByte, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6)
  {
    switch (paramInt3)
    {
    default: 
      paramArrayOfByte = Bitmap.Config.ARGB_8888;
    }
    for (;;)
    {
      this.mSysFontWidth = paramInt1;
      this.mSysFontHeight = paramInt2;
      this.mSysFontConfig = paramArrayOfByte;
      return;
      paramArrayOfByte = Bitmap.Config.ARGB_4444;
      continue;
      paramArrayOfByte = Bitmap.Config.ARGB_8888;
    }
  }
  
  String _izGetLanguage()
  {
    return getResources().getConfiguration().locale.getLanguage();
  }
  
  String _izHttpCFHTTPMessageCopyHeaderFieldValue(String paramString)
  {
    Object localObject2 = null;
    Object localObject1 = localObject2;
    if (this.http != null) {
      localObject1 = localObject2;
    }
    try
    {
      if (this.http.getHeaderFields() != null) {
        localObject1 = this.http.getHeaderField(paramString);
      }
      return (String)localObject1;
    }
    catch (Exception paramString)
    {
      paramString.printStackTrace();
    }
    return null;
  }
  
  int _izHttpCFHTTPMessageGetResponseStatusCode()
  {
    int i = -1;
    if (this.http != null) {}
    try
    {
      i = this.http.getResponseCode();
      return i;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return -1;
  }
  
  /* Error */
  String _izHttpCFReadStreamCopyProperty()
  {
    // Byte code:
    //   0: aconst_null
    //   1: astore_2
    //   2: aconst_null
    //   3: astore_3
    //   4: aload_2
    //   5: astore_1
    //   6: aload_0
    //   7: getfield 583	jp/gungho/padEN/AppDelegate:http	Ljava/net/HttpURLConnection;
    //   10: ifnull +203 -> 213
    //   13: aload_2
    //   14: astore_1
    //   15: aload_0
    //   16: getfield 583	jp/gungho/padEN/AppDelegate:http	Ljava/net/HttpURLConnection;
    //   19: invokevirtual 1357	java/net/HttpURLConnection:getHeaderFields	()Ljava/util/Map;
    //   22: ifnull +191 -> 213
    //   25: new 685	java/lang/String
    //   28: dup
    //   29: ldc_w 472
    //   32: invokespecial 905	java/lang/String:<init>	(Ljava/lang/String;)V
    //   35: astore_1
    //   36: aload_0
    //   37: getfield 583	jp/gungho/padEN/AppDelegate:http	Ljava/net/HttpURLConnection;
    //   40: invokevirtual 1357	java/net/HttpURLConnection:getHeaderFields	()Ljava/util/Map;
    //   43: invokeinterface 1371 1 0
    //   48: invokeinterface 1377 1 0
    //   53: astore_3
    //   54: aload_3
    //   55: invokeinterface 1382 1 0
    //   60: ifeq +167 -> 227
    //   63: aload_3
    //   64: invokeinterface 1386 1 0
    //   69: checkcast 1388	java/util/Map$Entry
    //   72: astore 4
    //   74: new 675	java/lang/StringBuilder
    //   77: dup
    //   78: invokespecial 676	java/lang/StringBuilder:<init>	()V
    //   81: aload_1
    //   82: invokevirtual 702	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   85: aload 4
    //   87: invokeinterface 1391 1 0
    //   92: checkcast 685	java/lang/String
    //   95: invokevirtual 702	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   98: invokevirtual 712	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   101: astore_2
    //   102: aload_2
    //   103: astore_1
    //   104: aload 4
    //   106: invokeinterface 1394 1 0
    //   111: checkcast 1396	java/util/List
    //   114: invokeinterface 1397 1 0
    //   119: astore 4
    //   121: aload_2
    //   122: astore_1
    //   123: aload 4
    //   125: invokeinterface 1382 1 0
    //   130: ifeq +48 -> 178
    //   133: aload_2
    //   134: astore_1
    //   135: aload 4
    //   137: invokeinterface 1386 1 0
    //   142: checkcast 685	java/lang/String
    //   145: astore 5
    //   147: aload_2
    //   148: astore_1
    //   149: new 675	java/lang/StringBuilder
    //   152: dup
    //   153: invokespecial 676	java/lang/StringBuilder:<init>	()V
    //   156: aload_2
    //   157: invokevirtual 702	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   160: ldc_w 1399
    //   163: invokevirtual 702	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   166: aload 5
    //   168: invokevirtual 702	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   171: invokevirtual 712	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   174: astore_2
    //   175: goto -54 -> 121
    //   178: aload_2
    //   179: astore_1
    //   180: new 675	java/lang/StringBuilder
    //   183: dup
    //   184: invokespecial 676	java/lang/StringBuilder:<init>	()V
    //   187: aload_2
    //   188: invokevirtual 702	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   191: ldc_w 1401
    //   194: invokevirtual 702	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   197: invokevirtual 712	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   200: astore_2
    //   201: aload_2
    //   202: astore_1
    //   203: goto -149 -> 54
    //   206: astore_2
    //   207: aload_3
    //   208: astore_1
    //   209: aload_2
    //   210: invokevirtual 790	java/lang/Exception:printStackTrace	()V
    //   213: aload_1
    //   214: areturn
    //   215: astore_2
    //   216: goto -7 -> 209
    //   219: astore_2
    //   220: goto -11 -> 209
    //   223: astore_2
    //   224: goto -15 -> 209
    //   227: aload_1
    //   228: areturn
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	229	0	this	AppDelegate
    //   5	223	1	localObject1	Object
    //   1	201	2	str1	String
    //   206	4	2	localException1	Exception
    //   215	1	2	localException2	Exception
    //   219	1	2	localException3	Exception
    //   223	1	2	localException4	Exception
    //   3	205	3	localIterator	Iterator
    //   72	64	4	localObject2	Object
    //   145	22	5	str2	String
    // Exception table:
    //   from	to	target	type
    //   15	36	206	java/lang/Exception
    //   36	54	215	java/lang/Exception
    //   54	102	219	java/lang/Exception
    //   104	121	223	java/lang/Exception
    //   123	133	223	java/lang/Exception
    //   135	147	223	java/lang/Exception
    //   149	175	223	java/lang/Exception
    //   180	201	223	java/lang/Exception
  }
  
  void _izHttpExit()
  {
    _izHttpTerminateDownload();
  }
  
  int _izHttpGetContentLength()
  {
    int i = -1;
    if (this.http != null) {}
    try
    {
      i = this.mContentLength;
      return i;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return -1;
  }
  
  boolean _izHttpGetInitiate2(int paramInt, String paramString1, boolean paramBoolean1, String paramString2, String paramString3, boolean paramBoolean2)
  {
    this.mSize = paramInt;
    if (paramString1 != null) {
      this.mPurl = new String(paramString1);
    }
    this.mbBlock = paramBoolean1;
    if (paramString2 != null) {
      this.mPbuff = new String(paramString2);
    }
    if (paramString3 != null) {
      this.mPua = new String(paramString3);
    }
    this.mbGzip = paramBoolean2;
    if (this.http != null) {
      return false;
    }
    new Thread(new Runnable()
    {
      public void run()
      {
        for (;;)
        {
          try
          {
            AppDelegate.access$3402(AppDelegate.this, null);
            localObject = new URL(AppDelegate.this.mPurl);
            if (!AppDelegate.this.mPurl.startsWith("https")) {
              continue;
            }
            AppDelegate.access$3402(AppDelegate.this, (HttpsURLConnection)((URL)localObject).openConnection());
            if (AppDelegate.this.mPbuff == null) {
              continue;
            }
            AppDelegate.this.http.setRequestMethod("POST");
            AppDelegate.this.http.setDoOutput(true);
          }
          catch (Exception localException)
          {
            Object localObject;
            PrintStream localPrintStream;
            localException.printStackTrace();
            AppDelegate.this._izHttpTerminateDownload();
            AppDelegate.this.readStremCB(null, 8L, -1);
            continue;
            AppDelegate.this.http.setRequestMethod("GET");
            continue;
            AppDelegate.this.http.setRequestProperty("Accept-Encoding", "");
            continue;
          }
          localObject = new String(AppDelegate.this.mPua.getBytes("UTF8"), "UTF8");
          AppDelegate.this.http.setRequestProperty("User-Agent", (String)localObject);
          AppDelegate.this.http.setRequestProperty("Accept-Charset", "utf-8");
          AppDelegate.this.http.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
          if (!AppDelegate.this.mbGzip) {
            continue;
          }
          AppDelegate.this.http.setRequestProperty("Accept-Encoding", "gzip");
          if (AppDelegate.this.mPbuff != null)
          {
            localObject = new String(AppDelegate.this.mPbuff.getBytes("UTF8"), "UTF8");
            localPrintStream = new PrintStream(AppDelegate.this.http.getOutputStream());
            localPrintStream.print((String)localObject);
            localPrintStream.close();
          }
          AppDelegate.this.http.setReadTimeout(20000);
          AppDelegate.this.http.setConnectTimeout(20000);
          AppDelegate.this.http.setInstanceFollowRedirects(true);
          AppDelegate.this.http.connect();
          AppDelegate.access$3902(AppDelegate.this, AppDelegate.this.http.getInputStream());
          if (AppDelegate.this.http == null) {
            return;
          }
          AppDelegate.this._izHttpReadStremCB();
          continue;
          AppDelegate.access$3402(AppDelegate.this, (HttpURLConnection)((URL)localObject).openConnection());
        }
      }
    }).start();
    return true;
  }
  
  String _izHttpGetURLDecode(String paramString)
  {
    try
    {
      paramString = URLDecoder.decode(paramString, "UTF-8");
      return paramString;
    }
    catch (Exception paramString)
    {
      paramString.printStackTrace();
    }
    return null;
  }
  
  String _izHttpGetURLDecodeEscapes(String paramString1, String paramString2)
  {
    StringBuffer localStringBuffer = new StringBuffer("");
    if (paramString1 != null) {}
    for (;;)
    {
      int i;
      int j;
      try
      {
        m = paramString1.length();
        if (paramString2 == null) {
          break label151;
        }
        i = paramString2.length();
      }
      catch (Exception paramString1)
      {
        int m;
        String str2;
        int k;
        String str1;
        paramString1.printStackTrace();
      }
      if (j < m)
      {
        str2 = URLDecoder.decode(paramString1.substring(j, j + 1), "UTF-8");
        k = 0;
        str1 = str2;
        if (k < i)
        {
          if ((paramString2 != null) && (paramString1.substring(j, j + 1).equals(paramString2.substring(k, k + 1)))) {
            str1 = paramString1.substring(j, j + 1);
          }
        }
        else
        {
          localStringBuffer.append(str1);
          j += 1;
          continue;
        }
        k += 1;
      }
      else
      {
        return localStringBuffer.toString();
        label151:
        i = 0;
        j = 0;
      }
    }
  }
  
  String _izHttpGetURLEncode(String paramString)
  {
    try
    {
      paramString = URLEncoder.encode(paramString, "UTF-8");
      return paramString;
    }
    catch (Exception paramString)
    {
      paramString.printStackTrace();
    }
    return null;
  }
  
  String _izHttpGetURLEncodeEscapes(String paramString1, String paramString2)
  {
    StringBuffer localStringBuffer = new StringBuffer("");
    if (paramString1 != null) {}
    for (;;)
    {
      int i;
      int j;
      try
      {
        m = paramString1.length();
        if (paramString2 == null) {
          break label151;
        }
        i = paramString2.length();
      }
      catch (Exception paramString1)
      {
        int m;
        String str2;
        int k;
        String str1;
        paramString1.printStackTrace();
      }
      if (j < m)
      {
        str2 = URLEncoder.encode(paramString1.substring(j, j + 1), "UTF-8");
        k = 0;
        str1 = str2;
        if (k < i)
        {
          if ((paramString2 != null) && (paramString1.substring(j, j + 1).equals(paramString2.substring(k, k + 1)))) {
            str1 = paramString1.substring(j, j + 1);
          }
        }
        else
        {
          localStringBuffer.append(str1);
          j += 1;
          continue;
        }
        k += 1;
      }
      else
      {
        return localStringBuffer.toString();
        label151:
        i = 0;
        j = 0;
      }
    }
  }
  
  void _izHttpInit()
  {
    this.http = null;
    this.in = null;
  }
  
  public void _izHttpReadStremCB()
  {
    long l;
    if (this.in != null) {
      l = 0L;
    }
    try
    {
      int j = this.in.available();
      int i = j;
      if (j <= 0) {
        i = 4096;
      }
      byte[] arrayOfByte = new byte[i];
      i = this.in.read(arrayOfByte);
      if (i > 0) {
        l = 2L;
      }
      for (;;)
      {
        this.mContentLength = this.http.getContentLength();
        readStremCB(arrayOfByte, l, i);
        return;
        if (i == -1) {
          l = 16L;
        }
      }
      return;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
      _izHttpTerminateDownload();
      readStremCB(null, 8L, -1);
    }
  }
  
  void _izHttpTerminateDownload()
  {
    try
    {
      if (this.in != null)
      {
        this.in.close();
        this.in = null;
      }
    }
    catch (Exception localException1)
    {
      try
      {
        for (;;)
        {
          if (this.http != null)
          {
            this.http.disconnect();
            this.http = null;
          }
          this.mPurl = null;
          this.mPbuff = null;
          this.mPua = null;
          this.mContentLength = -1;
          System.gc();
          return;
          localException1 = localException1;
          this.in = null;
        }
      }
      catch (Exception localException2)
      {
        for (;;)
        {
          this.http = null;
        }
      }
    }
  }
  
  String _izHttpUrlDecode(String paramString)
  {
    try
    {
      paramString = URLDecoder.decode(paramString, "UTF-8");
      return paramString;
    }
    catch (UnsupportedEncodingException paramString)
    {
      paramString.printStackTrace();
    }
    return null;
  }
  
  String _izHttpUrlEncode(String paramString)
  {
    try
    {
      paramString = URLEncoder.encode(paramString, "UTF-8");
      return paramString;
    }
    catch (UnsupportedEncodingException paramString)
    {
      paramString.printStackTrace();
    }
    return null;
  }
  
  String _izLocStrings(String paramString)
  {
    return getResources().getString(Integer.parseInt(paramString));
  }
  
  void _izLocaleExit() {}
  
  void _izLocaleInit() {}
  
  void _izSbarChange(int paramInt, boolean paramBoolean) {}
  
  void _izSbarDisp(boolean paramBoolean1, boolean paramBoolean2)
  {
    if (paramBoolean1)
    {
      requestWindowFeature(1);
      getWindow().addFlags(1024);
      return;
    }
    requestWindowFeature(7);
    getWindow().clearFlags(1024);
  }
  
  int _izSbarStatusBarFrameHeight()
  {
    int i = 0;
    if (this.mView != null) {
      i = (int)this.mView.s();
    }
    return i;
  }
  
  boolean _izSbarStatusBarHidden()
  {
    return true;
  }
  
  int _izSbarStatusBarOrientation()
  {
    return getResources().getConfiguration().orientation;
  }
  
  void _izSbarStyle(int paramInt, boolean paramBoolean) {}
  
  int _izSndAvpCalc()
  {
    return this.audioPlayer.d();
  }
  
  void _izSndAvpExecPause(boolean paramBoolean)
  {
    if (paramBoolean)
    {
      this.audioPlayer.g();
      return;
    }
    this.audioPlayer.a(this.mFocus);
  }
  
  boolean _izSndAvpExecStop()
  {
    return this.audioPlayer.f();
  }
  
  boolean _izSndAvpIsPlaying()
  {
    return this.audioPlayer.i();
  }
  
  boolean _izSndAvpIsRunning()
  {
    return this.audioPlayer.h();
  }
  
  boolean _izSndAvpPlay(boolean paramBoolean)
  {
    return this.audioPlayer.e();
  }
  
  boolean _izSndAvpPrepareExists(String paramString)
  {
    try
    {
      getAssets().openFd(paramString).close();
      return true;
    }
    catch (Exception paramString)
    {
      paramString.printStackTrace();
    }
    return false;
  }
  
  void _izSndAvpPreparePlay(String paramString, boolean paramBoolean1, float paramFloat, boolean paramBoolean2)
  {
    this.audioPlayer.a(paramString, paramBoolean1, paramFloat, paramBoolean2);
  }
  
  void _izSndAvpRelease()
  {
    this.audioPlayer.c();
  }
  
  void _izSndAvpSetVolume(float paramFloat)
  {
    this.audioPlayer.a(paramFloat);
  }
  
  void _izSndSeExit()
  {
    if (this.sndPool != null)
    {
      int i = 0;
      while (i < this.maxGroup)
      {
        this.sndPoolState[i] = null;
        this.sndPoolStopTime[i] = null;
        this.sndPlayTime[i] = null;
        this.sndPoolId[i] = null;
        i += 1;
      }
      this.sndPool.release();
      this.sndPool = null;
    }
    this.sndPoolState = ((int[][])null);
    this.sndPoolStopTime = ((long[][])null);
    this.sndPlayTime = ((long[][])null);
    this.sndPoolId = ((int[][])null);
    System.gc();
  }
  
  void _izSndSeList(int[] paramArrayOfInt)
  {
    int i = 0;
    while (i < this.maxGroup)
    {
      this.maxStream[i] = paramArrayOfInt[i];
      this.sndPoolState[i] = new int['Ā'];
      int j = 0;
      while (j < 256)
      {
        this.sndPoolState[i][j] = 'ထ';
        j += 1;
      }
      this.sndPoolStopTime[i] = new long['Ā'];
      this.sndPlayTime[i] = new long['Ā'];
      this.sndPoolId[i] = new int['Ā'];
      i += 1;
    }
  }
  
  void _izSndSePolyGroup(int paramInt)
  {
    this.sndPool = new SoundPool(4, 3, 0);
    this.sndPoolState = new int[paramInt][];
    this.sndPoolStopTime = new long[paramInt][];
    this.sndPlayTime = new long[paramInt][];
    this.sndPoolId = new int[paramInt][];
    this.maxStream = new int[paramInt];
    this.maxGroup = paramInt;
  }
  
  void _izSndSeUnload(int paramInt)
  {
    if (this.sndPool != null)
    {
      this.sndPlayTime[paramInt] = null;
      this.sndPool.release();
      this.sndPool = null;
    }
  }
  
  int _seLoadMain(int paramInt1, int paramInt2, String paramString, int paramInt3, long paramLong1, long paramLong2, int paramInt4)
  {
    try
    {
      if (this.sndPool == null)
      {
        this.sndPool = new SoundPool(4, 3, 0);
        int i = 0;
        while (i < 256)
        {
          this.sndPoolState[paramInt1][i] = 'ထ';
          i += 1;
        }
      }
      paramInt3 = this.sndPool.load(getApplicationContext(), 2131427328 + paramInt3, 1);
      paramString.printStackTrace();
    }
    catch (Exception paramString)
    {
      try
      {
        this.sndPoolId[paramInt1][paramInt2] = paramInt3;
        this.sndPlayTime[paramInt1][paramInt2] = paramInt4;
        return paramInt3;
      }
      catch (Exception paramString)
      {
        for (;;) {}
      }
      paramString = paramString;
      paramInt3 = -1;
    }
    return paramInt3;
  }
  
  boolean _verifyCert(byte[] paramArrayOfByte)
  {
    try
    {
      paramArrayOfByte = new ByteArrayInputStream(paramArrayOfByte);
      paramArrayOfByte = (X509Certificate)CertificateFactory.getInstance("X.509").generateCertificate(paramArrayOfByte);
      if (Build.VERSION.SDK_INT >= 14)
      {
        KeyStore localKeyStore = KeyStore.getInstance("AndroidCAStore");
        localKeyStore.load(null, null);
        TrustManagerFactory localTrustManagerFactory = TrustManagerFactory.getInstance("X509");
        localTrustManagerFactory.init(localKeyStore);
        ((X509TrustManager)localTrustManagerFactory.getTrustManagers()[0]).checkClientTrusted(new X509Certificate[] { paramArrayOfByte }, "RSA");
        return true;
      }
      return false;
    }
    catch (Exception paramArrayOfByte)
    {
      paramArrayOfByte.toString();
      paramArrayOfByte.printStackTrace();
    }
    return false;
  }
  
  int addNumberField(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, String paramString1, String paramString2, int paramInt6)
  {
    Message localMessage = handler.obtainMessage();
    Bundle localBundle = new Bundle();
    this.inNumberOnly = true;
    this.inEditing = false;
    this.maxTextLeng = paramInt6;
    d locald = new d(appDelegate);
    paramInt6 = locald.hashCode();
    this.pTextFields.add(locald);
    localBundle.putInt("hash", paramInt6);
    localBundle.putInt("x", paramInt1);
    localBundle.putInt("y", paramInt2);
    localBundle.putInt("w", paramInt3);
    localBundle.putInt("h", paramInt4);
    localBundle.putInt("minimumFontSize", paramInt5);
    localBundle.putString("text", paramString1);
    localBundle.putString("placeholder", paramString2);
    localBundle.putInt("keyboardType", 4);
    localMessage.what = 1;
    localMessage.setData(localBundle);
    handler.sendMessage(localMessage);
    return paramInt6;
  }
  
  int addTextField(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, String paramString1, String paramString2, int paramInt6)
  {
    Message localMessage = handler.obtainMessage();
    Bundle localBundle = new Bundle();
    this.inNumberOnly = false;
    this.inEditing = false;
    this.maxTextLeng = paramInt6;
    d locald = new d(appDelegate);
    paramInt6 = locald.hashCode();
    this.pTextFields.add(locald);
    localBundle.putInt("hash", paramInt6);
    localBundle.putInt("x", paramInt1);
    localBundle.putInt("y", paramInt2);
    localBundle.putInt("w", paramInt3);
    localBundle.putInt("h", paramInt4);
    localBundle.putInt("minimumFontSize", paramInt5);
    localBundle.putString("text", paramString1);
    localBundle.putString("placeholder", paramString2);
    localBundle.putInt("keyboardType", 0);
    localMessage.what = 0;
    localMessage.setData(localBundle);
    handler.sendMessage(localMessage);
    return paramInt6;
  }
  
  void addWebView(int paramInt1, int paramInt2, int paramInt3, int paramInt4, String paramString)
  {
    this.bWebLoaded = false;
    if (this.pUiWebView == null)
    {
      Message localMessage = handler.obtainMessage();
      Bundle localBundle = new Bundle();
      localBundle.putInt("x", paramInt1);
      localBundle.putInt("y", paramInt2);
      localBundle.putInt("w", paramInt3);
      localBundle.putInt("h", paramInt4);
      localBundle.putString("url", paramString);
      localMessage.what = 10;
      localMessage.setData(localBundle);
      handler.sendMessage(localMessage);
    }
  }
  
  public void appRestart()
  {
    setSystemUiVisilityMode();
    Intent localIntent = new Intent(this, AppDelegate.class);
    finish();
    if ((getViewInitFlag()) && (!this.mPaused))
    {
      applicationWillTerminate(true);
      this.mPaused = true;
    }
    startActivity(localIntent);
    System.gc();
  }
  
  public native void applicationDidBecomeActive();
  
  public native void applicationDidEnterBackground();
  
  public native void applicationWillEnterForeground();
  
  public native void applicationWillResignActive();
  
  public native void applicationWillTerminate(boolean paramBoolean);
  
  String bundleIdentifier()
  {
    return getApplicationContext().getPackageName().toLowerCase();
  }
  
  void cASYNCLOADER_main(int paramInt, String paramString)
  {
    new b(paramInt, paramString).start();
  }
  
  void cBGDLMAN_addDownload(int paramInt1, int paramInt2, String paramString1, String paramString2, int paramInt3, int paramInt4, int paramInt5)
  {
    if (this.pBgDlMan != null) {
      this.pBgDlMan.a(paramInt1, paramInt2, paramString1, paramString2, paramInt3, paramInt4, paramInt5);
    }
  }
  
  void cBGDLMAN_buildList(int paramInt)
  {
    if (this.pBgDlMan == null) {
      this.pBgDlMan = new f(this);
    }
    for (;;)
    {
      if (!this.pBgDlMan.o) {
        this.pBgDlMan.start();
      }
      this.pBgDlMan.a(paramInt);
      return;
      if (!this.pBgDlMan.o)
      {
        this.pBgDlMan = null;
        this.pBgDlMan = new f(this);
      }
    }
  }
  
  void cBGDLMAN_enterBackground()
  {
    if (this.pBgDlMan != null) {
      this.pBgDlMan.b();
    }
  }
  
  void cBGDLMAN_execMainThread()
  {
    if (this.pBgDlMan != null) {
      this.pBgDlMan.start();
    }
  }
  
  void cBGDLMAN_freeList()
  {
    if (this.pBgDlMan != null) {
      this.pBgDlMan.d();
    }
  }
  
  float cBGDLMAN_getEstimatedSeconds()
  {
    float f = 0.0F;
    if (this.pBgDlMan != null) {
      f = this.pBgDlMan.f();
    }
    return f;
  }
  
  int cBGDLMAN_getLeftFiles()
  {
    int i = 0;
    if (this.pBgDlMan != null) {
      i = this.pBgDlMan.i();
    }
    return i;
  }
  
  int cBGDLMAN_getLeftPercent()
  {
    int i = 0;
    if (this.pBgDlMan != null) {
      i = this.pBgDlMan.g();
    }
    return i;
  }
  
  float cBGDLMAN_getLeftPercentf()
  {
    float f = 0.0F;
    if (this.pBgDlMan != null) {
      f = this.pBgDlMan.h();
    }
    return f;
  }
  
  int cBGDLMAN_howManyRemaining()
  {
    int i = 0;
    if (this.pBgDlMan != null) {
      i = this.pBgDlMan.j();
    }
    return i;
  }
  
  void cBGDLMAN_init()
  {
    if (this.pBgDlMan != null) {
      this.pBgDlMan = null;
    }
    this.pBgDlMan = new f(this);
  }
  
  void cBGDLMAN_restoreFromBackground()
  {
    if (this.pBgDlMan != null) {
      this.pBgDlMan.c();
    }
  }
  
  void cFULLHTML_flipIn()
  {
    if (this.pHTMLVIEW != null)
    {
      Message localMessage = handler.obtainMessage();
      localMessage.what = 18;
      handler.sendMessage(localMessage);
    }
  }
  
  void cFULLHTML_init()
  {
    if (this.pHTMLVIEW == null) {
      return;
    }
    this.pHTMLVIEW.a();
  }
  
  void cFULLHTML_initWithTitle(String paramString1, String paramString2)
  {
    if (this.pHTMLVIEW == null) {
      return;
    }
    Message localMessage = handler.obtainMessage();
    Bundle localBundle = new Bundle();
    localBundle.putString("url", paramString1);
    localBundle.putString("title", paramString2);
    localMessage.what = 17;
    localMessage.setData(localBundle);
    handler.sendMessage(localMessage);
  }
  
  boolean cFULLHTML_isRunning()
  {
    if (this.pHTMLVIEW == null) {
      return false;
    }
    return this.pHTMLVIEW.b();
  }
  
  void cFULLHTML_release()
  {
    if (this.pHTMLVIEW != null)
    {
      Message localMessage = handler.obtainMessage();
      localMessage.what = 19;
      handler.sendMessage(localMessage);
    }
  }
  
  void cMAILEDIT_flipIn()
  {
    if (this.pMEDIT != null)
    {
      Message localMessage = handler.obtainMessage();
      localMessage.what = 7;
      handler.sendMessage(localMessage);
    }
  }
  
  String cMAILEDIT_getInputText()
  {
    if (this.pMEDIT == null) {
      return null;
    }
    return this.pMEDIT.e();
  }
  
  boolean cMAILEDIT_getbInEdit()
  {
    if (this.pMEDIT == null) {
      return false;
    }
    return this.pMEDIT.g();
  }
  
  boolean cMAILEDIT_getbSend()
  {
    if (this.pMEDIT == null) {
      return false;
    }
    return this.pMEDIT.f();
  }
  
  void cMAILEDIT_init()
  {
    if (this.pMEDIT == null) {
      return;
    }
    this.pMEDIT.a();
  }
  
  void cMAILEDIT_release()
  {
    if (this.pMEDIT != null)
    {
      Message localMessage = handler.obtainMessage();
      localMessage.what = 8;
      handler.sendMessage(localMessage);
    }
  }
  
  void cMAILEDIT_setMailTo(String paramString1, String paramString2, String paramString3, String paramString4)
  {
    if (this.pMEDIT == null) {
      return;
    }
    this.pMEDIT.a(paramString1, paramString2, paramString3, paramString4);
  }
  
  long cTIMER_elapsedRealtime()
  {
    return SystemClock.elapsedRealtime();
  }
  
  long cTIMER_uptimeMillis()
  {
    return SystemClock.uptimeMillis();
  }
  
  void callSystemGc() {}
  
  void cancelStaminaNotif()
  {
    if (this.notification != null) {
      this.notification.a();
    }
  }
  
  void changeSecure(boolean paramBoolean)
  {
    if (_izDevGetBuild_SDK_INT() > 16)
    {
      Message localMessage = handler.obtainMessage();
      localMessage.what = 33;
      handler.sendMessage(localMessage);
      this.isSecure = paramBoolean;
      this.mView.a(8);
    }
  }
  
  void checkRewardTransactions()
  {
    Message localMessage = handler.obtainMessage();
    localMessage.what = 40;
    handler.sendMessage(localMessage);
  }
  
  public int checkRoot()
  {
    int k = 0;
    String[] arrayOfString = new String[2];
    arrayOfString[0] = "com.noshufou.android.su";
    arrayOfString[1] = "eu.chainfire.supersu";
    int i;
    try
    {
      Runtime.getRuntime().exec("su").destroy();
      return 2;
    }
    catch (IOException localIOException)
    {
      i = 0;
    }
    for (;;)
    {
      int j = k;
      if (i < arrayOfString.length) {}
      try
      {
        getPackageManager().getApplicationInfo(arrayOfString[i], 0);
        j = 1;
        localIOException.printStackTrace();
        return j;
      }
      catch (Exception localException)
      {
        localException.printStackTrace();
        i += 1;
      }
    }
  }
  
  /* Error */
  boolean checkTool()
  {
    // Byte code:
    //   0: iconst_4
    //   1: anewarray 685	java/lang/String
    //   4: astore 5
    //   6: aload 5
    //   8: iconst_0
    //   9: ldc_w 1851
    //   12: aastore
    //   13: aload 5
    //   15: iconst_1
    //   16: ldc_w 1853
    //   19: aastore
    //   20: aload 5
    //   22: iconst_2
    //   23: ldc_w 1855
    //   26: aastore
    //   27: aload 5
    //   29: iconst_3
    //   30: ldc_w 1857
    //   33: aastore
    //   34: aload_0
    //   35: getfield 410	jp/gungho/padEN/AppDelegate:isAlartDialog	Z
    //   38: ifeq +5 -> 43
    //   41: iconst_1
    //   42: ireturn
    //   43: aload_0
    //   44: ldc_w 1859
    //   47: invokevirtual 941	jp/gungho/padEN/AppDelegate:getSystemService	(Ljava/lang/String;)Ljava/lang/Object;
    //   50: checkcast 1861	android/app/ActivityManager
    //   53: invokevirtual 1865	android/app/ActivityManager:getRunningAppProcesses	()Ljava/util/List;
    //   56: astore 4
    //   58: aload 4
    //   60: ifnull +127 -> 187
    //   63: aload 4
    //   65: invokeinterface 1397 1 0
    //   70: astore 6
    //   72: iconst_0
    //   73: istore_2
    //   74: iload_2
    //   75: istore_3
    //   76: aload 6
    //   78: invokeinterface 1382 1 0
    //   83: ifeq +21 -> 104
    //   86: aload 6
    //   88: invokeinterface 1386 1 0
    //   93: checkcast 1867	android/app/ActivityManager$RunningAppProcessInfo
    //   96: astore 4
    //   98: iload_2
    //   99: ifeq +7 -> 106
    //   102: iload_2
    //   103: istore_3
    //   104: iload_3
    //   105: ireturn
    //   106: iconst_0
    //   107: istore_1
    //   108: iload_2
    //   109: istore_3
    //   110: iload_1
    //   111: aload 5
    //   113: arraylength
    //   114: if_icmpge +44 -> 158
    //   117: aload 4
    //   119: getfield 1870	android/app/ActivityManager$RunningAppProcessInfo:processName	Ljava/lang/String;
    //   122: aload 5
    //   124: iload_1
    //   125: aaload
    //   126: invokevirtual 1087	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   129: ifeq +34 -> 163
    //   132: aload_0
    //   133: aload_0
    //   134: ldc_w 1871
    //   137: invokevirtual 1872	jp/gungho/padEN/AppDelegate:getString	(I)Ljava/lang/String;
    //   140: aload_0
    //   141: ldc_w 1873
    //   144: invokevirtual 1872	jp/gungho/padEN/AppDelegate:getString	(I)Ljava/lang/String;
    //   147: iconst_0
    //   148: invokevirtual 1877	jp/gungho/padEN/AppDelegate:openAlertDialog	(Ljava/lang/String;Ljava/lang/String;I)V
    //   151: aload_0
    //   152: iconst_1
    //   153: putfield 410	jp/gungho/padEN/AppDelegate:isAlartDialog	Z
    //   156: iconst_1
    //   157: istore_3
    //   158: iload_3
    //   159: istore_2
    //   160: goto -86 -> 74
    //   163: iload_1
    //   164: iconst_1
    //   165: iadd
    //   166: istore_1
    //   167: goto -59 -> 108
    //   170: astore 4
    //   172: aload 4
    //   174: invokevirtual 790	java/lang/Exception:printStackTrace	()V
    //   177: goto -17 -> 160
    //   180: astore 4
    //   182: iconst_1
    //   183: istore_2
    //   184: goto -12 -> 172
    //   187: iconst_0
    //   188: istore_3
    //   189: goto -85 -> 104
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	192	0	this	AppDelegate
    //   107	60	1	i	int
    //   73	111	2	bool1	boolean
    //   75	114	3	bool2	boolean
    //   56	62	4	localObject	Object
    //   170	3	4	localException1	Exception
    //   180	1	4	localException2	Exception
    //   4	119	5	arrayOfString	String[]
    //   70	17	6	localIterator	Iterator
    // Exception table:
    //   from	to	target	type
    //   110	151	170	java/lang/Exception
    //   151	156	180	java/lang/Exception
  }
  
  void chgTextFieldMag(int paramInt, float paramFloat1, float paramFloat2)
  {
    d locald = getTextField(paramInt);
    if ((locald != null) && (locald.a != null) && (locald.a.getVisibility() != 0))
    {
      Message localMessage = handler.obtainMessage();
      Bundle localBundle = new Bundle();
      localBundle.putInt("hash", paramInt);
      localBundle.putFloat("xmag", paramFloat1);
      localBundle.putFloat("ymag", paramFloat2);
      localBundle.putInt("x", locald.a.getLeft());
      localBundle.putInt("y", locald.a.getTop());
      localBundle.putInt("w", locald.a.getWidth());
      localBundle.putInt("h", locald.a.getHeight());
      localMessage.what = 4;
      localMessage.setData(localBundle);
      handler.sendMessage(localMessage);
    }
  }
  
  void chgTextFieldPos(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    Object localObject = getTextField(paramInt1);
    if ((localObject != null) && (((d)localObject).a != null) && ((((d)localObject).a.getLeft() != paramInt2) || (((d)localObject).a.getTop() != paramInt3)))
    {
      localObject = handler.obtainMessage();
      Bundle localBundle = new Bundle();
      localBundle.putInt("hash", paramInt1);
      localBundle.putInt("x", paramInt2);
      localBundle.putInt("y", paramInt3);
      localBundle.putInt("w", paramInt4);
      localBundle.putInt("h", paramInt5);
      ((Message)localObject).what = 3;
      ((Message)localObject).setData(localBundle);
      handler.sendMessage((Message)localObject);
    }
  }
  
  public native void clearBgColor();
  
  public native void completeTransaction();
  
  void consumeFinished(g paramg)
  {
    paramg = handler.obtainMessage(21, paramg);
    handler.sendMessage(paramg);
  }
  
  void copyToClipboard(String paramString)
  {
    Message localMessage = handler.obtainMessage();
    Bundle localBundle = new Bundle();
    localBundle.putString("string", paramString);
    localMessage.what = 20;
    localMessage.setData(localBundle);
    handler.sendMessage(localMessage);
  }
  
  void dataInstall()
  {
    if (isSelfPermission("android.permission.WRITE_EXTERNAL_STORAGE"))
    {
      this.recv = 0;
      new Thread(new Runnable()
      {
        public void run()
        {
          Object localObject5 = null;
          Object localObject1 = null;
          localObject7 = new String[3];
          localObject7[0] = AppDelegate.this.getFileName1();
          localObject7[1] = AppDelegate.this.getFileName2();
          localObject7[2] = AppDelegate.this.getFileName3();
          byte[] arrayOfByte = new byte['Ѐ'];
          AssetManager localAssetManager = AppDelegate.this.getResources().getAssets();
          for (;;)
          {
            try
            {
              localObject4 = new File(AppDelegate.this.getInstallPath());
              if (!((File)localObject4).exists()) {
                ((File)localObject4).mkdirs();
              }
              i = 0;
              localObject4 = null;
              localObject5 = localObject1;
              try
              {
                if (i >= localObject7.length) {
                  continue;
                }
                str = AppDelegate.this.getInstallPath() + localObject7[i];
                if (str != null) {
                  continue;
                }
                throw new Exception("Illigal Install path " + str);
              }
              catch (Throwable localThrowable1) {}
            }
            catch (Throwable localThrowable3)
            {
              int i;
              String str;
              int j;
              int m;
              Object localObject4 = null;
              continue;
              continue;
              continue;
              j += m;
              continue;
            }
            localThrowable1.printStackTrace();
            if (localObject4 != null) {}
            try
            {
              ((InputStream)localObject4).close();
              if (localObject5 != null) {
                ((DataOutputStream)localObject5).close();
              }
            }
            catch (Throwable localThrowable2)
            {
              Object localObject2;
              continue;
            }
            if (AppDelegate.this.isSelfPermission("android.permission.WRITE_EXTERNAL_STORAGE"))
            {
              AppDelegate.access$4302(AppDelegate.this, 2);
              return;
              localObject2 = new File(str);
              if (!((File)localObject2).exists())
              {
                ((File)localObject2).setWritable(true);
                ((File)localObject2).createNewFile();
              }
              localObject2 = localAssetManager.open(localObject7[i]);
            }
            try
            {
              int k = ((InputStream)localObject2).available();
              localObject4 = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(str)));
              j = 0;
              if (k > j) {}
              try
              {
                m = ((InputStream)localObject2).read(arrayOfByte, 0, arrayOfByte.length);
                if (m <= 0) {
                  continue;
                }
                ((DataOutputStream)localObject4).write(arrayOfByte, 0, m);
                ((DataOutputStream)localObject4).flush();
              }
              catch (Throwable localThrowable4)
              {
                localObject7 = localThrowable3;
                localObject3 = localThrowable4;
                Object localObject6 = localObject4;
                localObject4 = localObject7;
              }
              ((InputStream)localObject2).close();
              ((DataOutputStream)localObject4).close();
              i += 1;
              localObject5 = localObject4;
              localObject4 = localObject2;
            }
            catch (Throwable localThrowable5)
            {
              localObject4 = localObject3;
              Object localObject3 = localThrowable5;
            }
          }
          AppDelegate.access$4302(AppDelegate.this, 3);
          return;
          AppDelegate.access$4302(AppDelegate.this, 1);
        }
      }).start();
      return;
    }
    this.recv = 3;
  }
  
  boolean dataInstallCheck()
  {
    bool = true;
    String[] arrayOfString = new String[3];
    arrayOfString[0] = getFileName1();
    arrayOfString[1] = getFileName2();
    arrayOfString[2] = getFileName3();
    AssetManager localAssetManager = getResources().getAssets();
    Object localObject = getInternalPath();
    if (localObject == null) {
      return false;
    }
    localObject = new StatFs((String)localObject);
    long l2 = ((StatFs)localObject).getAvailableBlocks();
    long l3 = ((StatFs)localObject).getBlockSize();
    long l1 = 0L;
    int i = 0;
    try
    {
      while (i < arrayOfString.length)
      {
        localObject = localAssetManager.open(arrayOfString[i]);
        l1 += ((InputStream)localObject).available();
        ((InputStream)localObject).close();
        i += 1;
      }
      if (l1 > l2 * l3) {
        bool = false;
      }
    }
    catch (Throwable localThrowable)
    {
      for (;;)
      {
        bool = false;
        continue;
        this.recv = 0;
        requestPermissions("android.permission.WRITE_EXTERNAL_STORAGE", 2);
      }
    }
    if (bool)
    {
      if (isSelfPermission("android.permission.WRITE_EXTERNAL_STORAGE")) {
        dataInstall();
      }
    }
    else {
      return bool;
    }
  }
  
  boolean dataInstallFileExist(String paramString)
  {
    String[] arrayOfString = new String[3];
    arrayOfString[0] = getFileName1();
    arrayOfString[1] = getFileName2();
    arrayOfString[2] = getFileName3();
    boolean bool1 = isPathExist(paramString);
    int i = 0;
    boolean bool2;
    for (;;)
    {
      bool2 = bool1;
      try
      {
        if (i < arrayOfString.length)
        {
          bool2 = new File(paramString + arrayOfString[i]).exists();
          if (!bool2) {
            bool1 = false;
          }
          i += 1;
        }
      }
      catch (Throwable paramString)
      {
        paramString.printStackTrace();
        bool2 = false;
      }
    }
    return bool2;
  }
  
  boolean dataInstallUpdateCheck()
  {
    boolean bool1 = true;
    boolean bool2 = loadDataInstallUpdateCheck();
    if (bool2)
    {
      String[] arrayOfString = new String[3];
      arrayOfString[0] = getFileName1();
      arrayOfString[1] = getFileName2();
      arrayOfString[2] = getFileName3();
      AssetManager localAssetManager = getResources().getAssets();
      Object localObject = getInternalPath();
      if (localObject == null) {}
      do
      {
        return false;
        localObject = new StatFs((String)localObject);
        long l2 = ((StatFs)localObject).getAvailableBlocks();
        long l3 = ((StatFs)localObject).getBlockSize();
        long l1 = 0L;
        int i = 0;
        try
        {
          while (i < arrayOfString.length)
          {
            localObject = localAssetManager.open(arrayOfString[i]);
            l1 += ((InputStream)localObject).available();
            ((InputStream)localObject).close();
            i += 1;
          }
          if (l1 > l2 * l3) {
            bool1 = false;
          }
        }
        catch (Throwable localThrowable)
        {
          for (;;)
          {
            bool1 = false;
          }
        }
        if (!bool1) {
          break;
        }
      } while (!isSelfPermission("android.permission.WRITE_EXTERNAL_STORAGE"));
      dataInstall();
      return bool1;
      return bool1;
    }
    return bool2;
  }
  
  public native void dataRecovery();
  
  void dataUninstall()
  {
    try
    {
      deleteInstallFile(getInternalPath());
      return;
    }
    catch (Throwable localThrowable)
    {
      localThrowable.printStackTrace();
    }
  }
  
  void delTextField(int paramInt)
  {
    if (paramInt != 0)
    {
      Message localMessage = handler.obtainMessage();
      Bundle localBundle = new Bundle();
      localBundle.putInt("hash", paramInt);
      localMessage.what = 2;
      localMessage.setData(localBundle);
      handler.sendMessage(localMessage);
    }
  }
  
  void delWebView()
  {
    if ((this.pUiWebView != null) && (this.pUiWebView.getVisibility() != 8))
    {
      Message localMessage = handler.obtainMessage();
      localMessage.what = 11;
      handler.sendMessage(localMessage);
    }
  }
  
  public void deleteBootSharedPreferences()
  {
    try
    {
      getSharedPreferences("data076").edit().remove("bootcheck").commit();
      return;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
  }
  
  void deleteInstallFile(String paramString)
  {
    int i = 0;
    String[] arrayOfString = new String[3];
    arrayOfString[0] = getFileName1();
    arrayOfString[1] = getFileName2();
    arrayOfString[2] = getFileName3();
    for (;;)
    {
      try
      {
        if (i < arrayOfString.length)
        {
          File localFile = new File(paramString + arrayOfString[i]);
          if (!localFile.exists()) {
            break label89;
          }
          localFile.delete();
        }
      }
      catch (Throwable paramString)
      {
        paramString.printStackTrace();
      }
      return;
      label89:
      i += 1;
    }
  }
  
  public void deleteSharedPreferences(String paramString1, String paramString2)
  {
    try
    {
      getSharedPreferences(paramString1).edit().remove(paramString2).commit();
      return;
    }
    catch (Exception paramString1)
    {
      paramString1.printStackTrace();
    }
  }
  
  public native void didFinishLaunchingWithOptions();
  
  public boolean dispatchKeyEvent(KeyEvent paramKeyEvent)
  {
    int i = paramKeyEvent.getKeyCode();
    int j = paramKeyEvent.getAction();
    int k = paramKeyEvent.getFlags();
    long l = paramKeyEvent.getEventTime();
    if (getViewInitFlag())
    {
      boolean bool1;
      if ((k & 0x2) == 2) {
        bool1 = super.dispatchKeyEvent(paramKeyEvent);
      }
      boolean bool2;
      do
      {
        return bool1;
        if ((cFULLHTML_isRunning()) && (i == 4) && (j == 0))
        {
          this.pHTMLVIEW.e();
          return false;
        }
        bool2 = onKeyEvent(i, j, l);
        bool1 = bool2;
      } while (bool2);
      return super.dispatchKeyEvent(paramKeyEvent);
    }
    if ((getViewInitState() > 0) && (i == 4)) {
      return true;
    }
    return super.dispatchKeyEvent(paramKeyEvent);
  }
  
  byte[] drawSysFont(String paramString, float paramFloat1, float paramFloat2)
  {
    try
    {
      Bitmap localBitmap = Bitmap.createBitmap(this.mSysFontWidth, this.mSysFontHeight, this.mSysFontConfig);
      this.canvas = null;
      this.canvas = new Canvas(localBitmap);
      paint.setAntiAlias(true);
      this.canvas.drawText(paramString, paramFloat1, paint.getTextSize() - paramFloat2, paint);
      paramString = ByteBuffer.allocate(localBitmap.getWidth() * localBitmap.getHeight() * 4);
      paramString.order(ByteOrder.nativeOrder());
      localBitmap.copyPixelsToBuffer(paramString);
      paramString.position(0);
      localBitmap.recycle();
      paramString = paramString.array();
      return paramString;
    }
    catch (Exception paramString)
    {
      paramString.printStackTrace();
    }
    return null;
  }
  
  public native void enableRewardCheck(boolean paramBoolean);
  
  void eraseKeyboard(int paramInt)
  {
    Object localObject = getTextField(paramInt);
    if ((localObject != null) && (((d)localObject).a != null))
    {
      localObject = handler.obtainMessage();
      Bundle localBundle = new Bundle();
      localBundle.putInt("hash", paramInt);
      ((Message)localObject).what = 35;
      ((Message)localObject).setData(localBundle);
      handler.sendMessage((Message)localObject);
    }
  }
  
  void fadeTextField(int paramInt, float paramFloat)
  {
    Object localObject = getTextField(paramInt);
    if ((localObject != null) && (((d)localObject).a != null))
    {
      localObject = handler.obtainMessage();
      Bundle localBundle = new Bundle();
      localBundle.putFloat("alpha", paramFloat);
      localBundle.putInt("hash", paramInt);
      ((Message)localObject).what = 36;
      ((Message)localObject).setData(localBundle);
      handler.sendMessage((Message)localObject);
    }
  }
  
  public native void failedTransaction(int paramInt1, int paramInt2);
  
  void finishTutorial(String paramString)
  {
    Bundle localBundle = new Bundle();
    localBundle.putString("event", "tutorialComplete");
    localBundle.putString("userId", paramString);
    AppEventsLogger.newLogger(this).logEvent("fb_mobile_tutorial_completion", localBundle);
    Tracker.sendEvent(new Tracker.Event(10).setUserId(paramString));
  }
  
  public String getAccountName()
  {
    return this.accountName;
  }
  
  public String getAdID()
  {
    return jp.gungho.a.a.b();
  }
  
  public int getAdTrackingEnabled()
  {
    return jp.gungho.a.a.a();
  }
  
  public native String getApiReqShopStoneBuff();
  
  public native String getApiReqShopStoneRewardUrl();
  
  public native String getApiReqShopStoneUrl();
  
  public int getAuthState()
  {
    return this.authState;
  }
  
  boolean getBroadcastReceiver()
  {
    return this.isBroadcastReceiv;
  }
  
  float getDispHeight()
  {
    return this.dispHeight;
  }
  
  float getDispLeft()
  {
    float f = 0.0F;
    if (this.mView != null) {
      f = (getDispWidth() - this.mView.m()) / 2.0F;
    }
    return f;
  }
  
  float getDispTop()
  {
    float f = 0.0F;
    if (this.mView != null) {
      f = this.mView.g() + this.mView.q() * 2.0F;
    }
    return f;
  }
  
  public int getDispType()
  {
    int i = 0;
    if (getViewInitFlag()) {
      i = this.mView.r();
    }
    return i;
  }
  
  float getDispWidth()
  {
    return this.dispWidth;
  }
  
  Point getDisplayMetrics()
  {
    Point localPoint = new Point();
    DisplayMetrics localDisplayMetrics = new DisplayMetrics();
    getWindowManager().getDefaultDisplay().getMetrics(localDisplayMetrics);
    localPoint.set(localDisplayMetrics.widthPixels, localDisplayMetrics.heightPixels);
    return localPoint;
  }
  
  Point getDisplaySize()
  {
    Point localPoint = new Point();
    getWindowManager().getDefaultDisplay().getSize(localPoint);
    return localPoint;
  }
  
  public native String getExtFilePath();
  
  String getExternalPath()
  {
    try
    {
      String str = Environment.getExternalStorageDirectory().getCanonicalPath() + "/";
      return str;
    }
    catch (Exception localException) {}
    return null;
  }
  
  public String getFacebookAccessToken()
  {
    if (isLoggedInFacebook()) {
      return this.mFbAccessToken.getToken();
    }
    return null;
  }
  
  public String getFacebookUserID()
  {
    if ((isLoggedInFacebook()) && (this.mFbAccessToken != null)) {
      return this.mFbAccessToken.getUserId();
    }
    return null;
  }
  
  public String getFacebookUserName()
  {
    if (isLoggedInFacebook())
    {
      Profile localProfile = Profile.getCurrentProfile();
      if (localProfile != null) {
        return localProfile.getName();
      }
    }
    return null;
  }
  
  public native String getFileName1();
  
  public native String getFileName2();
  
  public native String getFileName3();
  
  public native String getFolderForFilePath(String paramString);
  
  int getHeight()
  {
    return (int)(Math.abs(font.top) + Math.abs(font.bottom));
  }
  
  String getInstallPath()
  {
    try
    {
      String str = getInternalPath();
      return str;
    }
    catch (Throwable localThrowable)
    {
      localThrowable.printStackTrace();
    }
    return null;
  }
  
  String getInternalPath()
  {
    try
    {
      String str = getApplicationContext().getFilesDir().getCanonicalPath() + "/";
      return str;
    }
    catch (Exception localException) {}
    return null;
  }
  
  /* Error */
  public String getMountSD()
  {
    // Byte code:
    //   0: aconst_null
    //   1: astore 4
    //   3: new 414	java/util/ArrayList
    //   6: dup
    //   7: invokespecial 415	java/util/ArrayList:<init>	()V
    //   10: astore 5
    //   12: new 2222	java/util/Scanner
    //   15: dup
    //   16: new 2224	java/io/FileInputStream
    //   19: dup
    //   20: new 868	java/io/File
    //   23: dup
    //   24: ldc_w 2226
    //   27: invokespecial 870	java/io/File:<init>	(Ljava/lang/String;)V
    //   30: invokespecial 2229	java/io/FileInputStream:<init>	(Ljava/io/File;)V
    //   33: invokespecial 2232	java/util/Scanner:<init>	(Ljava/io/InputStream;)V
    //   36: astore_3
    //   37: aload_3
    //   38: invokevirtual 2235	java/util/Scanner:hasNextLine	()Z
    //   41: ifeq +92 -> 133
    //   44: aload_3
    //   45: invokevirtual 2238	java/util/Scanner:nextLine	()Ljava/lang/String;
    //   48: astore 4
    //   50: aload 4
    //   52: ldc_w 2240
    //   55: invokevirtual 2243	java/lang/String:startsWith	(Ljava/lang/String;)Z
    //   58: ifne +14 -> 72
    //   61: aload 4
    //   63: ldc_w 2245
    //   66: invokevirtual 2243	java/lang/String:startsWith	(Ljava/lang/String;)Z
    //   69: ifeq -32 -> 37
    //   72: aload 4
    //   74: ldc_w 2247
    //   77: ldc_w 852
    //   80: invokevirtual 2250	java/lang/String:replaceAll	(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   83: ldc_w 852
    //   86: invokevirtual 2254	java/lang/String:split	(Ljava/lang/String;)[Ljava/lang/String;
    //   89: iconst_2
    //   90: aaload
    //   91: astore 4
    //   93: aload 5
    //   95: aload 4
    //   97: invokeinterface 2256 2 0
    //   102: ifne -65 -> 37
    //   105: aload 5
    //   107: aload 4
    //   109: invokeinterface 2257 2 0
    //   114: pop
    //   115: goto -78 -> 37
    //   118: astore_3
    //   119: iconst_0
    //   120: ifeq +11 -> 131
    //   123: new 2259	java/lang/NullPointerException
    //   126: dup
    //   127: invokespecial 2260	java/lang/NullPointerException:<init>	()V
    //   130: athrow
    //   131: aconst_null
    //   132: areturn
    //   133: aload_3
    //   134: ifnull +7 -> 141
    //   137: aload_3
    //   138: invokevirtual 2261	java/util/Scanner:close	()V
    //   141: getstatic 1039	android/os/Build$VERSION:SDK_INT	I
    //   144: bipush 9
    //   146: if_icmplt +23 -> 169
    //   149: invokestatic 2264	android/os/Environment:isExternalStorageRemovable	()Z
    //   152: ifne +17 -> 169
    //   155: aload 5
    //   157: invokestatic 2180	android/os/Environment:getExternalStorageDirectory	()Ljava/io/File;
    //   160: invokevirtual 883	java/io/File:getPath	()Ljava/lang/String;
    //   163: invokeinterface 2266 2 0
    //   168: pop
    //   169: iconst_0
    //   170: istore_1
    //   171: iload_1
    //   172: aload 5
    //   174: invokeinterface 2269 1 0
    //   179: if_icmpge +63 -> 242
    //   182: iload_1
    //   183: istore_2
    //   184: aload_0
    //   185: aload 5
    //   187: iload_1
    //   188: invokeinterface 2270 2 0
    //   193: checkcast 685	java/lang/String
    //   196: invokevirtual 2273	jp/gungho/padEN/AppDelegate:isMounted	(Ljava/lang/String;)Z
    //   199: ifne +16 -> 215
    //   202: aload 5
    //   204: iload_1
    //   205: invokeinterface 2275 2 0
    //   210: pop
    //   211: iload_1
    //   212: iconst_1
    //   213: isub
    //   214: istore_2
    //   215: iload_2
    //   216: iconst_1
    //   217: iadd
    //   218: istore_1
    //   219: goto -48 -> 171
    //   222: astore 5
    //   224: aload 4
    //   226: astore_3
    //   227: aload 5
    //   229: astore 4
    //   231: aload_3
    //   232: ifnull +7 -> 239
    //   235: aload_3
    //   236: invokevirtual 2261	java/util/Scanner:close	()V
    //   239: aload 4
    //   241: athrow
    //   242: aload 5
    //   244: invokeinterface 2269 1 0
    //   249: ifle +20 -> 269
    //   252: aload 5
    //   254: iconst_0
    //   255: invokeinterface 2270 2 0
    //   260: checkcast 685	java/lang/String
    //   263: areturn
    //   264: astore 4
    //   266: goto -35 -> 231
    //   269: aconst_null
    //   270: areturn
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	271	0	this	AppDelegate
    //   170	49	1	i	int
    //   183	35	2	j	int
    //   36	9	3	localScanner	java.util.Scanner
    //   118	20	3	localFileNotFoundException	java.io.FileNotFoundException
    //   226	10	3	localObject1	Object
    //   1	239	4	localObject2	Object
    //   264	1	4	localObject3	Object
    //   10	193	5	localArrayList	ArrayList
    //   222	31	5	localObject4	Object
    // Exception table:
    //   from	to	target	type
    //   12	37	118	java/io/FileNotFoundException
    //   37	72	118	java/io/FileNotFoundException
    //   72	115	118	java/io/FileNotFoundException
    //   12	37	222	finally
    //   37	72	264	finally
    //   72	115	264	finally
  }
  
  public boolean getNavibar()
  {
    return !this.isNavibarHide;
  }
  
  public int getNavigationBarHeight()
  {
    return this.navigationBarHeight;
  }
  
  public boolean getPermanentMenuKey()
  {
    return this.hasPermanentMenuKey;
  }
  
  public boolean getPermissionResult()
  {
    return this.mPermissionsResult;
  }
  
  Point getRealSize()
  {
    Point localPoint = new Point(0, 0);
    Display localDisplay = getWindowManager().getDefaultDisplay();
    if (Build.VERSION.SDK_INT >= 17) {
      localDisplay.getRealSize(localPoint);
    }
    for (;;)
    {
      return localPoint;
      if (Build.VERSION.SDK_INT >= 13) {
        try
        {
          Method localMethod1 = Display.class.getMethod("getRawWidth", new Class[0]);
          Method localMethod2 = Display.class.getMethod("getRawHeight", new Class[0]);
          localPoint.set(((Integer)localMethod1.invoke(localDisplay, new Object[0])).intValue(), ((Integer)localMethod2.invoke(localDisplay, new Object[0])).intValue());
        }
        catch (Exception localException)
        {
          return getDisplaySize();
        }
      }
    }
    return getDisplaySize();
  }
  
  public SSLSocketFactory getSSLSocketFactory()
  {
    try
    {
      SSLSocketFactory localSSLSocketFactory = initSSLContext().getSocketFactory();
      return localSSLSocketFactory;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return null;
  }
  
  public SharedPreferences getSharedPreferences(String paramString)
  {
    try
    {
      paramString = getApplicationContext().getSharedPreferences(paramString, 0);
      return paramString;
    }
    catch (Exception paramString)
    {
      paramString.printStackTrace();
    }
    return null;
  }
  
  public SharedPreferences.Editor getSharedPreferencesEditer(String paramString)
  {
    try
    {
      paramString = getSharedPreferences(paramString).edit();
      return paramString;
    }
    catch (Exception paramString)
    {
      paramString.printStackTrace();
    }
    return null;
  }
  
  public String getSharedPreferencesString(String paramString1, String paramString2)
  {
    try
    {
      paramString1 = getSharedPreferences(paramString1).getString(paramString2, null);
      return paramString1;
    }
    catch (Exception paramString1)
    {
      paramString1.printStackTrace();
    }
    return null;
  }
  
  public int getStatusBarHeight()
  {
    return this.statusBarHeight;
  }
  
  d getTextField(int paramInt)
  {
    if (paramInt == 0) {
      return null;
    }
    int j = this.pTextFields.size();
    int i = 0;
    if (i <= j) {
      if (((d)this.pTextFields.get(i)).hashCode() != paramInt) {}
    }
    for (d locald = (d)this.pTextFields.get(i);; locald = null)
    {
      return locald;
      i += 1;
      break;
    }
  }
  
  String getTextFieldText(int paramInt)
  {
    localObject4 = getTextField(paramInt);
    localObject1 = "";
    Object localObject2 = localObject1;
    if (localObject4 != null)
    {
      if ((((d)localObject4).a == null) || (((d)localObject4).a.getVisibility() != 0)) {
        break label68;
      }
      localObject2 = ((d)localObject4).a.getText().toString();
    }
    label68:
    do
    {
      do
      {
        for (;;)
        {
          try
          {
            localObject4 = izUtf8GetUcs2Code((String)localObject2);
          }
          catch (Exception localException1) {}
          try
          {
            localObject2 = _deleteCR(izUtf8GetUcs2Code((String)localObject2));
            return (String)localObject2;
          }
          catch (Exception localException3)
          {
            for (;;)
            {
              Object localObject3;
              localObject1 = localObject4;
            }
          }
          localObject2 = ((d)localObject4).b();
        }
        localException1.printStackTrace();
        localObject3 = localObject1;
      } while (getNavibar());
      localObject3 = localObject1;
    } while (_izDevGetBuild_SDK_INT() < 19);
    this.latchText = "";
    this.latchPtf = paramInt;
    try
    {
      this.pTextFieldLatch = new CountDownLatch(1);
      appDelegate.runOnUiThread(new Runnable()
      {
        public void run()
        {
          d locald = AppDelegate.this.getTextField(AppDelegate.this.latchPtf);
          AppDelegate.this.latchText = AppDelegate.this.izUtf8GetUcs2Code(locald.a.getText().toString());
          AppDelegate.this.latchText = AppDelegate.this._deleteCR(AppDelegate.this.izUtf8GetUcs2Code(locald.a.getText().toString()));
          if (AppDelegate.this.pTextFieldLatch != null) {
            AppDelegate.this.pTextFieldLatch.countDown();
          }
        }
      });
      this.pTextFieldLatch.await();
      localObject3 = this.latchText;
      return (String)localObject3;
    }
    catch (Exception localException2)
    {
      localException2.printStackTrace();
      return (String)localObject1;
    }
  }
  
  String getUrlQuery()
  {
    return this.mUrlQuery;
  }
  
  String getUrlScheme()
  {
    return this.mUrlScheme;
  }
  
  public native String getUserAgent();
  
  e getView()
  {
    return this.mView;
  }
  
  boolean getViewInitFlag()
  {
    boolean bool = false;
    if (this.mView != null) {
      bool = this.mView.d();
    }
    return bool;
  }
  
  int getViewInitState()
  {
    int i = 0;
    if (this.mView != null) {
      i = this.mView.e();
    }
    return i;
  }
  
  int getWidth(String paramString)
  {
    return (int)paint.measureText(paramString);
  }
  
  public native void handleOpenURL(String paramString1, String paramString2);
  
  public String hasLeftSpaces4DownloadSD(int paramInt)
  {
    long l1 = 1024L;
    String str = getMountSD();
    Object localObject = str;
    long l2;
    long l3;
    if (str != null)
    {
      localObject = new StatFs(str);
      l2 = ((StatFs)localObject).getAvailableBlocks();
      l3 = ((StatFs)localObject).getBlockSize();
      if (l3 <= 1024L) {
        break label198;
      }
    }
    for (;;)
    {
      l3 /= l1;
      if (paramInt / l1 >= l3 * l2)
      {
        localObject = null;
        return (String)localObject;
      }
      if (!str.substring(str.length() - 1).equals("/")) {}
      for (localObject = str + "/";; localObject = str)
      {
        str = (String)localObject + "Android/data/" + getApplicationContext().getPackageName() + "/files/";
        localObject = str;
        if (_izFileIsExistPath(str)) {
          break;
        }
        localObject = str;
        if (_izFilePathMkDirs(str)) {
          break;
        }
        return null;
      }
      label198:
      l1 = 1L;
    }
  }
  
  public boolean hasLeftSpaces4DownloadSD(String paramString, int paramInt)
  {
    long l1 = 1024L;
    long l2;
    long l3;
    if (paramString != null)
    {
      StatFs localStatFs = new StatFs(paramString.substring(0, paramString.indexOf("/Android/data/" + getApplicationContext().getPackageName() + "/files/")));
      l2 = localStatFs.getAvailableBlocks();
      l3 = localStatFs.getBlockSize();
      if (l3 <= 1024L) {
        break label122;
      }
    }
    for (;;)
    {
      l3 /= l1;
      return (paramInt / l1 < l3 * l2) && (_izFileIsExistPath(paramString)) && (_izFilePathMkDirs(paramString));
      label122:
      l1 = 1L;
    }
  }
  
  boolean hasNavigationBar()
  {
    boolean bool = true;
    Object localObject = getApplicationContext();
    Resources localResources = ((Context)localObject).getResources();
    int i = localResources.getIdentifier("config_showNavigationBar", "bool", "android");
    String str;
    if (i != 0)
    {
      localObject = "";
      if (Build.VERSION.SDK_INT >= 16) {}
      try
      {
        localObject = Class.forName("android.os.SystemProperties").getDeclaredMethod("get", new Class[] { String.class });
        ((Method)localObject).setAccessible(true);
        localObject = (String)((Method)localObject).invoke(null, new Object[] { "qemu.hw.mainkeys" });
        bool = localResources.getBoolean(i);
        if ("1".equals(localObject)) {
          return false;
        }
      }
      catch (Throwable localThrowable)
      {
        for (;;)
        {
          localThrowable.printStackTrace();
          str = "";
        }
      }
      if ("0".equals(str)) {
        return true;
      }
    }
    else
    {
      if (!ViewConfiguration.get(str).hasPermanentMenuKey()) {}
      for (;;)
      {
        return bool;
        bool = false;
      }
    }
    return bool;
  }
  
  void hideTextField(int paramInt, boolean paramBoolean)
  {
    Message localMessage = handler.obtainMessage();
    Bundle localBundle = new Bundle();
    localBundle.putBoolean("flag", paramBoolean);
    localBundle.putInt("hash", paramInt);
    localMessage.what = 2;
    localMessage.setData(localBundle);
    handler.sendMessage(localMessage);
  }
  
  void imgViewClose()
  {
    if (this.mImgView != null)
    {
      Message localMessage = handler.obtainMessage();
      localMessage.what = 9;
      handler.sendMessage(localMessage);
    }
  }
  
  public SSLContext initSSLContext()
  {
    SSLContext localSSLContext = SSLContext.getInstance("TLS");
    localSSLContext.init(null, null, null);
    HttpsURLConnection.setDefaultSSLSocketFactory(localSSLContext.getSocketFactory());
    return localSSLContext;
  }
  
  public boolean isAdInitialized()
  {
    return jp.gungho.a.a.c();
  }
  
  boolean isEditingTextField()
  {
    return this.inEditing;
  }
  
  boolean isImgViewDrew()
  {
    if (this.mImgView != null) {
      return this.mImgView.a;
    }
    return false;
  }
  
  int isInstallEnd()
  {
    return this.recv;
  }
  
  public boolean isKeyboardShowing(View paramView)
  {
    Object localObject = paramView.getContext();
    if (localObject == null) {}
    int i;
    int j;
    do
    {
      View localView;
      do
      {
        return false;
        localView = paramView.getRootView();
      } while (localView == null);
      paramView = new Rect();
      localView.getWindowVisibleDisplayFrame(paramView);
      localObject = ((Context)localObject).getResources().getDisplayMetrics();
      getWindowManager().getDefaultDisplay();
      i = paramView.bottom;
      j = paramView.top;
    } while (Math.abs(this.appViewHeight - (i - j)) <= ((DisplayMetrics)localObject).density * 100.0F);
    return true;
  }
  
  public boolean isLoggedInFacebook()
  {
    return this.mFbAccessToken != null;
  }
  
  /* Error */
  public boolean isMounted(String paramString)
  {
    // Byte code:
    //   0: iconst_0
    //   1: istore_3
    //   2: aconst_null
    //   3: astore 4
    //   5: new 2222	java/util/Scanner
    //   8: dup
    //   9: new 2224	java/io/FileInputStream
    //   12: dup
    //   13: new 868	java/io/File
    //   16: dup
    //   17: ldc_w 2478
    //   20: invokespecial 870	java/io/File:<init>	(Ljava/lang/String;)V
    //   23: invokespecial 2229	java/io/FileInputStream:<init>	(Ljava/io/File;)V
    //   26: invokespecial 2232	java/util/Scanner:<init>	(Ljava/io/InputStream;)V
    //   29: astore 5
    //   31: iload_3
    //   32: istore_2
    //   33: aload 5
    //   35: astore 4
    //   37: aload 5
    //   39: invokevirtual 2235	java/util/Scanner:hasNextLine	()Z
    //   42: ifeq +23 -> 65
    //   45: aload 5
    //   47: astore 4
    //   49: aload 5
    //   51: invokevirtual 2238	java/util/Scanner:nextLine	()Ljava/lang/String;
    //   54: aload_1
    //   55: invokevirtual 754	java/lang/String:contains	(Ljava/lang/CharSequence;)Z
    //   58: istore_2
    //   59: iload_2
    //   60: ifeq -29 -> 31
    //   63: iconst_1
    //   64: istore_2
    //   65: aload 5
    //   67: ifnull +8 -> 75
    //   70: aload 5
    //   72: invokevirtual 2261	java/util/Scanner:close	()V
    //   75: iload_2
    //   76: ireturn
    //   77: astore_1
    //   78: aconst_null
    //   79: astore 4
    //   81: new 2480	java/lang/RuntimeException
    //   84: dup
    //   85: aload_1
    //   86: invokespecial 2483	java/lang/RuntimeException:<init>	(Ljava/lang/Throwable;)V
    //   89: athrow
    //   90: astore_1
    //   91: aload 4
    //   93: ifnull +8 -> 101
    //   96: aload 4
    //   98: invokevirtual 2261	java/util/Scanner:close	()V
    //   101: aload_1
    //   102: athrow
    //   103: astore_1
    //   104: goto -13 -> 91
    //   107: astore_1
    //   108: aload 5
    //   110: astore 4
    //   112: goto -31 -> 81
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	115	0	this	AppDelegate
    //   0	115	1	paramString	String
    //   32	44	2	bool1	boolean
    //   1	31	3	bool2	boolean
    //   3	108	4	localObject	Object
    //   29	80	5	localScanner	java.util.Scanner
    // Exception table:
    //   from	to	target	type
    //   5	31	77	java/io/FileNotFoundException
    //   37	45	90	finally
    //   49	59	90	finally
    //   81	90	90	finally
    //   5	31	103	finally
    //   37	45	107	java/io/FileNotFoundException
    //   49	59	107	java/io/FileNotFoundException
  }
  
  boolean isOpenKeyboard()
  {
    return isKeyboardShowing(this.frameLayout);
  }
  
  boolean isPathExist(String paramString)
  {
    boolean bool = false;
    if (!TextUtils.isEmpty(paramString)) {}
    try
    {
      paramString = new File(paramString);
      new StringBuilder().append(getApplicationContext().getFilesDir().getCanonicalPath()).append("/").toString();
      bool = paramString.canRead();
      return bool;
    }
    catch (Exception paramString)
    {
      paramString.printStackTrace();
    }
    return false;
  }
  
  public boolean isPermissionWindowEnable()
  {
    return this.mPermissionsResultBusy;
  }
  
  public boolean isSelfPermission(String paramString)
  {
    if ("android.permission.WRITE_EXTERNAL_STORAGE".equals(paramString)) {}
    while ((_izDevGetBuild_SDK_INT() < 23) || (android.support.v4.app.a.a(getApplicationContext(), paramString) == 0)) {
      return true;
    }
    return false;
  }
  
  String isValidVersion()
  {
    Object localObject = "1.0.0";
    try
    {
      String str = getPackageManager().getPackageInfo(getApplicationContext().getPackageName(), 128).versionName;
      localObject = str;
      return null;
    }
    catch (Exception localException2)
    {
      for (;;)
      {
        try
        {
          localObject = new String(((String)localObject).getBytes("UTF8"), "UTF8");
          return (String)localObject;
        }
        catch (Exception localException1)
        {
          localException1.printStackTrace();
        }
        localException2 = localException2;
        localException2.printStackTrace();
      }
    }
  }
  
  boolean isValidgmsVersion()
  {
    Object localObject = GoogleApiAvailability.getInstance();
    int i = ((GoogleApiAvailability)localObject).isGooglePlayServicesAvailable(getApplicationContext());
    Log.i("googleapi", "res = " + i);
    switch (i)
    {
    case 0: 
    default: 
      return true;
    }
    localObject = ((GoogleApiAvailability)localObject).getErrorDialog(this, i, 10003);
    if (localObject != null) {
      ((Dialog)localObject).show();
    }
    return false;
  }
  
  public native int izCrcCalc(byte[] paramArrayOfByte, int paramInt);
  
  void izSndSeUnloadAll(int paramInt)
  {
    if (this.sndPool != null)
    {
      int i = 0;
      while (i < this.maxStream[paramInt])
      {
        this.sndPoolState[paramInt][i] = 'တ';
        i += 1;
      }
      this.sndPool.release();
      this.sndPool = null;
    }
  }
  
  String izUtf8GetUcs2Code(String paramString)
  {
    int j = paramString.length();
    StringBuilder localStringBuilder = new StringBuilder();
    int i = 0;
    if (i < j)
    {
      int k = paramString.codePointAt(i);
      if (k >= 65536) {
        localStringBuilder.append("■");
      }
      for (;;)
      {
        i += Character.charCount(k);
        break;
        localStringBuilder.append(paramString.charAt(i));
      }
    }
    return localStringBuilder.toString();
  }
  
  void izViewClearBgColor()
  {
    clearBgColor();
  }
  
  void izViewSetBgColor(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    setBgColor(paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public native boolean loadDataInstallUpdateCheck();
  
  public native int loadDispType();
  
  public native boolean loadNaviBarState();
  
  public void loginFacebook()
  {
    LoginManager.getInstance().logInWithReadPermissions(this, Arrays.asList(new String[] { "public_profile" }));
  }
  
  public void logoutFacebook()
  {
    this.mFbAccessToken = null;
    LoginManager.getInstance().logOut();
  }
  
  boolean mediaMountCheck()
  {
    return "mounted".equals(Environment.getExternalStorageState());
  }
  
  void nameInput(String paramString, int paramInt)
  {
    Bundle localBundle = new Bundle();
    localBundle.putInt("rank", paramInt);
    localBundle.putString("userName", paramString);
    AppEventsLogger.newLogger(this).logEvent("NAME_INPUT", localBundle);
    Tracker.sendEvent(new Tracker.Event("NAME_INPUT").setUserName(paramString).addCustom("start_monster", paramInt));
  }
  
  protected void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent)
  {
    super.onActivityResult(paramInt1, paramInt2, paramIntent);
    if (this.mFbCallbackManager != null) {
      this.mFbCallbackManager.onActivityResult(paramInt1, paramInt2, paramIntent);
    }
    switch (paramInt1)
    {
    }
    do
    {
      do
      {
        return;
      } while (this.mHelper.a(paramInt1, paramInt2, paramIntent));
      super.onActivityResult(paramInt1, paramInt2, paramIntent);
      return;
      if (paramInt2 == -1)
      {
        handleSignInResult(GoogleSignIn.getSignedInAccountFromIntent(paramIntent));
        return;
      }
      this.authState = 2;
      return;
    } while (paramInt2 == -1);
    this.authState = 2;
  }
  
  public void onClickBtnGoogleOAutn()
  {
    Message localMessage = handler.obtainMessage();
    localMessage.what = 37;
    handler.sendMessage(localMessage);
  }
  
  protected void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    AppEventsLogger.activateApp(getApplication());
    AppEventsLogger.newLogger(this);
    Tracker.configure(new Tracker.Configuration(getApplicationContext()).setAppGuid("kopaden-and-tfwo").setLogLevel(3));
    this.notification = new c(getApplicationContext());
    appDelegate = this;
    this.mPaused = false;
    this.mFocus = false;
    this.mUrlScheme = null;
    this.mUrlQuery = null;
    didFinishLaunchingWithOptions();
    if (!TextUtils.isEmpty(getSharedPreferencesString("data076", "bootcheck")))
    {
      deleteSharedPreferences("data076", "bootcheck");
      dataRecovery();
    }
    saveSharedPreferencesString("data076", "bootcheck", "boot");
    paramBundle = getIntent();
    if ("android.intent.action.VIEW".equals(paramBundle.getAction()))
    {
      paramBundle = paramBundle.getData();
      this.mUrlScheme = paramBundle.getScheme();
      this.mUrlQuery = paramBundle.getQuery();
    }
    requestWindowFeature(1);
    updateNavigationBarHeight();
    boolean bool;
    int i;
    Point localPoint;
    if (getNavigationBarHeight() == 0)
    {
      bool = true;
      this.isNavibarHide = bool;
      i = _izDevGetBuild_SDK_INT();
      if (i >= 19)
      {
        paramBundle = new Point();
        getWindowManager().getDefaultDisplay().getSize(paramBundle);
        localPoint = new Point(0, 0);
        getWindowManager().getDefaultDisplay().getRealSize(localPoint);
        if (paramBundle.y != localPoint.y) {
          break label701;
        }
      }
    }
    label701:
    for (this.hasPermanentMenuKey = true;; this.hasPermanentMenuKey = false)
    {
      if ((!getNavibar()) && (i >= 19)) {}
      this.frameLayout = new FrameLayout(this);
      setContentView(this.frameLayout);
      this.mView = new e(this);
      this.frameLayout.addView(this.mView, new ViewGroup.LayoutParams(-2, -2));
      this.mImgView = new b(this);
      this.mImgView.setBackgroundColor(-1);
      this.mImgView.setImageResource(2131099812);
      paramBundle = new FrameLayout.LayoutParams(-1, -1);
      paramBundle.gravity = 17;
      this.mImgView.setLayoutParams(paramBundle);
      this.frameLayout.addView(this.mImgView);
      paramBundle = getWindowManager().getDefaultDisplay();
      localPoint = new Point();
      paramBundle.getSize(localPoint);
      this.dispWidth = localPoint.x;
      this.dispHeight = localPoint.y;
      if ((!getNavibar()) && (i >= 19)) {
        this.dispHeight = getRealSize().y;
      }
      this.pHTMLVIEW = new h(this);
      this.frameLayout.addView(this.pHTMLVIEW.b, new ViewGroup.LayoutParams(-1, -1));
      this.pMEDIT = new i(this);
      this.frameLayout.addView(this.pMEDIT.b, new ViewGroup.LayoutParams(-1, -1));
      handler = new Handler()
      {
        public void handleMessage(Message paramAnonymousMessage)
        {
          Object localObject1 = paramAnonymousMessage.getData();
          switch (paramAnonymousMessage.what)
          {
          case 99: 
          default: 
          case 0: 
          case 1: 
          case 2: 
          case 3: 
          case 4: 
          case 5: 
          case 6: 
          case 7: 
          case 8: 
          case 9: 
          case 10: 
          case 11: 
          case 12: 
          case 13: 
          case 14: 
          case 15: 
          case 16: 
          case 17: 
          case 18: 
          case 19: 
          case 20: 
          case 21: 
          case 22: 
          case 23: 
          case 24: 
          case 40: 
          case 39: 
          case 30: 
          case 36: 
          case 31: 
          case 35: 
          case 32: 
            do
            {
              do
              {
                do
                {
                  do
                  {
                    do
                    {
                      do
                      {
                        do
                        {
                          do
                          {
                            do
                            {
                              do
                              {
                                do
                                {
                                  do
                                  {
                                    do
                                    {
                                      do
                                      {
                                        do
                                        {
                                          do
                                          {
                                            do
                                            {
                                              do
                                              {
                                                do
                                                {
                                                  do
                                                  {
                                                    do
                                                    {
                                                      do
                                                      {
                                                        do
                                                        {
                                                          do
                                                          {
                                                            do
                                                            {
                                                              for (;;)
                                                              {
                                                                return;
                                                                paramAnonymousMessage = AppDelegate.this.getTextField(((Bundle)localObject1).getInt("hash"));
                                                                paramAnonymousMessage.a();
                                                                paramAnonymousMessage.a.setOnFocusChangeListener(new View.OnFocusChangeListener()
                                                                {
                                                                  public void onFocusChange(View paramAnonymous2View, boolean paramAnonymous2Boolean)
                                                                  {
                                                                    InputMethodManager localInputMethodManager = (InputMethodManager)AppDelegate.this.getSystemService("input_method");
                                                                    Log.d("onFocusChange", "hasFocus:" + paramAnonymous2Boolean);
                                                                    AppDelegate.this.updateStatusBarHeight();
                                                                    if (paramAnonymous2Boolean)
                                                                    {
                                                                      AppDelegate.access$002(AppDelegate.this, true);
                                                                      return;
                                                                    }
                                                                    localInputMethodManager.hideSoftInputFromWindow(paramAnonymous2View.getWindowToken(), 0);
                                                                    if (((AppDelegate.this.getNavibar()) || (AppDelegate.this._izDevGetBuild_SDK_INT() < 19)) || (AppDelegate.this._izDevGetBuild_SDK_INT() >= 19)) {
                                                                      AppDelegate.this.setNavigationBarHide(AppDelegate.this.isNavibarHide);
                                                                    }
                                                                    AppDelegate.access$002(AppDelegate.this, false);
                                                                  }
                                                                });
                                                                try
                                                                {
                                                                  Object localObject2 = TextView.class.getDeclaredField("mCursorDrawableRes");
                                                                  ((Field)localObject2).setAccessible(true);
                                                                  ((Field)localObject2).set(paramAnonymousMessage.a, Integer.valueOf(2131099778));
                                                                  paramAnonymousMessage.a.setBackgroundColor(Color.rgb(255, 255, 255));
                                                                  paramAnonymousMessage.a.setVisibility(4);
                                                                  AppDelegate.this.frameLayout.addView(paramAnonymousMessage.a, new ViewGroup.LayoutParams(-2, -2));
                                                                  switch (((Bundle)localObject1).getInt("keyboardType"))
                                                                  {
                                                                  default: 
                                                                    paramAnonymousMessage.a.setOnKeyListener(new View.OnKeyListener()
                                                                    {
                                                                      public boolean onKey(View paramAnonymous2View, int paramAnonymous2Int, KeyEvent paramAnonymous2KeyEvent)
                                                                      {
                                                                        if ((paramAnonymous2KeyEvent.getAction() == 0) && (paramAnonymous2Int == 66))
                                                                        {
                                                                          ((InputMethodManager)AppDelegate.this.getSystemService("input_method")).hideSoftInputFromWindow(paramAnonymous2View.getWindowToken(), 0);
                                                                          if ((!AppDelegate.this.getNavibar()) && (AppDelegate.this._izDevGetBuild_SDK_INT() >= 19)) {
                                                                            AppDelegate.this.setNavigationBarHandle(AppDelegate.this.isNavibarHide);
                                                                          }
                                                                          return true;
                                                                        }
                                                                        return false;
                                                                      }
                                                                    });
                                                                    paramAnonymousMessage.a.setOnEditorActionListener(new TextView.OnEditorActionListener()
                                                                    {
                                                                      public boolean onEditorAction(TextView paramAnonymous2TextView, int paramAnonymous2Int, KeyEvent paramAnonymous2KeyEvent)
                                                                      {
                                                                        Log.d("onEditorAction", "actionId:" + paramAnonymous2Int);
                                                                        if (paramAnonymous2KeyEvent != null)
                                                                        {
                                                                          if (((paramAnonymous2KeyEvent.getAction() & 0xFF) == 0) && (paramAnonymous2KeyEvent.getKeyCode() == 66))
                                                                          {
                                                                            paramAnonymous2KeyEvent = (InputMethodManager)AppDelegate.this.getSystemService("input_method");
                                                                            if (paramAnonymous2KeyEvent != null) {
                                                                              paramAnonymous2KeyEvent.hideSoftInputFromWindow(paramAnonymous2TextView.getWindowToken(), 0);
                                                                            }
                                                                            return true;
                                                                          }
                                                                        }
                                                                        else
                                                                        {
                                                                          if (paramAnonymous2Int == 6)
                                                                          {
                                                                            AppDelegate.this.mView.setFocusable(true);
                                                                            AppDelegate.this.mView.setFocusableInTouchMode(true);
                                                                            AppDelegate.this.mView.requestFocus();
                                                                            return false;
                                                                          }
                                                                          return true;
                                                                        }
                                                                        return false;
                                                                      }
                                                                    });
                                                                    f2 = AppDelegate.this.getDispLeft();
                                                                    f1 = AppDelegate.this.getDispTop();
                                                                    if (!AppDelegate.this.getResources().getBoolean(2130903045)) {
                                                                      break;
                                                                    }
                                                                  case 0: 
                                                                  case 1: 
                                                                  case 2: 
                                                                  case 3: 
                                                                  case 4: 
                                                                  case 5: 
                                                                  case 6: 
                                                                    try
                                                                    {
                                                                      f3 = ((Integer)Display.class.getMethod("getRawHeight", new Class[0]).invoke(AppDelegate.this.getWindowManager().getDefaultDisplay(), new Object[0])).intValue();
                                                                      if (f3 == AppDelegate.this.getDispHeight()) {
                                                                        break label1180;
                                                                      }
                                                                      f4 = AppDelegate.this.getDispHeight();
                                                                      f1 = f3 - f4;
                                                                    }
                                                                    catch (Exception localException2)
                                                                    {
                                                                      for (;;)
                                                                      {
                                                                        float f9;
                                                                        localException2.printStackTrace();
                                                                      }
                                                                    }
                                                                    f1 *= AppDelegate.this.mView.k();
                                                                    f3 = ((Bundle)localObject1).getInt("x");
                                                                    f4 = AppDelegate.this.mView.j();
                                                                    f5 = AppDelegate.this.mView.h();
                                                                    f6 = ((Bundle)localObject1).getInt("y");
                                                                    f7 = AppDelegate.this.mView.k();
                                                                    f8 = ((Bundle)localObject1).getInt("w") * 2.0F * AppDelegate.this.mView.j();
                                                                    f9 = ((Bundle)localObject1).getInt("h") * 2.0F * AppDelegate.this.mView.k();
                                                                    try
                                                                    {
                                                                      paramAnonymousMessage.a.setWidth((int)f8);
                                                                      paramAnonymousMessage.a.setHeight((int)f9);
                                                                      AppDelegate.this.textViewTextResize(paramAnonymousMessage.a, f9);
                                                                      paramAnonymousMessage.a.setImeOptions(6);
                                                                      paramAnonymousMessage.a.setText(((Bundle)localObject1).getString("text"));
                                                                      paramAnonymousMessage.a.setTextColor(-16777216);
                                                                      paramAnonymousMessage.a.setHint(((Bundle)localObject1).getString("placeholder"));
                                                                      paramAnonymousMessage.a.setPadding(0, 0, 0, 0);
                                                                      localObject2 = new FrameLayout.LayoutParams((int)f8, (int)f9);
                                                                      ((FrameLayout.LayoutParams)localObject2).gravity = 51;
                                                                      ((FrameLayout.LayoutParams)localObject2).leftMargin = ((int)(f3 * 2.0F * f4 + f5 + f2));
                                                                      ((FrameLayout.LayoutParams)localObject2).topMargin = ((int)(f1 + f6 * 2.0F * f7));
                                                                      paramAnonymousMessage.a.setLayoutParams((ViewGroup.LayoutParams)localObject2);
                                                                      paramAnonymousMessage.a.setGravity(17);
                                                                      if (((Bundle)localObject1).getString("text") != null)
                                                                      {
                                                                        i = ((Bundle)localObject1).getString("text").length();
                                                                        paramAnonymousMessage.a.setSelection(0, paramAnonymousMessage.a.length());
                                                                        paramAnonymousMessage.a.setSelection(i);
                                                                        return;
                                                                      }
                                                                    }
                                                                    catch (Exception paramAnonymousMessage)
                                                                    {
                                                                      paramAnonymousMessage.printStackTrace();
                                                                      return;
                                                                    }
                                                                  }
                                                                }
                                                                catch (Exception localException1)
                                                                {
                                                                  for (;;)
                                                                  {
                                                                    localException1.printStackTrace();
                                                                    continue;
                                                                    paramAnonymousMessage.a.setInputType(1);
                                                                    paramAnonymousMessage.a.setFilters(new InputFilter[] { new InputFilter.LengthFilter(AppDelegate.this.maxTextLeng) });
                                                                    continue;
                                                                    paramAnonymousMessage.a.setInputType(1);
                                                                    paramAnonymousMessage.a.setFilters(new InputFilter[] { new AppDelegate.a(AppDelegate.this), new InputFilter.LengthFilter(AppDelegate.this.maxTextLeng) });
                                                                    paramAnonymousMessage.a(true);
                                                                    continue;
                                                                    paramAnonymousMessage.a.setInputType(1);
                                                                    paramAnonymousMessage.a.setFilters(new InputFilter[] { new InputFilter.LengthFilter(AppDelegate.this.maxTextLeng) });
                                                                    continue;
                                                                    paramAnonymousMessage.a.setInputType(1);
                                                                    paramAnonymousMessage.a.setFilters(new InputFilter[] { new InputFilter.LengthFilter(AppDelegate.this.maxTextLeng) });
                                                                    continue;
                                                                    paramAnonymousMessage.a.setInputType(12290);
                                                                    paramAnonymousMessage.a(true);
                                                                    continue;
                                                                    paramAnonymousMessage.a.setInputType(12290);
                                                                    continue;
                                                                    paramAnonymousMessage.a.setInputType(12290);
                                                                    paramAnonymousMessage.a(true);
                                                                    continue;
                                                                    f1 = 960.0F / AppDelegate.this.mView.p() * f1;
                                                                  }
                                                                }
                                                              }
                                                              paramAnonymousMessage = AppDelegate.this.getTextField(((Bundle)localObject1).getInt("hash"));
                                                            } while ((paramAnonymousMessage == null) || (paramAnonymousMessage.a == null));
                                                            paramAnonymousMessage.a.setVisibility(8);
                                                            paramAnonymousMessage.a.getEditableText().clear();
                                                            AppDelegate.this.frameLayout.removeView(paramAnonymousMessage.a);
                                                            AppDelegate.this.pTextFields.remove(paramAnonymousMessage);
                                                            paramAnonymousMessage.finalize();
                                                            return;
                                                            paramAnonymousMessage = AppDelegate.this.getTextField(((Bundle)localObject1).getInt("hash"));
                                                            f3 = AppDelegate.this.getDispLeft();
                                                            f1 = AppDelegate.this.getDispTop();
                                                            f4 = ((Bundle)localObject1).getInt("x");
                                                            f5 = AppDelegate.this.mView.j();
                                                            f6 = AppDelegate.this.mView.h();
                                                            f2 = ((Bundle)localObject1).getInt("y") * 2.0F * AppDelegate.this.mView.k() + f1;
                                                            f1 = f2;
                                                            if (AppDelegate.this.mView.r() == 2) {
                                                              f1 = f2 - AppDelegate.this.mView.s() * AppDelegate.this.mView.k();
                                                            }
                                                            f2 = ((Bundle)localObject1).getInt("w") * 2.0F * AppDelegate.this.mView.j();
                                                            f7 = ((Bundle)localObject1).getInt("h") * 2.0F * AppDelegate.this.mView.k();
                                                          } while ((paramAnonymousMessage == null) || (paramAnonymousMessage.a == null));
                                                          if ((paramAnonymousMessage.a.getVisibility() != 0) && (paramAnonymousMessage.a.isEnabled())) {
                                                            paramAnonymousMessage.a.setVisibility(0);
                                                          }
                                                          paramAnonymousMessage.a.setWidth((int)f2);
                                                          paramAnonymousMessage.a.setHeight((int)f7);
                                                          paramAnonymousMessage.a.setPadding(0, 0, 0, 0);
                                                          localObject1 = new FrameLayout.LayoutParams((int)f2, (int)f7);
                                                          ((FrameLayout.LayoutParams)localObject1).gravity = 51;
                                                          ((FrameLayout.LayoutParams)localObject1).leftMargin = ((int)(f4 * 2.0F * f5 + f6 + f3));
                                                          ((FrameLayout.LayoutParams)localObject1).topMargin = ((int)f1);
                                                          paramAnonymousMessage.a.setLayoutParams((ViewGroup.LayoutParams)localObject1);
                                                          paramAnonymousMessage.a.setGravity(17);
                                                          return;
                                                          paramAnonymousMessage = AppDelegate.this.getTextField(((Bundle)localObject1).getInt("hash"));
                                                        } while ((paramAnonymousMessage == null) || (paramAnonymousMessage.a == null) || (paramAnonymousMessage.a.getVisibility() == 0));
                                                        paramAnonymousMessage.a.setVisibility(0);
                                                        return;
                                                        paramAnonymousMessage = AppDelegate.this.getTextField(((Bundle)localObject1).getInt("hash"));
                                                        if ((paramAnonymousMessage != null) && (paramAnonymousMessage.a != null))
                                                        {
                                                          paramAnonymousMessage.a.getSelectionStart();
                                                          ((Bundle)localObject1).getInt("offset");
                                                          paramAnonymousMessage.a.setText(((Bundle)localObject1).getString("text"));
                                                          i = paramAnonymousMessage.a.length();
                                                          paramAnonymousMessage.a.setSelection(i);
                                                          return;
                                                        }
                                                      } while (paramAnonymousMessage == null);
                                                      paramAnonymousMessage.a(((Bundle)localObject1).getString("text"));
                                                      return;
                                                      paramAnonymousMessage = AppDelegate.this.getTextField(((Bundle)localObject1).getInt("hash"));
                                                    } while ((paramAnonymousMessage == null) || (paramAnonymousMessage.a == null));
                                                    if (((Bundle)localObject1).getBoolean("flag"))
                                                    {
                                                      paramAnonymousMessage.a.setVisibility(8);
                                                      return;
                                                    }
                                                    paramAnonymousMessage.a.setVisibility(0);
                                                    return;
                                                  } while (AppDelegate.this.pMEDIT == null);
                                                  AppDelegate.this.pMEDIT.a(AppDelegate.this.mView.h(), AppDelegate.this.mView.g(), AppDelegate.this.mView.i(), AppDelegate.this.mView.l());
                                                  AppDelegate.this.pMEDIT.c();
                                                  return;
                                                } while (AppDelegate.this.pMEDIT == null);
                                                AppDelegate.this.pMEDIT.b();
                                                return;
                                              } while (AppDelegate.this.mImgView == null);
                                              AppDelegate.this.frameLayout.removeView(AppDelegate.this.mImgView);
                                              AppDelegate.access$602(AppDelegate.this, null);
                                              return;
                                            } while (AppDelegate.this.pUiWebView != null);
                                            AppDelegate.access$702(AppDelegate.this, new WebView(AppDelegate.appDelegate));
                                            AppDelegate.this.pUiWebView.setVisibility(8);
                                            AppDelegate.this.pUiWebView.setWebViewClient(new WebViewClient()
                                            {
                                              public boolean shouldOverrideUrlLoading(WebView paramAnonymous2WebView, String paramAnonymous2String)
                                              {
                                                paramAnonymous2WebView = new Intent("android.intent.action.VIEW", Uri.parse(paramAnonymous2String));
                                                AppDelegate.appDelegate.startActivity(paramAnonymous2WebView);
                                                return true;
                                              }
                                            });
                                            AppDelegate.access$902(AppDelegate.this, false);
                                            AppDelegate.this.frameLayout.addView(AppDelegate.this.pUiWebView, new ViewGroup.LayoutParams(-2, -2));
                                          } while (AppDelegate.this.mView == null);
                                          AppDelegate.access$902(AppDelegate.this, false);
                                          f1 = ((Bundle)localObject1).getInt("x");
                                          float f6 = ((Bundle)localObject1).getInt("y");
                                          float f2 = ((Bundle)localObject1).getInt("w");
                                          float f3 = ((Bundle)localObject1).getInt("h");
                                          AppDelegate.access$1002(AppDelegate.this, (int)(AppDelegate.this.mView.p() / 2.0F));
                                          AppDelegate.access$1102(AppDelegate.this, null);
                                          AppDelegate.access$1102(AppDelegate.this, new Rect((int)f1, (int)f6, (int)f2, (int)f3));
                                          AppDelegate.access$1202(AppDelegate.this, (int)(f3 / 2.0F + f6));
                                          AppDelegate.access$1302(AppDelegate.this, AppDelegate.this.webViewStartLine + f3 / 2.0F);
                                          AppDelegate.access$1402(AppDelegate.this, f2 / 2.0F + f1);
                                          AppDelegate.access$1502(AppDelegate.this, AppDelegate.this.webViewY);
                                          float f4 = AppDelegate.this.mView.j();
                                          float f5 = AppDelegate.this.mView.h();
                                          f6 = (float)Math.ceil(0.0F + (f6 * 2.0F * AppDelegate.this.mView.k() + AppDelegate.this.mView.g()));
                                          float f7 = AppDelegate.this.mView.j();
                                          float f8 = AppDelegate.this.mView.k();
                                          AppDelegate.this.pUiWebView.setScrollBarStyle(0);
                                          AppDelegate.this.pUiWebView.setVisibility(0);
                                          AppDelegate.this.pUiWebView.setBackgroundColor(-16777216);
                                          AppDelegate.this.pUiWebView.getSettings().setBuiltInZoomControls(true);
                                          AppDelegate.this.pUiWebView.getSettings().setJavaScriptEnabled(true);
                                          AppDelegate.this.pUiWebView.setInitialScale((int)AppDelegate.this.mView.j() * 100);
                                          paramAnonymousMessage = new FrameLayout.LayoutParams((int)(2.0F * f2 * f7), (int)(2.0F * f3 * f8));
                                          paramAnonymousMessage.gravity = 51;
                                          paramAnonymousMessage.leftMargin = ((int)(f1 * 2.0F * f4 + f5));
                                          paramAnonymousMessage.topMargin = ((int)f6);
                                          AppDelegate.this.pUiWebView.setLayoutParams(paramAnonymousMessage);
                                          paramAnonymousMessage = ((Bundle)localObject1).getString("url");
                                          AppDelegate.this.pUiWebView.loadUrl(paramAnonymousMessage);
                                          AppDelegate.access$902(AppDelegate.this, true);
                                          return;
                                        } while (AppDelegate.this.pUiWebView == null);
                                        AppDelegate.this.pUiWebView.setVisibility(8);
                                        AppDelegate.this.frameLayout.removeView(AppDelegate.this.pUiWebView);
                                        AppDelegate.access$702(AppDelegate.this, null);
                                        return;
                                        AppDelegate.this.getWindow().addFlags(1024);
                                        return;
                                      } while (AppDelegate.this.mAlertDialog == null);
                                      AppDelegate.this.mAlertDialog.setIcon(17301642);
                                      AppDelegate.this.mAlertDialog.setTitle(((Bundle)localObject1).getString("title"));
                                      AppDelegate.this.mAlertDialog.setMessage(((Bundle)localObject1).getString("message"));
                                      if (((Bundle)localObject1).getString("positive") != null)
                                      {
                                        if (AppDelegate.this.mPositiveButtonListener != null) {
                                          AppDelegate.this.mAlertDialog.setPositiveButton(((Bundle)localObject1).getString("positive"), AppDelegate.this.mPositiveButtonListener);
                                        }
                                      }
                                      else
                                      {
                                        if (((Bundle)localObject1).getString("negative") == null) {
                                          break label2736;
                                        }
                                        if (AppDelegate.this.mNegativeButtonListener == null) {
                                          break label2706;
                                        }
                                        AppDelegate.this.mAlertDialog.setNegativeButton(((Bundle)localObject1).getString("negative"), AppDelegate.this.mNegativeButtonListener);
                                      }
                                      for (;;)
                                      {
                                        AppDelegate.this.mAlertDialog.show();
                                        return;
                                        AppDelegate.this.mAlertDialog.setPositiveButton(((Bundle)localObject1).getString("positive"), new DialogInterface.OnClickListener()
                                        {
                                          public void onClick(DialogInterface paramAnonymous2DialogInterface, int paramAnonymous2Int)
                                          {
                                            paramAnonymous2DialogInterface.cancel();
                                          }
                                        });
                                        break;
                                        AppDelegate.this.mAlertDialog.setNegativeButton(((Bundle)localObject1).getString("negative"), new DialogInterface.OnClickListener()
                                        {
                                          public void onClick(DialogInterface paramAnonymous2DialogInterface, int paramAnonymous2Int)
                                          {
                                            if ((!AppDelegate.this.getNavibar()) && (AppDelegate.this._izDevGetBuild_SDK_INT() >= 19)) {
                                              AppDelegate.this.setupMainWindowDisplayMode();
                                            }
                                            paramAnonymous2DialogInterface.cancel();
                                          }
                                        });
                                        continue;
                                        AppDelegate.this.mAlertDialog.setCancelable(false);
                                      }
                                      if ((AppDelegate.this.mHelper != null) && (AppDelegate.this.mGotInventoryListener != null) && (AppDelegate.this.mHelper.c()) && (!AppDelegate.this.mHelper.d()))
                                      {
                                        AppDelegate.this.mHelper.a(AppDelegate.this.mGotInventoryListener);
                                        return;
                                      }
                                      AppDelegate.this._failedTransaction(0, 100);
                                      return;
                                      if ((AppDelegate.this.mHelper != null) && (AppDelegate.this.mGotSkuDetailsListener != null) && (AppDelegate.this.mHelper.c()) && (!AppDelegate.this.mHelper.d()))
                                      {
                                        localObject1 = ((Bundle)localObject1).getStringArray("moreSkus");
                                        paramAnonymousMessage = null;
                                        if (localObject1 != null) {
                                          paramAnonymousMessage = Arrays.asList((Object[])localObject1);
                                        }
                                        AppDelegate.this.mHelper.a(paramAnonymousMessage, AppDelegate.this.mGotSkuDetailsListener);
                                        return;
                                      }
                                      AppDelegate.this.requestDidFailWithError();
                                      return;
                                    } while (AppDelegate.this.sndPool == null);
                                    AppDelegate.this.sndPool.play(((Bundle)localObject1).getInt("soundID"), ((Bundle)localObject1).getFloat("leftVolume"), ((Bundle)localObject1).getFloat("rightVolume"), ((Bundle)localObject1).getInt("priority"), ((Bundle)localObject1).getInt("loop"), ((Bundle)localObject1).getFloat("rate"));
                                    return;
                                  } while (AppDelegate.this.pHTMLVIEW == null);
                                  AppDelegate.this.pHTMLVIEW.a(((Bundle)localObject1).getString("url"), ((Bundle)localObject1).getString("title"));
                                  return;
                                } while (AppDelegate.this.pHTMLVIEW == null);
                                AppDelegate.this.frameLayout.removeView(AppDelegate.this.pHTMLVIEW.b);
                                AppDelegate.this.frameLayout.addView(AppDelegate.this.pHTMLVIEW.b, new ViewGroup.LayoutParams(-1, -1));
                                AppDelegate.this.pHTMLVIEW.a(AppDelegate.this.mView.h(), AppDelegate.this.mView.g(), AppDelegate.this.mView.i(), AppDelegate.this.mView.l());
                                AppDelegate.this.pHTMLVIEW.d();
                                return;
                              } while (AppDelegate.this.pHTMLVIEW == null);
                              AppDelegate.this.pHTMLVIEW.c();
                              return;
                              paramAnonymousMessage = ((Bundle)localObject1).getString("string");
                              AppDelegate.this.setClipboard(paramAnonymousMessage);
                              return;
                            } while (!AppDelegate.this.getViewInitFlag());
                            paramAnonymousMessage = (g)paramAnonymousMessage.obj;
                            if (paramAnonymousMessage.b().endsWith(".rew")) {
                              AppDelegate.access$2102(AppDelegate.this, AppDelegate.this.getApiReqShopStoneRewardUrl());
                            }
                            while (AppDelegate.this.ShopStoneUrl != null)
                            {
                              AppDelegate.this._consumeFinished(paramAnonymousMessage);
                              return;
                              AppDelegate.access$2102(AppDelegate.this, AppDelegate.this.getApiReqShopStoneUrl());
                            }
                            AppDelegate.this._failedTransaction(0, 1);
                            return;
                          } while ((!AppDelegate.this.getViewInitFlag()) || (AppDelegate.this.mHelper.d()));
                          int i = paramAnonymousMessage.arg1;
                          if (paramAnonymousMessage.arg2 < 0) {
                            AppDelegate.this.setApiResShopStone(i);
                          }
                          for (;;)
                          {
                            AppDelegate.this.mHelper.a((g)paramAnonymousMessage.obj, AppDelegate.this.mConsumeFinishedListener);
                            return;
                            AppDelegate.this.setApiReward(i, paramAnonymousMessage.arg2);
                          }
                        } while (!AppDelegate.this.getViewInitFlag());
                        AppDelegate.this.completeTransaction();
                        return;
                      } while (!AppDelegate.this.getViewInitFlag());
                      AppDelegate.this.failedTransaction(((Bundle)localObject1).getInt("state"), ((Bundle)localObject1).getInt("code"));
                      return;
                      if ((AppDelegate.this.mHelper != null) && (AppDelegate.this.mCheckRewListener != null) && (AppDelegate.this.mHelper.c()) && (!AppDelegate.this.mHelper.d()))
                      {
                        AppDelegate.this.mHelper.a(AppDelegate.this.mCheckRewListener);
                        return;
                      }
                      AppDelegate.this._failedTransaction(0, 100);
                      return;
                      AppDelegate.this.mHelper.a(false, (d.e)paramAnonymousMessage.obj);
                      return;
                      paramAnonymousMessage = AppDelegate.this.getTextField(((Bundle)localObject1).getInt("hash"));
                    } while ((paramAnonymousMessage == null) || (paramAnonymousMessage.a == null));
                    if (((Bundle)localObject1).getBoolean("flag"))
                    {
                      paramAnonymousMessage.a.setEnabled(true);
                      paramAnonymousMessage.a.setAlpha(1.0F);
                      return;
                    }
                    paramAnonymousMessage.a.setEnabled(false);
                    paramAnonymousMessage.a.setAlpha(0.5F);
                    return;
                    paramAnonymousMessage = AppDelegate.this.getTextField(((Bundle)localObject1).getInt("hash"));
                  } while ((paramAnonymousMessage == null) || (paramAnonymousMessage.a == null));
                  float f1 = ((Bundle)localObject1).getFloat("alpha");
                  paramAnonymousMessage.a.setAlpha(f1);
                  boolean bool;
                  if (f1 > 0.0F)
                  {
                    bool = true;
                    if (!bool) {
                      break label3667;
                    }
                    paramAnonymousMessage.a.setVisibility(0);
                  }
                  for (;;)
                  {
                    paramAnonymousMessage.a.setEnabled(bool);
                    return;
                    bool = false;
                    break;
                    paramAnonymousMessage.a.setVisibility(8);
                  }
                  paramAnonymousMessage = AppDelegate.this.getTextField(((Bundle)localObject1).getInt("hash"));
                } while ((paramAnonymousMessage == null) || (paramAnonymousMessage.a == null));
                paramAnonymousMessage.a.requestFocus();
                ((InputMethodManager)AppDelegate.this.getSystemService("input_method")).showSoftInput(paramAnonymousMessage.a, 0);
                return;
                paramAnonymousMessage = AppDelegate.this.getTextField(((Bundle)localObject1).getInt("hash"));
              } while ((paramAnonymousMessage == null) || (paramAnonymousMessage.a == null));
              ((InputMethodManager)AppDelegate.this.getSystemService("input_method")).hideSoftInputFromWindow(paramAnonymousMessage.a.getWindowToken(), 2);
              return;
            } while (AppDelegate.this.mErrorDialog == null);
            AppDelegate.this.mErrorDialog.setIcon(17301642);
            AppDelegate.this.mErrorDialog.setTitle(((Bundle)localObject1).getString("title"));
            AppDelegate.this.mErrorDialog.setMessage(((Bundle)localObject1).getString("message"));
            AppDelegate.access$2302(AppDelegate.this, true);
            if ((((Bundle)localObject1).getString("positive") != null) && (AppDelegate.this.mErrorButtonListener != null))
            {
              AppDelegate.this.mErrorDialog.setPositiveButton(((Bundle)localObject1).getString("positive"), AppDelegate.this.mErrorButtonListener);
              AppDelegate.access$2302(AppDelegate.this, false);
            }
            AppDelegate.this.mErrorDialog.setCancelable(false);
            AppDelegate.this.mErrorDialog.show();
            return;
          case 33: 
            AppDelegate.this.mView.f();
            return;
          case 34: 
            label1180:
            label2706:
            label2736:
            label3667:
            AppDelegate.this.frameLayout.removeView(AppDelegate.this.mView);
            AppDelegate.this.frameLayout.removeView(AppDelegate.this.pHTMLVIEW.b);
            AppDelegate.this.frameLayout.removeView(AppDelegate.this.pMEDIT.b);
          }
          try
          {
            AppDelegate.this.mView.setSecure(AppDelegate.this.isSecure);
            AppDelegate.this.frameLayout.addView(AppDelegate.this.mView, new ViewGroup.LayoutParams(-2, -2));
            AppDelegate.this.frameLayout.addView(AppDelegate.this.pHTMLVIEW.b, new ViewGroup.LayoutParams(-1, -1));
            AppDelegate.this.frameLayout.addView(AppDelegate.this.pMEDIT.b, new ViewGroup.LayoutParams(-1, -1));
            AppDelegate.this.mView.a(9);
            return;
            AppDelegate.this.googleSignIn();
            return;
            AppDelegate.this.setNavigationBarHide(((Bundle)localObject1).getBoolean("isHide"));
            return;
          }
          catch (Throwable paramAnonymousMessage)
          {
            for (;;) {}
          }
        }
      };
      if (this.mHandler == null) {
        this.mHandler = new Handler();
      }
      this.mAudioManager = ((AudioManager)appDelegate.getSystemService("audio"));
      paramBundle = new IntentFilter();
      paramBundle.addAction("android.media.RINGER_MODE_CHANGED");
      paramBundle.addAction("android.intent.action.HEADSET_PLUG");
      registerReceiver(mReceiver, paramBundle);
      this.mHelper = new jp.gungho.a.d(this, "CONSTRUCT_YOUR_KEY_AND_PLACE_IT_HERE");
      this.mHelper.a(false);
      this.mHelper.a(new d.d()
      {
        public void a(jp.gungho.a.e paramAnonymouse)
        {
          if (!paramAnonymouse.c()) {}
          while ((AppDelegate.this.mHelper == null) || (AppDelegate.this.mHelper.d())) {
            return;
          }
          AppDelegate.this.mHelper.a(AppDelegate.this.mGotInventoryListener);
        }
      });
      this.mFbCallbackManager = CallbackManager.Factory.create();
      LoginManager.getInstance().registerCallback(this.mFbCallbackManager, new FacebookCallback()
      {
        public void a(LoginResult paramAnonymousLoginResult)
        {
          AppDelegate.access$2702(AppDelegate.this, AccessToken.getCurrentAccessToken());
          AppDelegate.this.onSocialLoggedIn();
        }
        
        public void onCancel()
        {
          AppDelegate.this.onSocialCancelled();
        }
        
        public void onError(FacebookException paramAnonymousFacebookException)
        {
          AppDelegate.this.onSocialError(-1);
        }
      });
      createGoogleClient();
      jp.gungho.a.a.a(getApplicationContext());
      this.audioPlayer.a(getApplicationContext(), this.frameLayout);
      return;
      bool = false;
      break;
    }
  }
  
  protected void onDestroy()
  {
    unregisterReceiver(mReceiver);
    if ((getViewInitFlag()) && (!this.mPaused))
    {
      applicationWillTerminate(false);
      this.mPaused = true;
    }
    if (this.mHelper != null) {
      this.mHelper.a();
    }
    this.mHelper = null;
    _izDeviceExit();
    _izFontExit();
    _izHttpExit();
    _izLocaleExit();
    _izSndSeExit();
    _izSndAvpRelease();
    if (this.mImgView != null) {
      this.mImgView = null;
    }
    if (this.pHTMLVIEW != null) {
      this.pHTMLVIEW = null;
    }
    if (this.pMEDIT != null) {
      this.pMEDIT = null;
    }
    if (this.mView != null) {
      this.mView = null;
    }
    super.onDestroy();
  }
  
  public native void onDrawFrame();
  
  public native boolean onKeyEvent(int paramInt1, int paramInt2, long paramLong);
  
  public void onLowMemory()
  {
    super.onLowMemory();
  }
  
  protected void onPause()
  {
    if (this.mView != null)
    {
      this.mView.onPause();
      if (getViewInitFlag())
      {
        _izSndAvpExecPause(true);
        if (!this.mPaused)
        {
          applicationDidEnterBackground();
          this.mPaused = true;
        }
      }
    }
    super.onPause();
  }
  
  public void onRequestPermissionsResult(int paramInt, String[] paramArrayOfString, int[] paramArrayOfInt)
  {
    if (paramInt == this.mPermissionsReqNum)
    {
      if (paramArrayOfInt[0] != 0) {
        break label53;
      }
      this.mPermissionsResult = true;
      switch (paramInt)
      {
      }
    }
    for (;;)
    {
      this.mPermissionsResultBusy = false;
      return;
      dataInstall();
      continue;
      label53:
      this.mPermissionsResult = false;
      switch (paramInt)
      {
      default: 
        break;
      case 2: 
        this.recv = 3;
      }
    }
  }
  
  protected void onRestart()
  {
    if (getViewInitFlag()) {}
    super.onRestart();
  }
  
  protected void onResume()
  {
    checkTool();
    if (((getNavibar()) || (_izDevGetBuild_SDK_INT() < 19)) || (this.mView != null))
    {
      this.mView.onResume();
      if (getViewInitFlag())
      {
        _izSndAvpExecPause(false);
        if (this.mPaused) {
          applicationWillEnterForeground();
        }
      }
      setNavigationBarHide(this.isNavibarHide);
    }
    this.mPaused = false;
    cancelStaminaNotif();
    super.onResume();
  }
  
  public native void onSocialCancelled();
  
  public native void onSocialError(int paramInt);
  
  public native void onSocialLoggedIn();
  
  protected void onStart()
  {
    super.onStart();
    this.audioPlayer.a();
  }
  
  protected void onStop()
  {
    super.onStop();
    if ((getViewInitFlag()) && (!this.mPaused))
    {
      applicationDidEnterBackground();
      this.mPaused = true;
    }
    this.audioPlayer.b();
  }
  
  public native void onSurfaceChanged(int paramInt1, int paramInt2, int paramInt3, int paramInt4, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
  
  public native void onSurfaceCreated(AssetManager paramAssetManager);
  
  public native void onSurfaceDestroy();
  
  public native void onSurfacePause();
  
  public native void onSurfaceResume();
  
  public native void onTouchEvent(float paramFloat1, float paramFloat2, int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong, int paramInt5);
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent)
  {
    if (getViewInitFlag())
    {
      int i = paramMotionEvent.getAction();
      int j = paramMotionEvent.getPointerCount();
      int k = (0xFF00 & i) >> 8;
      float f1 = paramMotionEvent.getX(k);
      float f2 = paramMotionEvent.getY(k);
      long l = paramMotionEvent.getEventTime();
      float f3 = this.mView.q();
      float f4 = this.statusBarHeight;
      if (k == 0) {
        onTouchEvent(f1 - 0.0F, f2 - (f3 * 2.0F + f4), k, 0, j, i, l, i & 0xFF);
      }
      if ((i & 0xFF) == 0)
      {
        this.mView.setFocusable(true);
        this.mView.setFocusableInTouchMode(true);
        this.mView.requestFocus();
      }
    }
    return super.onTouchEvent(paramMotionEvent);
  }
  
  public void onWindowFocusChanged(boolean paramBoolean)
  {
    this.mFocus = paramBoolean;
    if (this.bErrorDialog) {
      return;
    }
    if (getViewInitFlag())
    {
      if (!paramBoolean) {
        break label94;
      }
      _izSndAvpExecPause(false);
      applicationDidBecomeActive();
    }
    for (;;)
    {
      super.onWindowFocusChanged(paramBoolean);
      if (((this.mView != null) && (!this.mPaused)) && (!paramBoolean)) {
        break;
      }
      updateStatusBarHeight();
      if (((!getNavibar()) && (_izDevGetBuild_SDK_INT() >= 19)) && (_izDevGetBuild_SDK_INT() < 19)) {
        break;
      }
      setNavigationBarHandle(this.isNavibarHide);
      return;
      label94:
      _izSndAvpExecPause(true);
      applicationWillResignActive();
    }
  }
  
  void openAlertDialog(String paramString1, String paramString2, int paramInt)
  {
    Message localMessage = handler.obtainMessage();
    Bundle localBundle = new Bundle();
    localBundle.putString("title", paramString1);
    localBundle.putString("message", paramString2);
    this.mPositiveButtonListener = null;
    this.mNegativeButtonListener = null;
    switch (paramInt)
    {
    default: 
      localBundle.putString("positive", getString(2131492964));
      this.mPositiveButtonListener = new DialogInterface.OnClickListener()
      {
        public void onClick(DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt)
        {
          if ((AppDelegate.this.getViewInitFlag()) && (!AppDelegate.this.mPaused))
          {
            AppDelegate.this.mView.c();
            AppDelegate.access$4102(AppDelegate.this, true);
          }
          AppDelegate.this.finish();
        }
      };
    }
    for (;;)
    {
      this.mAlertDialog = null;
      this.mAlertDialog = new AlertDialog.Builder(this);
      localMessage.what = 13;
      localMessage.setData(localBundle);
      handler.sendMessage(localMessage);
      return;
      localBundle.putString("negative", getString(2131492959));
      localBundle.putString("positive", getString(2131492980));
      continue;
      localBundle.putString("negative", getString(2131492897));
      this.mNegativeButtonListener = new DialogInterface.OnClickListener()
      {
        public void onClick(DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt)
        {
          paramAnonymousDialogInterface.cancel();
        }
      };
      localBundle.putString("positive", getString(2131492964));
      this.mPositiveButtonListener = new DialogInterface.OnClickListener()
      {
        public void onClick(DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt)
        {
          if ((AppDelegate.this.getViewInitFlag()) && (!AppDelegate.this.mPaused))
          {
            AppDelegate.this.mView.b();
            AppDelegate.access$4102(AppDelegate.this, true);
          }
        }
      };
      continue;
      localBundle.putString("negative", getString(2131492958));
      localBundle.putString("positive", getString(2131492964));
      continue;
      localBundle.putString("positive", getString(2131492964));
      this.mPositiveButtonListener = new DialogInterface.OnClickListener()
      {
        public void onClick(DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt) {}
      };
    }
  }
  
  public void openApplicationSettings()
  {
    Intent localIntent = new Intent("android.settings.APPLICATION_DETAILS_SETTINGS");
    localIntent.setData(Uri.fromParts("package", getPackageName(), null));
    startActivity(localIntent);
  }
  
  void openGooglePlay()
  {
    String str = getApplicationContext().getPackageName();
    startActivity(new Intent("android.intent.action.VIEW", Uri.parse("market://details?id=" + str)));
  }
  
  void openURL(String paramString)
  {
    paramString = new Intent("android.intent.action.VIEW", Uri.parse(paramString));
    paramString.setFlags(268435456);
    startActivity(paramString);
  }
  
  public native String padVulgarityCheck(String paramString);
  
  String pasteFromClipboard()
  {
    try
    {
      String str = ((ClipboardManager)getSystemService("clipboard")).getPrimaryClip().getItemAt(0).getText().toString();
      return str;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return null;
  }
  
  public native void productsRequest(String[] paramArrayOfString1, String[] paramArrayOfString2, String[] paramArrayOfString3, String[] paramArrayOfString4, String paramString, float[] paramArrayOfFloat, int paramInt);
  
  boolean purchaseProduct(String paramString1, String paramString2, String paramString3)
  {
    if ((this.mHelper == null) || (this.mPurchaseFinishedListener == null) || (this.mHelper.d())) {
      return false;
    }
    this.mHelper.a(this, paramString1, 10001, this.mPurchaseFinishedListener);
    return true;
  }
  
  void purchaseSend(String paramString, double paramDouble, int paramInt)
  {
    if ((paramString != null) && (paramString.length() > 0)) {
      Tracker.sendEvent(new Tracker.Event(6).setCurrency("USD").setPrice(paramDouble).setUserId(String.valueOf(paramInt)).setContentId(paramString));
    }
  }
  
  void raiseKeyboard(int paramInt)
  {
    Object localObject = getTextField(paramInt);
    if ((localObject != null) && (((d)localObject).a != null))
    {
      localObject = handler.obtainMessage();
      Bundle localBundle = new Bundle();
      localBundle.putInt("hash", paramInt);
      ((Message)localObject).what = 31;
      ((Message)localObject).setData(localBundle);
      handler.sendMessage((Message)localObject);
    }
  }
  
  void rankUpSend(String paramString, int paramInt)
  {
    Bundle localBundle = new Bundle();
    localBundle.putInt("rank", paramInt);
    localBundle.putString("userId", paramString);
    AppEventsLogger.newLogger(this).logEvent("RANK_ACHIEVED", localBundle);
    Tracker.sendEvent(new Tracker.Event("RANK_ACHIEVED").setUserId(paramString).addCustom("rank", paramInt));
  }
  
  public native void readStremCB(byte[] paramArrayOfByte, long paramLong, int paramInt);
  
  public native void requestDidFailWithError();
  
  public void requestPermissions(String paramString, int paramInt)
  {
    if (_izDevGetBuild_SDK_INT() >= 23)
    {
      this.mPermissionsResult = false;
      this.mPermissionsResultBusy = true;
      this.mPermissionsReqNum = paramInt;
      paramInt = this.mPermissionsReqNum;
      android.support.v4.app.a.a(this, new String[] { paramString }, paramInt);
    }
  }
  
  void requestProductList(String[] paramArrayOfString)
  {
    Message localMessage = handler.obtainMessage();
    localMessage.what = 15;
    Bundle localBundle = new Bundle();
    localBundle.putStringArray("moreSkus", paramArrayOfString);
    localMessage.setData(localBundle);
    handler.sendMessage(localMessage);
  }
  
  public native void requestPurchaseResponseOk();
  
  void restoreRewardTransactions()
  {
    Message localMessage = handler.obtainMessage();
    localMessage.what = 39;
    localMessage.obj = this.mCheckInventoryListener;
    handler.sendMessage(localMessage);
    enableRewardCheck(true);
  }
  
  void restoreTransactions()
  {
    Message localMessage = handler.obtainMessage();
    localMessage.what = 14;
    handler.sendMessage(localMessage);
  }
  
  public native void ringerModeChanged(boolean paramBoolean);
  
  public native boolean saveDataInstallUpdate(String paramString);
  
  public native boolean saveExtDownload(String paramString, byte[] paramArrayOfByte, int paramInt);
  
  public void saveSharedPreferencesString(String paramString1, String paramString2, String paramString3)
  {
    try
    {
      getSharedPreferences(paramString1).edit().putString(paramString2, paramString3).commit();
      return;
    }
    catch (Exception paramString1)
    {
      paramString1.printStackTrace();
    }
  }
  
  int secondsFromGMT()
  {
    return TimeZone.getDefault().getRawOffset() / 1000;
  }
  
  public native void setApiResShopStone(int paramInt);
  
  public native void setApiReward(int paramInt1, int paramInt2);
  
  public void setAppRestart()
  {
    this.mView.a();
  }
  
  public native void setAsyncLoader(int paramInt, String paramString);
  
  public void setAuthState(int paramInt)
  {
    this.authState = paramInt;
  }
  
  public native void setBgColor(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  void setBroadcastReceive(boolean paramBoolean)
  {
    this.isBroadcastReceiv = paramBoolean;
  }
  
  void setClipboard(String paramString)
  {
    try
    {
      paramString = new ClipData.Item(paramString);
      paramString = new ClipData(new ClipDescription("text_data", new String[] { "text/plain" }), paramString);
      ((ClipboardManager)getSystemService("clipboard")).setPrimaryClip(paramString);
      return;
    }
    catch (Exception paramString) {}
  }
  
  void setColor(int paramInt)
  {
    paint.setColor(paramInt);
  }
  
  void setColor(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    paint.setColor(Color.argb(paramInt4, paramInt1, paramInt2, paramInt3));
  }
  
  void setFullScreen()
  {
    Message localMessage = handler.obtainMessage();
    localMessage.what = 12;
    handler.sendMessage(localMessage);
  }
  
  void setNavigationBarHandle(boolean paramBoolean) {}
  
  void setNavigationBarHide(boolean paramBoolean) {}
  
  void setSecure()
  {
    if (_izDevGetBuild_SDK_INT() > 16)
    {
      Message localMessage = handler.obtainMessage();
      localMessage.what = 34;
      handler.sendMessage(localMessage);
    }
  }
  
  void setSize(int paramInt, float paramFloat)
  {
    if (paramFloat < 0.0F) {
      paramFloat = 10.0F;
    }
    for (;;)
    {
      float f;
      if (paramInt == 0)
      {
        paint.setTypeface(Typeface.defaultFromStyle(0));
        f = paramFloat;
      }
      for (;;)
      {
        paint.setTextSize(f);
        font = paint.getFontMetrics();
        if (paramFloat >= -font.ascent + font.descent) {
          break;
        }
        f -= 0.1F;
        continue;
        paint.setStyle(Paint.Style.FILL_AND_STROKE);
        paint.setStrokeWidth(1.2F);
        f = paramFloat;
      }
      return;
    }
  }
  
  void setStaminaNotif(long paramLong, String paramString)
  {
    if (this.notification != null) {
      this.notification.a(paramLong, paramString);
    }
  }
  
  void setString(String paramString)
  {
    Message localMessage = handler.obtainMessage();
    Bundle localBundle = new Bundle();
    localBundle.putString("string", paramString);
    localMessage.what = 20;
    localMessage.setData(localBundle);
    handler.sendMessage(localMessage);
  }
  
  public View setSystemUiInvisilityMode()
  {
    try
    {
      View localView = getWindow().getDecorView();
      return localView;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return null;
  }
  
  public void setSystemUiVisilityMode()
  {
    if ((!getNavibar()) && (_izDevGetBuild_SDK_INT() >= 19)) {}
    try
    {
      this.mDisptLatch = new CountDownLatch(1);
      appDelegate.runOnUiThread(new Runnable()
      {
        public void run()
        {
          AppDelegate.this.getWindow().getDecorView().setSystemUiVisibility(0);
        }
      });
      return;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
  }
  
  void setTextFieldEnable(int paramInt, boolean paramBoolean)
  {
    Object localObject = getTextField(paramInt);
    if ((localObject != null) && (((d)localObject).a != null))
    {
      localObject = handler.obtainMessage();
      Bundle localBundle = new Bundle();
      localBundle.putInt("hash", paramInt);
      localBundle.putBoolean("flag", paramBoolean);
      ((Message)localObject).what = 30;
      ((Message)localObject).setData(localBundle);
      handler.sendMessage((Message)localObject);
    }
  }
  
  void setTextFieldText(int paramInt, String paramString)
  {
    setTextFieldText(paramInt, paramString, 0);
  }
  
  void setTextFieldText(int paramInt1, String paramString, int paramInt2)
  {
    if (getTextField(paramInt1) != null)
    {
      Message localMessage = handler.obtainMessage();
      Bundle localBundle = new Bundle();
      localBundle.putString("text", paramString);
      localBundle.putInt("offset", paramInt2);
      localBundle.putInt("hash", paramInt1);
      localMessage.what = 5;
      localMessage.setData(localBundle);
      handler.sendMessage(localMessage);
    }
  }
  
  void setUserID(String paramString)
  {
    AppEventsLogger.setUserID(paramString);
  }
  
  public void setupMainWindowDisplayMode()
  {
    if ((!setupWindowDisplayMode()) && (!getNavibar()) && (_izDevGetBuild_SDK_INT() >= 19)) {}
    try
    {
      this.mDisptLatch = new CountDownLatch(1);
      appDelegate.runOnUiThread(new Runnable()
      {
        public void run()
        {
          AppDelegate.this.setupWindowDisplayMode();
          if (AppDelegate.this.mDisptLatch != null) {
            AppDelegate.this.mDisptLatch.countDown();
          }
        }
      });
      this.mDisptLatch.await();
      return;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
  }
  
  public boolean setupWindowDisplayMode()
  {
    try
    {
      setSystemUiInvisilityMode().setOnSystemUiVisibilityChangeListener(new View.OnSystemUiVisibilityChangeListener()
      {
        public void onSystemUiVisibilityChange(int paramAnonymousInt)
        {
          new Handler().postDelayed(new Runnable()
          {
            public void run()
            {
              AppDelegate.this.setSystemUiInvisilityMode();
            }
          }, 2000L);
        }
      });
      return true;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return false;
  }
  
  void sndPoolPause(int paramInt1, int paramInt2)
  {
    if (this.sndPool != null)
    {
      if (this.sndPoolState[paramInt1][paramInt2] == 4114) {
        this.sndPool.pause(this.sndPoolId[paramInt1][paramInt2]);
      }
      this.sndPoolState[paramInt1][paramInt2] = 'ဓ';
    }
  }
  
  void sndPoolPlay(int paramInt1, int paramInt2, float paramFloat1, float paramFloat2, int paramInt3, int paramInt4, float paramFloat3)
  {
    if (this.sndPool != null) {}
    try
    {
      int i = this.mAudioManager.getRingerMode();
      if (_izDevGetRingerModeState() != i) {
        _izDevSetRingerModeState(i);
      }
      if (!_izDevGetRingerMode())
      {
        this.sndPoolStopTime[paramInt1][paramInt2] = (System.currentTimeMillis() + this.sndPlayTime[paramInt1][paramInt2]);
        this.sndPoolState[paramInt1][paramInt2] = 'ဒ';
        Message localMessage = handler.obtainMessage();
        Bundle localBundle = new Bundle();
        localBundle.putInt("soundID", this.sndPoolId[paramInt1][paramInt2]);
        localBundle.putFloat("leftVolume", paramFloat1);
        localBundle.putFloat("rightVolume", paramFloat2);
        localBundle.putInt("priority", paramInt3);
        localBundle.putInt("loop", paramInt4);
        localBundle.putFloat("rate", paramFloat3);
        localMessage.what = 16;
        localMessage.setData(localBundle);
        handler.sendMessage(localMessage);
      }
      return;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
  }
  
  void sndPoolSetVolume(int paramInt1, int paramInt2, float paramFloat1, float paramFloat2)
  {
    if (this.sndPool != null) {
      this.sndPool.setVolume(this.sndPoolId[paramInt1][paramInt2], paramFloat1, paramFloat2);
    }
  }
  
  int sndPoolState(int paramInt1, int paramInt2)
  {
    if (this.sndPoolState[paramInt1][paramInt2] == 4114)
    {
      long l = System.currentTimeMillis();
      if (this.sndPoolStopTime[paramInt1][paramInt2] <= l)
      {
        sndPoolStop(paramInt1, paramInt2);
        this.sndPoolStopTime[paramInt1][paramInt2] = 0L;
        this.sndPoolState[paramInt1][paramInt2] = 'န';
      }
    }
    return this.sndPoolState[paramInt1][paramInt2];
  }
  
  void sndPoolStop(int paramInt1, int paramInt2)
  {
    if (this.sndPool != null)
    {
      this.sndPoolStopTime[paramInt1][paramInt2] = 0L;
      this.sndPoolState[paramInt1][paramInt2] = 'န';
    }
  }
  
  void startAd() {}
  
  public native void texReloadAll();
  
  void textFieldClose(int paramInt)
  {
    d locald = getTextField(paramInt);
    if ((locald != null) && (locald.a != null) && (locald.a.getVisibility() == 0))
    {
      ((InputMethodManager)getSystemService("input_method")).hideSoftInputFromWindow(locald.a.getWindowToken(), 2);
      if ((!getNavibar()) && (_izDevGetBuild_SDK_INT() >= 19)) {
        setNavigationBarHide(this.isNavibarHide);
      }
      this.inEditing = false;
    }
  }
  
  public native int textFieldDidChange(String paramString, StringBuffer paramStringBuffer);
  
  public native boolean textFieldShouldChangeCharactersInRange(int paramInt1, int paramInt2, String paramString1, String paramString2);
  
  void textFieldTextRangeFromPosition(int paramInt1, int paramInt2)
  {
    d locald = getTextField(paramInt1);
    if ((locald != null) && (locald.a != null))
    {
      paramInt2 = locald.a.getSelectionStart() + paramInt2;
      if (paramInt2 <= locald.a.length()) {
        break label70;
      }
      paramInt1 = locald.a.length();
    }
    for (;;)
    {
      locald.a.setSelection(0, locald.a.length());
      locald.a.setSelection(paramInt1);
      return;
      label70:
      paramInt1 = paramInt2;
      if (paramInt2 < 0) {
        paramInt1 = 0;
      }
    }
  }
  
  void textViewTextResize(TextView paramTextView, float paramFloat)
  {
    float f1 = paramTextView.getTextSize();
    Paint localPaint = new Paint();
    localPaint.setTextSize(paint.getTextSize());
    for (;;)
    {
      localPaint.setTextSize(f1);
      Paint.FontMetrics localFontMetrics = localPaint.getFontMetrics();
      float f2 = -localFontMetrics.top;
      if (paramFloat >= localFontMetrics.descent + f2) {
        break;
      }
      f1 -= 0.1F;
    }
    paramTextView.setTextSize(0, f1);
  }
  
  double timeIntervalSince1970(long paramLong)
  {
    return paramLong;
  }
  
  void trackLogin(String paramString) {}
  
  void tutorialStart(String paramString)
  {
    Bundle localBundle = new Bundle();
    localBundle.putString("userId", paramString);
    AppEventsLogger.newLogger(this).logEvent("TUTORIAL_START", localBundle);
    Tracker.sendEvent(new Tracker.Event("TUTORIAL_START").setUserId(paramString));
  }
  
  public void updateNavigationBarHeight()
  {
    if (Build.VERSION.SDK_INT < 20)
    {
      this.navigationBarHeight = 0;
      return;
    }
    int i = getDisplaySize().y;
    int j = getRealSize().y;
    if (j > i)
    {
      this.navigationBarHeight = (j - i);
      return;
    }
    this.navigationBarHeight = 0;
  }
  
  public void updateStatusBarHeight()
  {
    Rect localRect = new Rect();
    if (this.statusBarHeight <= 0)
    {
      appDelegate.getWindow().getDecorView().getWindowVisibleDisplayFrame(localRect);
      this.statusBarHeight = localRect.top;
    }
  }
  
  public void updateViewHeight()
  {
    View localView = this.mView.getRootView();
    if (localView == null) {
      return;
    }
    Rect localRect = new Rect();
    localView.getWindowVisibleDisplayFrame(localRect);
    this.appViewHeight = (localRect.bottom - localRect.top);
  }
  
  public native boolean viewDidLoad();
  
  int webViewPosUpd(int paramInt)
  {
    if (this.pUiWebView == null) {}
    do
    {
      return 0;
      if (this.bWebLoaded) {
        break;
      }
    } while (paramInt >= 0);
    delWebView();
    return 0;
    if (paramInt < 0) {
      this.webViewYtgt = ((short)(int)(this.webViewStartLine + this.webBounds.bottom / 2.0F));
    }
    this.webViewY = ((this.webViewYtgt - this.webViewY) / 4.0F + this.webViewY);
    this.webViewPos_y = ((int)(this.webViewY + 0.5F));
    if (this.webViewPos_y == this.webViewYtgt) {
      this.webViewYtgt = ((short)(int)this.webViewPos_y);
    }
    if ((paramInt < 0) && (this.webViewPos_y - this.webBounds.bottom / 2.0F >= this.webViewStartLine))
    {
      delWebView();
      return 0;
    }
    return (short)(int)(this.webViewStartLine - this.webViewPos_y + this.webBounds.bottom / 2.0F);
  }
  
  class a
    implements InputFilter
  {
    a() {}
    
    public CharSequence filter(CharSequence paramCharSequence, int paramInt1, int paramInt2, Spanned paramSpanned, int paramInt3, int paramInt4)
    {
      if (paramCharSequence.toString().matches("^[a-zA-Z0-9]+$")) {
        return paramCharSequence;
      }
      return "";
    }
  }
  
  class b
    extends Thread
  {
    int a;
    String b;
    
    public b(int paramInt, String paramString)
    {
      this.a = paramInt;
      this.b = new String(paramString);
    }
    
    public void run()
    {
      AppDelegate.this.setAsyncLoader(this.a, this.b);
    }
  }
}


/* Location:              C:\adcap\Pad2\jd-gui-windows-1.4.0\classes-dex2jar.jar!\jp\gungho\padEN\AppDelegate.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */