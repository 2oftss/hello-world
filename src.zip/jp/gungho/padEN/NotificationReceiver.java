package jp.gungho.padEN;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.os.Build.VERSION;
import android.support.v4.app.v.c;

public class NotificationReceiver
  extends BroadcastReceiver
{
  public void onReceive(Context paramContext, Intent paramIntent)
  {
    Object localObject = new Intent(paramContext, AppDelegate.class);
    ((Intent)localObject).addFlags(536870912);
    PendingIntent.getActivity(paramContext, 0, (Intent)localObject, 0);
    paramIntent = (NotificationManager)paramContext.getSystemService("notification");
    localObject = PendingIntent.getActivity(paramContext, 0, (Intent)localObject, 134217728);
    String str = paramContext.getString(2131492894);
    if (Build.VERSION.SDK_INT >= 26) {
      paramIntent.createNotificationChannel(new NotificationChannel("NOTIF_CHANNEL", str, 3));
    }
    paramIntent = new v.c(paramContext, "NOTIF_CHANNEL").a(BitmapFactory.decodeResource(paramContext.getResources(), 2131099789)).a(2131099811).a(paramContext.getString(2131492894)).b(paramContext.getString(2131492972)).b(1).a((PendingIntent)localObject).a(true).a(System.currentTimeMillis());
    ((NotificationManager)paramContext.getSystemService("notification")).notify(0, paramIntent.a());
  }
}


/* Location:              C:\adcap\Pad2\jd-gui-windows-1.4.0\classes-dex2jar.jar!\jp\gungho\padEN\NotificationReceiver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */