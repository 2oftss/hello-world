package jp.gungho.padEN;

import android.content.Context;
import android.graphics.Paint;
import android.widget.TextView;

class a
  extends TextView
{
  public a(Context paramContext)
  {
    super(paramContext);
  }
  
  private void a()
  {
    float f3 = 24.0F;
    Paint localPaint = new Paint();
    int i = getWidth();
    float f1 = getTextSize();
    localPaint.setTextSize(f1);
    float f2 = localPaint.measureText(getText().toString());
    if (i < f2) {
      if (24.0F >= f1) {
        f1 = f3;
      }
    }
    for (;;)
    {
      setTextSize(0, f1);
      return;
      f1 -= 1.0F;
      localPaint.setTextSize(f1);
      f2 = localPaint.measureText(getText().toString());
      break;
    }
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
    a();
  }
}


/* Location:              C:\adcap\Pad2\jd-gui-windows-1.4.0\classes-dex2jar.jar!\jp\gungho\padEN\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */