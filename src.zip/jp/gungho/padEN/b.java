package jp.gungho.padEN;

import android.content.Context;
import android.graphics.Canvas;
import android.widget.ImageView;

class b
  extends ImageView
{
  public boolean a = false;
  
  b(Context paramContext)
  {
    super(paramContext);
  }
  
  protected void onDraw(Canvas paramCanvas)
  {
    this.a = true;
    super.onDraw(paramCanvas);
  }
}


/* Location:              C:\adcap\Pad2\jd-gui-windows-1.4.0\classes-dex2jar.jar!\jp\gungho\padEN\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */