package jp.gungho.padEN;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

public class c
{
  Intent a = null;
  private Context b;
  private PendingIntent c = null;
  
  c(Context paramContext)
  {
    this.b = paramContext;
    this.a = new Intent(paramContext, NotificationReceiver.class);
  }
  
  public void a()
  {
    AlarmManager localAlarmManager = (AlarmManager)this.b.getSystemService("alarm");
    this.c = PendingIntent.getBroadcast(this.b, 0, this.a, 134217728);
    localAlarmManager.cancel(this.c);
  }
  
  public void a(long paramLong, String paramString)
  {
    paramString = (AlarmManager)this.b.getSystemService("alarm");
    this.c = PendingIntent.getBroadcast(this.b, 0, this.a, 134217728);
    paramString.set(1, System.currentTimeMillis() + paramLong, this.c);
  }
}


/* Location:              C:\adcap\Pad2\jd-gui-windows-1.4.0\classes-dex2jar.jar!\jp\gungho\padEN\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */