package jp.gungho.padEN;

import android.content.Context;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.widget.EditText;

public class d
{
  public EditText a = null;
  private Context b;
  private String c = "";
  private a d;
  
  public d(Context paramContext)
  {
    this.b = paramContext;
  }
  
  public void a()
  {
    this.a = new EditText(this.b);
    if (this.c != null)
    {
      this.a.setText(this.c);
      this.a.setSelection(0, this.a.length());
      this.a.setSelection(this.c.length());
      this.c = null;
    }
  }
  
  public void a(String paramString)
  {
    if (this.a == null) {
      this.c = new String(paramString);
    }
  }
  
  public void a(boolean paramBoolean)
  {
    if (paramBoolean)
    {
      this.d = new a((AppDelegate)this.b);
      this.a.addTextChangedListener(this.d);
    }
  }
  
  public String b()
  {
    if (this.a == null) {
      return this.c;
    }
    return this.a.getText().toString();
  }
  
  public void finalize()
  {
    this.a = null;
  }
  
  class a
    implements TextWatcher
  {
    AppDelegate a;
    String b;
    boolean c;
    
    public a(AppDelegate paramAppDelegate)
    {
      this.a = paramAppDelegate;
      this.b = null;
      this.c = false;
    }
    
    public void afterTextChanged(Editable paramEditable)
    {
      int i;
      int j;
      if (this.c)
      {
        Object localObject = new StringBuffer();
        paramEditable = new String(paramEditable.toString());
        i = this.a.textFieldDidChange(paramEditable, (StringBuffer)localObject);
        localObject = new String(((StringBuffer)localObject).toString());
        if (!paramEditable.equals(localObject))
        {
          if (d.this.a.getVisibility() != 0) {
            d.this.a.setVisibility(0);
          }
          j = d.this.a.getSelectionStart() + i;
          d.this.a.setText((CharSequence)localObject);
          if (j <= ((String)localObject).length()) {
            break label164;
          }
          i = ((String)localObject).length();
          d.this.a.setSelection(0, ((String)localObject).length());
          d.this.a.setSelection(i);
        }
      }
      for (;;)
      {
        this.b = null;
        this.c = false;
        return;
        label164:
        i = j;
        if (j >= 0) {
          break;
        }
        i = 0;
        break;
        i = d.this.a.getSelectionStart();
        d.this.a.setText(this.b);
        if (!TextUtils.isEmpty(this.b))
        {
          d.this.a.setSelection(0, this.b.length());
          d.this.a.setSelection(i + 0);
        }
      }
    }
    
    public void beforeTextChanged(CharSequence paramCharSequence, int paramInt1, int paramInt2, int paramInt3)
    {
      this.b = null;
      this.b = new String(paramCharSequence.toString());
      this.c = false;
    }
    
    public void onTextChanged(CharSequence paramCharSequence, int paramInt1, int paramInt2, int paramInt3)
    {
      this.c = this.a.textFieldShouldChangeCharactersInRange(paramInt1, paramInt3, paramCharSequence.toString().substring(paramInt1, paramInt1 + paramInt3), this.b);
    }
  }
}


/* Location:              C:\adcap\Pad2\jd-gui-windows-1.4.0\classes-dex2jar.jar!\jp\gungho\padEN\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */