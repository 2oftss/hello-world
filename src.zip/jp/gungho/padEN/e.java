package jp.gungho.padEN;

import android.content.res.AssetManager;
import android.content.res.Resources;
import android.graphics.Point;
import android.graphics.Rect;
import android.opengl.GLSurfaceView;
import android.opengl.GLSurfaceView.Renderer;
import android.os.SystemClock;
import android.view.Display;
import android.view.WindowManager;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

class e
  extends GLSurfaceView
{
  private AppDelegate a;
  private AssetManager b;
  private a c;
  private float d = 0.6666667F;
  private float e = 0.6666667F;
  private float f = 1.0F;
  private float g = 1.0F;
  private float h = 0.0F;
  private float i = 0.0F;
  private float j = 640.0F;
  private float k = 960.0F;
  private float l = 0.0F;
  private float m = 0.0F;
  private float n = 640.0F;
  private float o = 960.0F;
  private float p = 0.0F;
  private float q = 0.0F;
  private float r = 0.0F;
  private int s;
  private int t = 0;
  private boolean u = false;
  private boolean v = false;
  
  public e(AppDelegate paramAppDelegate)
  {
    super(paramAppDelegate.getApplication());
    this.a = paramAppDelegate;
    this.c = new a();
    this.u = false;
    this.l = 0.0F;
    this.m = 0.0F;
    setRenderer(this.c);
  }
  
  int a(float paramFloat1, float paramFloat2, int paramInt)
  {
    float f2 = 960.0F;
    float f1 = f2;
    switch (paramInt)
    {
    default: 
      f1 = f2;
    case 1: 
      if (paramFloat1 <= paramFloat2) {
        if (640.0F / f1 > paramFloat1 / paramFloat2)
        {
          f2 = f1 * paramFloat1 / 640.0F;
          f1 = paramFloat1;
        }
      }
      break;
    }
    for (;;)
    {
      return (int)(f1 * (paramFloat2 - f2) + (paramFloat1 - f1) * f2);
      f1 = 1096.0F;
      break;
      f1 = 1251.0F;
      break;
      f1 = paramFloat2 * 640.0F / f1;
      f2 = paramFloat2;
      continue;
      if (f1 / 640.0F < paramFloat2 / paramFloat1)
      {
        f2 = f1 * paramFloat1 / 640.0F;
        f1 = paramFloat1;
      }
      else
      {
        f1 = paramFloat2 * 640.0F / f1;
        f2 = paramFloat2;
      }
    }
  }
  
  public void a()
  {
    this.t = 7;
  }
  
  public void a(int paramInt)
  {
    this.t = paramInt;
  }
  
  public void a(int paramInt1, int paramInt2, int paramInt3)
  {
    this.r = 0.0F;
    if (this.a._izDevGetBuild_SDK_INT() >= 19)
    {
      new Rect();
      Point localPoint = new Point();
      this.a.getWindowManager().getDefaultDisplay().getSize(localPoint);
      if (paramInt2 > localPoint.y)
      {
        this.m = paramInt2;
        this.q = this.a.getNavigationBarHeight();
        label78:
        this.l = paramInt1;
        this.d = (this.l / this.m);
      }
    }
    float f1;
    float f2;
    float f3;
    int i1;
    int i2;
    int i3;
    for (;;)
    {
      f1 = this.m;
      f1 = this.l / 640.0F;
      f1 = this.l;
      f1 = this.m;
      f2 = this.l / 640.0F;
      f3 = this.l;
      float f4 = this.l;
      f4 = this.m / 1096.0F;
      f4 = this.m;
      switch (paramInt3)
      {
      default: 
        this.s = 0;
        paramInt3 = a(paramInt1, paramInt2, 1);
        i1 = a(paramInt1, paramInt2, 2);
        i2 = a(paramInt1, paramInt2, 3);
        i3 = this.a._izDevGetBuild_SDK_INT();
        if (i3 >= 16) {
          break label838;
        }
        a(paramInt1, paramInt2, 1);
        return;
        this.m = paramInt2;
        this.r = 0.0F;
        break label78;
        this.d = (paramInt1 / paramInt2);
        this.l = paramInt1;
        this.m = paramInt2;
      }
    }
    this.e = 0.6666667F;
    this.n = 640.0F;
    this.o = 960.0F;
    this.s = 1;
    if (this.d > this.e)
    {
      this.j = (this.m / 960.0F * 640.0F);
      this.k = this.m;
      this.h = (0.0F - this.r);
      this.i = ((this.l - this.j) / 2.0F);
      this.f = (this.j / 640.0F);
      this.g = (this.k / 960.0F);
      return;
    }
    this.j = this.l;
    this.k = (this.l / 640.0F * 960.0F);
    this.h = ((this.m - this.k) / 2.0F - this.r + 0.0F);
    this.i = 0.0F;
    this.f = (this.j / 640.0F);
    this.g = (this.k / 960.0F);
    return;
    this.e = 0.5839416F;
    this.n = 640.0F;
    this.o = 1096.0F;
    this.s = 2;
    if (((f1 - f2 * 1096.0F) * f3 >= 0.0F) && (this.d < this.e))
    {
      this.j = this.l;
      this.k = (this.l / 640.0F * 1096.0F);
      this.h = ((this.m - this.k) / 2.0F - this.r + 0.0F);
      this.i = 0.0F;
      this.f = (this.j / 640.0F);
      this.g = (this.k / 1096.0F);
      return;
    }
    this.j = (this.m / 1096.0F * 640.0F);
    this.k = this.m;
    this.h = (0.0F - this.r + 0.0F);
    this.i = ((this.l - this.j) / 2.0F);
    this.f = (this.j / 640.0F);
    this.g = (this.k / 1096.0F);
    return;
    this.e = 0.5115907F;
    this.n = 640.0F;
    this.o = 1251.0F;
    this.s = 3;
    if (this.d < this.e)
    {
      this.j = this.l;
      this.k = (1251.0F * (this.l / 640.0F));
      this.h = ((this.m - this.k) / 2.0F - this.r + 0.0F);
      this.i = 0.0F;
      this.f = (this.j / 640.0F);
      this.g = (this.k / 1251.0F);
      return;
    }
    this.j = (this.m / 1251.0F * 640.0F);
    this.k = this.m;
    this.h = (0.0F - this.r + 0.0F);
    this.i = ((this.l - this.j) / 2.0F);
    this.f = (this.j / 640.0F);
    this.g = (this.k / 1251.0F);
    return;
    label838:
    if ((this.m > this.m / 960.0F * 640.0F) && (this.l >= 640.0F) && (this.m >= 1136.0F))
    {
      if ((i2 < i1) && (i2 < paramInt3) && (i3 >= 24))
      {
        a(paramInt1, paramInt2, 3);
        return;
      }
      if ((i1 < paramInt3) && (i1 < i2))
      {
        a(paramInt1, paramInt2, 2);
        return;
      }
      a(paramInt1, paramInt2, 1);
      return;
    }
    a(paramInt1, paramInt2, 1);
  }
  
  public void b()
  {
    this.v = true;
  }
  
  public void c()
  {
    this.t = 0;
    this.v = true;
  }
  
  public boolean d()
  {
    boolean bool = false;
    if (this.t >= 3) {
      bool = true;
    }
    return bool;
  }
  
  public int e()
  {
    return this.t;
  }
  
  public void f()
  {
    queueEvent(new Runnable()
    {
      public final void run()
      {
        e.a(e.this).onSurfacePause();
        e.a(e.this).setSecure();
      }
    });
  }
  
  public float g()
  {
    return this.h;
  }
  
  public float h()
  {
    return this.i;
  }
  
  public float i()
  {
    return this.j;
  }
  
  public float j()
  {
    return this.f;
  }
  
  public float k()
  {
    return this.g;
  }
  
  public float l()
  {
    return this.k;
  }
  
  public float m()
  {
    return this.l;
  }
  
  public float n()
  {
    return this.m;
  }
  
  public float o()
  {
    return this.n;
  }
  
  public void onPause()
  {
    if (this.t == 6) {
      queueEvent(new Runnable()
      {
        public final void run()
        {
          e.a(e.this).onSurfacePause();
        }
      });
    }
    this.u = true;
    super.onPause();
  }
  
  public void onResume()
  {
    if ((this.t >= 3) && (this.t <= 5)) {
      this.a.onSurfacePause();
    }
    this.u = false;
    super.onResume();
  }
  
  public float p()
  {
    return this.o;
  }
  
  public float q()
  {
    return this.r;
  }
  
  public int r()
  {
    return this.s;
  }
  
  public float s()
  {
    return 0.0F;
  }
  
  public class a
    implements GLSurfaceView.Renderer
  {
    public long a = 0L;
    public short b = 0;
    public long c = 0L;
    public long d = 0L;
    public float e = 0.0F;
    public long f = 0L;
    
    public a() {}
    
    public void onDrawFrame(GL10 paramGL10)
    {
      this.a = SystemClock.uptimeMillis();
      if ((float)this.a >= (float)this.d + 1000.0F)
      {
        this.d = this.a;
        this.e += this.b;
        this.b = 0;
        this.e = 0.0F;
      }
      this.b = ((short)(this.b + 1));
      if (e.b(e.this) == 0) {}
      for (;;)
      {
        this.f = SystemClock.uptimeMillis();
        return;
        if (e.b(e.this) == 1)
        {
          if (e.a(e.this).isImgViewDrew())
          {
            e.a(e.this).updateViewHeight();
            e.a(e.this, 2);
          }
        }
        else if (e.b(e.this) == 2)
        {
          if ((!e.c(e.this)) && (!e.d(e.this)) && (e.a(e.this).viewDidLoad())) {
            e.a(e.this, 3);
          }
        }
        else if (e.b(e.this) == 4)
        {
          int i = e.a(e.this).isInstallEnd();
          if (i == 1)
          {
            e.a(e.this).saveDataInstallUpdate(e.a(e.this).getInstallPath());
            e.a(e.this, 3);
          }
          else if (i != 0)
          {
            e.a(e.this, 3);
          }
        }
        else if (e.b(e.this) == 3)
        {
          e.a(e.this).imgViewClose();
          if (e.a(e.this).getUrlScheme() != null) {
            e.a(e.this).handleOpenURL(e.a(e.this).getUrlScheme(), e.a(e.this).getUrlQuery());
          }
          e.a(e.this, 5);
        }
        else if (e.b(e.this) == 7)
        {
          e.a(e.this).appRestart();
        }
        else if (e.b(e.this) != 8)
        {
          if (e.b(e.this) == 9)
          {
            e.a(e.this).texReloadAll();
            e.a(e.this, 6);
          }
          else if (!e.c(e.this))
          {
            if (!e.d(e.this)) {
              try
              {
                if (e.a(e.this).getBroadcastReceiver())
                {
                  e.a(e.this).ringerModeChanged(e.a(e.this)._izDevGetRingerMode());
                  e.a(e.this).setBroadcastReceive(false);
                }
                e.a(e.this).onDrawFrame();
                if (e.b(e.this) != 5) {
                  continue;
                }
                e.a(e.this, 6);
              }
              catch (Exception paramGL10)
              {
                paramGL10.printStackTrace();
              }
            }
          }
          else
          {
            e.a(e.this, 0);
            e.a(e.this).applicationWillTerminate(true);
            e.a(e.this).finish();
          }
        }
      }
    }
    
    public void onSurfaceChanged(GL10 paramGL10, int paramInt1, int paramInt2)
    {
      if (e.b(e.this) == 0) {}
      for (int i = e.a(e.this).loadDispType() & 0xF;; i = e.this.r())
      {
        e.this.a(paramInt1, paramInt2, i);
        e.a(e.this).onSurfaceChanged((int)e.this.m(), (int)e.this.n(), (int)e.this.o(), (int)e.this.p(), e.this.h(), e.this.g(), e.this.i(), e.this.l());
        if ((e.b(e.this) == 0) && (!e.c(e.this))) {
          e.a(e.this, 1);
        }
        return;
      }
    }
    
    public void onSurfaceCreated(GL10 paramGL10, EGLConfig paramEGLConfig)
    {
      e.a(e.this, e.a(e.this).getResources().getAssets());
      e.a(e.this).onSurfaceCreated(e.e(e.this));
    }
  }
}


/* Location:              C:\adcap\Pad2\jd-gui-windows-1.4.0\classes-dex2jar.jar!\jp\gungho\padEN\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */