package jp.gungho.padEN;

class f
  extends Thread
{
  int a;
  int b;
  int c;
  int d;
  int e;
  int f;
  int g;
  int h;
  int i;
  j[] j;
  double k;
  double l;
  float[] m;
  AppDelegate n;
  boolean o;
  double p;
  
  f(AppDelegate paramAppDelegate)
  {
    this.n = paramAppDelegate;
    this.o = false;
  }
  
  public void a()
  {
    this.b = 0;
    this.c = 0;
    this.a = 0;
    this.j = null;
    this.m = null;
    this.o = true;
    this.p = k();
    label186:
    double d1;
    double d2;
    do
    {
      for (;;)
      {
        try
        {
          if (this.a <= 0) {
            break;
          }
          if (this.b >= 4) {
            break label186;
          }
          localj = e();
          if (localj != null) {
            if (!localj.e) {}
          }
        }
        catch (Exception localException)
        {
          try
          {
            j localj;
            localj.e = false;
            if ((localj.p > 0.0D) && (k() - localj.p < 1.0D)) {
              Thread.sleep(3000L);
            }
            g localg = new g(this);
            localg.a(localj);
            localg.start();
            Thread.sleep(50L);
            this.c = ((int)(j() / 10.0F + 0.5F));
            this.p = k();
            continue;
          }
          finally {}
          localException = localException;
          localException.printStackTrace();
        }
        continue;
        Thread.sleep(50L);
      }
      Thread.sleep(250L);
      d1 = k();
      d2 = this.p;
    } while (d1 - d2 <= 600.0D);
    this.o = false;
  }
  
  public void a(int paramInt)
  {
    int i2 = 0;
    try
    {
      try
      {
        if (this.j != null) {
          d();
        }
        this.a = paramInt;
        this.j = new j[paramInt];
        this.k = k();
        this.l = this.k;
        this.d = -1;
        this.e = 1000;
        this.f = 0;
        this.i = 0;
        this.h = 0;
        this.m = new float[8];
        paramInt = 0;
        int i1;
        for (;;)
        {
          i1 = i2;
          if (paramInt >= 8) {
            break;
          }
          this.m[paramInt] = 0.0F;
          paramInt += 1;
        }
        while (i1 < this.a)
        {
          this.j[i1] = null;
          this.j[i1] = new j();
          this.j[i1].a();
          i1 += 1;
        }
        return;
      }
      finally {}
      return;
    }
    catch (Throwable localThrowable) {}
  }
  
  public void a(int paramInt1, int paramInt2, String paramString1, String paramString2, int paramInt3, int paramInt4, int paramInt5)
  {
    int i1 = 0;
    try
    {
      j[] arrayOfj = this.j;
      if (arrayOfj == null) {
        return;
      }
      while (i1 < this.a) {
        if (arrayOfj[i1].b == true)
        {
          i1 += 1;
        }
        else
        {
          arrayOfj[i1].b = true;
          arrayOfj[i1].f = new String(paramString1);
          arrayOfj[i1].g = new String(paramString2);
          arrayOfj[i1].h = paramInt4;
          arrayOfj[i1].l = paramInt5;
          arrayOfj[i1].i = 0;
          arrayOfj[i1].k = paramInt3;
          arrayOfj[i1].o = paramInt2;
          arrayOfj[i1].n = paramInt1;
          arrayOfj[i1].j = 0;
          arrayOfj[i1].p = 0.0D;
          this.f += 1;
        }
      }
      return;
    }
    finally {}
  }
  
  public void b() {}
  
  public void c() {}
  
  public void d()
  {
    int i1 = 0;
    try
    {
      j[] arrayOfj = this.j;
      this.j = null;
      this.a = 0;
      if (arrayOfj != null) {
        while (i1 < this.a)
        {
          arrayOfj[i1] = null;
          i1 += 1;
        }
      }
      System.gc();
      return;
    }
    finally {}
  }
  
  public j e()
  {
    int i2 = 0;
    Object localObject1;
    int i1;
    try
    {
      localObject1 = this.j;
      if (localObject1 != null) {
        break label149;
      }
      return null;
    }
    finally {}
    Object localObject3;
    if (i1 < this.a)
    {
      if ((localObject1[i1].b) && (!localObject1[i1].c) && (!localObject1[i1].e) && (!localObject1[i1].d))
      {
        localObject1[i1].d = true;
        localObject1 = localObject1[i1];
        return (j)localObject1;
      }
    }
    else
    {
      localObject3 = this.j;
      i1 = i2;
    }
    for (;;)
    {
      if (i1 < this.a)
      {
        if ((localObject3[i1].b) && (!localObject3[i1].c) && (localObject3[i1].d != true))
        {
          localObject3[i1].d = true;
          localObject3 = localObject3[i1];
          return (j)localObject3;
        }
      }
      else
      {
        return null;
        label149:
        i1 = 0;
        break;
        i1 += 1;
        break;
      }
      i1 += 1;
    }
  }
  
  public float f()
  {
    float f1 = 0.0F;
    if (this.g <= 0) {
      return -1.0F;
    }
    int i1 = 0;
    while (i1 < this.g)
    {
      f1 += this.m[i1];
      i1 += 1;
    }
    return f1 / this.g;
  }
  
  public int g()
  {
    return (int)(this.e / 10.0F + 0.5F);
  }
  
  public float h()
  {
    return this.e / 1000.0F;
  }
  
  public int i()
  {
    return this.f;
  }
  
  public int j()
  {
    for (;;)
    {
      try
      {
        Object localObject1 = this.j;
        if (localObject1 == null)
        {
          this.f = 0;
          this.e = 0;
          i1 = 0;
          this.e = i1;
          return i1;
        }
        int i2 = 0;
        long l1 = 0L;
        long l2 = 0L;
        int i1 = 0;
        if (i1 < this.a)
        {
          if (localObject1[i1].b)
          {
            l2 += localObject1[i1].h;
            if (localObject1[i1].c)
            {
              l1 += localObject1[i1].h;
            }
            else
            {
              i2 += 1;
              l1 = ((float)l1 + localObject1[i1].h * localObject1[i1].q);
            }
          }
        }
        else
        {
          this.f = i2;
          if (l2 <= 0L)
          {
            i1 = 0;
            continue;
          }
          i2 = 1000 - (int)((float)l1 / (float)l2 * 1000.0F + 0.5F);
          double d1 = k();
          i1 = i2;
          if (d1 - this.l <= 0.5D) {
            continue;
          }
          this.l = d1;
          float f1 = -1.0F;
          float f2 = (float)(d1 - this.k);
          f2 = (float)l1 / f2;
          if (-1.0F < 0.0F)
          {
            f1 = -1.0F;
            if (f2 > 0.0F) {
              f1 = (float)(l2 - l1) / f2;
            }
          }
          if ((f1 < 0.0F) || (this.d < 0))
          {
            this.d = 0;
            this.g = 0;
          }
          localObject1 = this.m;
          i1 = this.d;
          this.d = (i1 + 1);
          localObject1[i1] = f1;
          if (this.d >= 8) {
            this.d = 0;
          }
          this.g += 1;
          i1 = i2;
          if (this.g <= 8) {
            continue;
          }
          this.g = 8;
          i1 = i2;
          continue;
        }
        i1 += 1;
      }
      finally {}
    }
  }
  
  double k()
  {
    return System.currentTimeMillis() / 1000L - 978307200L;
  }
  
  public void run()
  {
    a();
  }
}


/* Location:              C:\adcap\Pad2\jd-gui-windows-1.4.0\classes-dex2jar.jar!\jp\gungho\padEN\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */