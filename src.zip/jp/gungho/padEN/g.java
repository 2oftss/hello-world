package jp.gungho.padEN;

class g
  extends Thread
{
  f a;
  j b;
  AppDelegate c;
  
  g(f paramf)
  {
    this.a = paramf;
    this.c = this.a.n;
  }
  
  g a(j paramj)
  {
    if (paramj != null) {
      this.b = paramj;
    }
    return this;
  }
  
  /* Error */
  public void a()
  {
    // Byte code:
    //   0: aconst_null
    //   1: astore 7
    //   3: aconst_null
    //   4: astore 6
    //   6: aconst_null
    //   7: astore 5
    //   9: aload_0
    //   10: monitorenter
    //   11: aload_0
    //   12: getfield 17	jp/gungho/padEN/g:a	Ljp/gungho/padEN/f;
    //   15: astore 8
    //   17: aload 8
    //   19: aload 8
    //   21: getfield 33	jp/gungho/padEN/f:b	I
    //   24: iconst_1
    //   25: iadd
    //   26: putfield 33	jp/gungho/padEN/f:b	I
    //   29: aload_0
    //   30: monitorexit
    //   31: new 35	java/net/URL
    //   34: dup
    //   35: aload_0
    //   36: getfield 28	jp/gungho/padEN/g:b	Ljp/gungho/padEN/j;
    //   39: getfield 41	jp/gungho/padEN/j:f	Ljava/lang/String;
    //   42: invokespecial 44	java/net/URL:<init>	(Ljava/lang/String;)V
    //   45: astore 8
    //   47: aload_0
    //   48: getfield 28	jp/gungho/padEN/g:b	Ljp/gungho/padEN/j;
    //   51: getfield 41	jp/gungho/padEN/j:f	Ljava/lang/String;
    //   54: ldc 46
    //   56: invokevirtual 52	java/lang/String:startsWith	(Ljava/lang/String;)Z
    //   59: ifeq +150 -> 209
    //   62: aload 8
    //   64: invokevirtual 56	java/net/URL:openConnection	()Ljava/net/URLConnection;
    //   67: checkcast 58	javax/net/ssl/HttpsURLConnection
    //   70: astore 8
    //   72: aload 8
    //   74: astore 5
    //   76: aload 7
    //   78: astore 6
    //   80: aload 5
    //   82: ldc 60
    //   84: invokevirtual 65	java/net/HttpURLConnection:setRequestMethod	(Ljava/lang/String;)V
    //   87: aload 7
    //   89: astore 6
    //   91: aload 5
    //   93: ldc 67
    //   95: aload_0
    //   96: getfield 24	jp/gungho/padEN/g:c	Ljp/gungho/padEN/AppDelegate;
    //   99: invokevirtual 73	jp/gungho/padEN/AppDelegate:getUserAgent	()Ljava/lang/String;
    //   102: invokevirtual 77	java/net/HttpURLConnection:setRequestProperty	(Ljava/lang/String;Ljava/lang/String;)V
    //   105: aload 7
    //   107: astore 6
    //   109: aload 5
    //   111: sipush 20000
    //   114: invokevirtual 81	java/net/HttpURLConnection:setReadTimeout	(I)V
    //   117: aload 7
    //   119: astore 6
    //   121: aload 5
    //   123: sipush 20000
    //   126: invokevirtual 84	java/net/HttpURLConnection:setConnectTimeout	(I)V
    //   129: aload 7
    //   131: astore 6
    //   133: aload 5
    //   135: invokevirtual 87	java/net/HttpURLConnection:connect	()V
    //   138: aload 7
    //   140: astore 6
    //   142: aload 5
    //   144: invokevirtual 91	java/net/HttpURLConnection:getContentLength	()I
    //   147: istore_2
    //   148: aload 7
    //   150: astore 6
    //   152: aload 5
    //   154: invokevirtual 95	java/net/HttpURLConnection:getInputStream	()Ljava/io/InputStream;
    //   157: astore 7
    //   159: aload 7
    //   161: astore 6
    //   163: iload_2
    //   164: newarray <illegal type>
    //   166: astore 8
    //   168: iconst_0
    //   169: istore_1
    //   170: iload_1
    //   171: iload_2
    //   172: if_icmpge +54 -> 226
    //   175: aload 7
    //   177: astore 6
    //   179: aload 7
    //   181: aload 8
    //   183: iload_1
    //   184: iload_2
    //   185: iload_1
    //   186: isub
    //   187: invokevirtual 101	java/io/InputStream:read	([BII)I
    //   190: istore_3
    //   191: iload_3
    //   192: ifgt +3 -> 195
    //   195: iload_1
    //   196: iload_3
    //   197: iadd
    //   198: istore_1
    //   199: goto -29 -> 170
    //   202: astore 5
    //   204: aload_0
    //   205: monitorexit
    //   206: aload 5
    //   208: athrow
    //   209: aload 8
    //   211: invokevirtual 56	java/net/URL:openConnection	()Ljava/net/URLConnection;
    //   214: checkcast 62	java/net/HttpURLConnection
    //   217: astore 8
    //   219: aload 8
    //   221: astore 5
    //   223: goto -147 -> 76
    //   226: aload 8
    //   228: ifnull +282 -> 510
    //   231: iload_2
    //   232: ifle +278 -> 510
    //   235: aload 7
    //   237: astore 6
    //   239: aload 5
    //   241: invokevirtual 104	java/net/HttpURLConnection:getResponseCode	()I
    //   244: istore_1
    //   245: iload_1
    //   246: sipush 200
    //   249: if_icmpne +206 -> 455
    //   252: aload 7
    //   254: astore 6
    //   256: aload_0
    //   257: aload 8
    //   259: invokevirtual 107	jp/gungho/padEN/g:b	([B)Z
    //   262: istore 4
    //   264: aload 7
    //   266: astore 6
    //   268: aload_0
    //   269: monitorenter
    //   270: iload 4
    //   272: ifeq +75 -> 347
    //   275: aload_0
    //   276: getfield 28	jp/gungho/padEN/g:b	Ljp/gungho/padEN/j;
    //   279: iconst_1
    //   280: putfield 110	jp/gungho/padEN/j:c	Z
    //   283: aload_0
    //   284: monitorexit
    //   285: aload 7
    //   287: astore 6
    //   289: aload_0
    //   290: monitorenter
    //   291: aload_0
    //   292: getfield 28	jp/gungho/padEN/g:b	Ljp/gungho/padEN/j;
    //   295: iconst_0
    //   296: putfield 113	jp/gungho/padEN/j:d	Z
    //   299: aload_0
    //   300: monitorexit
    //   301: aload 7
    //   303: ifnull +8 -> 311
    //   306: aload 7
    //   308: invokevirtual 116	java/io/InputStream:close	()V
    //   311: aload 5
    //   313: ifnull +8 -> 321
    //   316: aload 5
    //   318: invokevirtual 119	java/net/HttpURLConnection:disconnect	()V
    //   321: aload_0
    //   322: monitorenter
    //   323: aload_0
    //   324: getfield 17	jp/gungho/padEN/g:a	Ljp/gungho/padEN/f;
    //   327: astore 5
    //   329: aload 5
    //   331: aload 5
    //   333: getfield 33	jp/gungho/padEN/f:b	I
    //   336: iconst_1
    //   337: isub
    //   338: putfield 33	jp/gungho/padEN/f:b	I
    //   341: aload_0
    //   342: monitorexit
    //   343: invokestatic 124	java/lang/System:gc	()V
    //   346: return
    //   347: aload_0
    //   348: getfield 28	jp/gungho/padEN/g:b	Ljp/gungho/padEN/j;
    //   351: iconst_1
    //   352: putfield 127	jp/gungho/padEN/j:e	Z
    //   355: aload_0
    //   356: getfield 28	jp/gungho/padEN/g:b	Ljp/gungho/padEN/j;
    //   359: astore 6
    //   361: aload 6
    //   363: aload 6
    //   365: getfield 130	jp/gungho/padEN/j:j	I
    //   368: iconst_1
    //   369: iadd
    //   370: putfield 130	jp/gungho/padEN/j:j	I
    //   373: goto -90 -> 283
    //   376: astore 8
    //   378: aload_0
    //   379: monitorexit
    //   380: aload 7
    //   382: astore 6
    //   384: aload 8
    //   386: athrow
    //   387: astore 8
    //   389: aload 7
    //   391: astore 6
    //   393: aload 8
    //   395: astore 7
    //   397: aload_0
    //   398: monitorenter
    //   399: aload_0
    //   400: getfield 28	jp/gungho/padEN/g:b	Ljp/gungho/padEN/j;
    //   403: iconst_1
    //   404: putfield 127	jp/gungho/padEN/j:e	Z
    //   407: aload_0
    //   408: getfield 28	jp/gungho/padEN/g:b	Ljp/gungho/padEN/j;
    //   411: iconst_0
    //   412: putfield 113	jp/gungho/padEN/j:d	Z
    //   415: aload_0
    //   416: monitorexit
    //   417: aload 7
    //   419: invokevirtual 133	java/lang/Exception:printStackTrace	()V
    //   422: aload 6
    //   424: ifnull +8 -> 432
    //   427: aload 6
    //   429: invokevirtual 116	java/io/InputStream:close	()V
    //   432: aload 5
    //   434: ifnull -113 -> 321
    //   437: aload 5
    //   439: invokevirtual 119	java/net/HttpURLConnection:disconnect	()V
    //   442: goto -121 -> 321
    //   445: astore 5
    //   447: aload 5
    //   449: invokevirtual 133	java/lang/Exception:printStackTrace	()V
    //   452: goto -131 -> 321
    //   455: iload_1
    //   456: sipush 200
    //   459: if_icmpeq -174 -> 285
    //   462: aload 7
    //   464: astore 6
    //   466: aload 5
    //   468: invokevirtual 136	java/net/HttpURLConnection:getErrorStream	()Ljava/io/InputStream;
    //   471: invokevirtual 116	java/io/InputStream:close	()V
    //   474: goto -189 -> 285
    //   477: astore 8
    //   479: aload 5
    //   481: astore 7
    //   483: aload 8
    //   485: astore 5
    //   487: aload 6
    //   489: ifnull +8 -> 497
    //   492: aload 6
    //   494: invokevirtual 116	java/io/InputStream:close	()V
    //   497: aload 7
    //   499: ifnull +8 -> 507
    //   502: aload 7
    //   504: invokevirtual 119	java/net/HttpURLConnection:disconnect	()V
    //   507: aload 5
    //   509: athrow
    //   510: aload 7
    //   512: astore 6
    //   514: aload_0
    //   515: monitorenter
    //   516: aload_0
    //   517: getfield 28	jp/gungho/padEN/g:b	Ljp/gungho/padEN/j;
    //   520: iconst_1
    //   521: putfield 127	jp/gungho/padEN/j:e	Z
    //   524: aload_0
    //   525: getfield 28	jp/gungho/padEN/g:b	Ljp/gungho/padEN/j;
    //   528: astore 6
    //   530: aload 6
    //   532: aload 6
    //   534: getfield 130	jp/gungho/padEN/j:j	I
    //   537: iconst_1
    //   538: iadd
    //   539: putfield 130	jp/gungho/padEN/j:j	I
    //   542: aload_0
    //   543: monitorexit
    //   544: goto -259 -> 285
    //   547: astore 8
    //   549: aload_0
    //   550: monitorexit
    //   551: aload 7
    //   553: astore 6
    //   555: aload 8
    //   557: athrow
    //   558: astore 8
    //   560: aload_0
    //   561: monitorexit
    //   562: aload 7
    //   564: astore 6
    //   566: aload 8
    //   568: athrow
    //   569: astore 5
    //   571: aload 5
    //   573: invokevirtual 133	java/lang/Exception:printStackTrace	()V
    //   576: goto -255 -> 321
    //   579: astore 7
    //   581: aload_0
    //   582: monitorexit
    //   583: aload 7
    //   585: athrow
    //   586: astore 8
    //   588: aload 5
    //   590: astore 7
    //   592: aload 8
    //   594: astore 5
    //   596: goto -109 -> 487
    //   599: astore 6
    //   601: aload 6
    //   603: invokevirtual 133	java/lang/Exception:printStackTrace	()V
    //   606: goto -99 -> 507
    //   609: astore 5
    //   611: aload_0
    //   612: monitorexit
    //   613: aload 5
    //   615: athrow
    //   616: astore 5
    //   618: aconst_null
    //   619: astore 7
    //   621: goto -134 -> 487
    //   624: astore 7
    //   626: aconst_null
    //   627: astore 6
    //   629: goto -232 -> 397
    //   632: astore 7
    //   634: aconst_null
    //   635: astore 6
    //   637: goto -240 -> 397
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	640	0	this	g
    //   169	291	1	i	int
    //   147	85	2	j	int
    //   190	8	3	k	int
    //   262	9	4	bool	boolean
    //   7	146	5	localObject1	Object
    //   202	5	5	localObject2	Object
    //   221	217	5	localObject3	Object
    //   445	35	5	localException1	Exception
    //   485	23	5	localObject4	Object
    //   569	20	5	localException2	Exception
    //   594	1	5	localObject5	Object
    //   609	5	5	localObject6	Object
    //   616	1	5	localObject7	Object
    //   4	561	6	localObject8	Object
    //   599	3	6	localException3	Exception
    //   627	9	6	localObject9	Object
    //   1	562	7	localObject10	Object
    //   579	5	7	localObject11	Object
    //   590	30	7	localObject12	Object
    //   624	1	7	localException4	Exception
    //   632	1	7	localException5	Exception
    //   15	243	8	localObject13	Object
    //   376	9	8	localObject14	Object
    //   387	7	8	localException6	Exception
    //   477	7	8	localObject15	Object
    //   547	9	8	localObject16	Object
    //   558	9	8	localObject17	Object
    //   586	7	8	localObject18	Object
    // Exception table:
    //   from	to	target	type
    //   11	31	202	finally
    //   204	206	202	finally
    //   275	283	376	finally
    //   283	285	376	finally
    //   347	373	376	finally
    //   378	380	376	finally
    //   163	168	387	java/lang/Exception
    //   179	191	387	java/lang/Exception
    //   239	245	387	java/lang/Exception
    //   256	264	387	java/lang/Exception
    //   268	270	387	java/lang/Exception
    //   289	291	387	java/lang/Exception
    //   384	387	387	java/lang/Exception
    //   466	474	387	java/lang/Exception
    //   514	516	387	java/lang/Exception
    //   555	558	387	java/lang/Exception
    //   566	569	387	java/lang/Exception
    //   427	432	445	java/lang/Exception
    //   437	442	445	java/lang/Exception
    //   80	87	477	finally
    //   91	105	477	finally
    //   109	117	477	finally
    //   121	129	477	finally
    //   133	138	477	finally
    //   142	148	477	finally
    //   152	159	477	finally
    //   163	168	477	finally
    //   179	191	477	finally
    //   239	245	477	finally
    //   256	264	477	finally
    //   268	270	477	finally
    //   289	291	477	finally
    //   384	387	477	finally
    //   466	474	477	finally
    //   514	516	477	finally
    //   555	558	477	finally
    //   566	569	477	finally
    //   516	544	547	finally
    //   549	551	547	finally
    //   291	301	558	finally
    //   560	562	558	finally
    //   306	311	569	java/lang/Exception
    //   316	321	569	java/lang/Exception
    //   399	417	579	finally
    //   581	583	579	finally
    //   397	399	586	finally
    //   417	422	586	finally
    //   583	586	586	finally
    //   492	497	599	java/lang/Exception
    //   502	507	599	java/lang/Exception
    //   323	343	609	finally
    //   611	613	609	finally
    //   31	72	616	finally
    //   209	219	616	finally
    //   31	72	624	java/lang/Exception
    //   209	219	624	java/lang/Exception
    //   80	87	632	java/lang/Exception
    //   91	105	632	java/lang/Exception
    //   109	117	632	java/lang/Exception
    //   121	129	632	java/lang/Exception
    //   133	138	632	java/lang/Exception
    //   142	148	632	java/lang/Exception
    //   152	159	632	java/lang/Exception
  }
  
  public boolean a(byte[] paramArrayOfByte)
  {
    boolean bool = false;
    String str = this.c.getExtFilePath() + this.b.g;
    if (this.c.saveExtDownload(str, paramArrayOfByte, paramArrayOfByte.length))
    {
      double d = this.b.k * 60;
      this.c._izFileSetFileTime(str, d);
      bool = true;
    }
    return bool;
  }
  
  public boolean b(byte[] paramArrayOfByte)
  {
    String str;
    switch (this.b.n)
    {
    default: 
      str = this.c.getExtFilePath() + this.b.g;
      if ((this.b.n == 1) && (this.c.izCrcCalc(paramArrayOfByte, paramArrayOfByte.length) != this.b.l)) {
        return false;
      }
      break;
    case 4: 
    case 5: 
      return a(paramArrayOfByte);
    }
    if (this.c._izFileWrite(str, paramArrayOfByte, paramArrayOfByte.length) != true)
    {
      this.c._izFileDelete(str);
      return false;
    }
    double d = this.b.k * 60;
    this.c._izFileSetFileTime(str, d);
    return true;
  }
  
  public void run()
  {
    a();
  }
}


/* Location:              C:\adcap\Pad2\jd-gui-windows-1.4.0\classes-dex2jar.jar!\jp\gungho\padEN\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */