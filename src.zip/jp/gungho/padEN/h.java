package jp.gungho.padEN;

import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.text.TextUtils.TruncateAt;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.view.inputmethod.InputMethodManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;

public class h
{
  public AppDelegate a;
  LinearLayout b;
  RelativeLayout c;
  a d;
  Button e;
  Button f;
  int g;
  WebView h;
  String i;
  String j;
  String k;
  String l;
  boolean m;
  
  public h(AppDelegate paramAppDelegate)
  {
    this.a = paramAppDelegate;
    this.i = null;
    this.j = null;
    this.k = null;
    this.l = null;
    this.m = false;
    this.b = new LinearLayout(this.a);
    this.b.setBackgroundColor(-16777216);
    this.b.setOrientation(1);
    this.c = new RelativeLayout(this.a);
    this.c.setBackgroundColor(-1);
    this.e = new Button(this.a);
    this.e.setTextSize(14.0F);
    this.e.setText("close");
    this.e.setId(2131165279);
    this.e.setBackgroundColor(-1);
    this.f = new Button(this.a);
    this.f.setTextSize(14.0F);
    this.f.setText("Back");
    this.f.setId(2131165280);
    this.f.setBackgroundColor(-1);
    paramAppDelegate = new RelativeLayout.LayoutParams(-2, -2);
    paramAppDelegate.addRule(11);
    this.e.setTextColor(Color.rgb(0, 122, 255));
    this.e.setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        h.this.b(this);
      }
    });
    RelativeLayout.LayoutParams localLayoutParams = new RelativeLayout.LayoutParams(-2, -2);
    localLayoutParams.addRule(9);
    this.f.setTextColor(Color.rgb(0, 122, 255));
    this.f.setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        h.this.a(this);
      }
    });
    this.c.addView(this.e, paramAppDelegate);
    this.c.addView(this.f, localLayoutParams);
    this.b.addView(this.c, new LinearLayout.LayoutParams(-1, -2));
    this.b.setVisibility(4);
    this.h = new WebView(this.a);
    this.h.setVisibility(8);
    this.h.setWebViewClient(new WebViewClient()
    {
      public void onPageFinished(WebView paramAnonymousWebView, String paramAnonymousString)
      {
        if (h.this.j == null) {
          h.this.j = paramAnonymousString;
        }
        super.onPageFinished(paramAnonymousWebView, paramAnonymousString);
      }
      
      public void onPageStarted(WebView paramAnonymousWebView, String paramAnonymousString, Bitmap paramAnonymousBitmap)
      {
        if (!h.this.m) {
          h.this.l = new String(paramAnonymousString);
        }
      }
      
      public boolean shouldOverrideUrlLoading(WebView paramAnonymousWebView, String paramAnonymousString)
      {
        if ((!paramAnonymousString.startsWith("http:")) && (!paramAnonymousString.startsWith("https:")))
        {
          paramAnonymousWebView.stopLoading();
          if ((h.this.l != null) && (!h.this.l.equals("")))
          {
            paramAnonymousWebView = new Intent("android.intent.action.VIEW", Uri.parse(h.this.l));
            h.this.a.startActivity(paramAnonymousWebView);
            return true;
          }
        }
        else
        {
          h localh = h.this;
          localh.g += 1;
        }
        return super.shouldOverrideUrlLoading(paramAnonymousWebView, paramAnonymousString);
      }
    });
    this.h.setScrollBarStyle(0);
    this.h.setVisibility(0);
    this.h.getSettings().setBuiltInZoomControls(true);
    this.h.getSettings().setJavaScriptEnabled(true);
    int n = (int)(this.a.getResources().getDisplayMetrics().density * 100.0F);
    this.h.setInitialScale(n);
    this.b.addView(this.h, new LinearLayout.LayoutParams(-1, -1));
  }
  
  void a()
  {
    this.i = null;
    this.j = null;
    this.k = null;
  }
  
  void a(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
  {
    paramFloat1 = 20.0F;
    paramFloat2 = paramFloat3 / 640.0F;
    paramFloat2 = 14.0F * (paramFloat4 / 960.0F);
    if (paramFloat2 > 20.0F) {}
    for (;;)
    {
      this.d = new a(this.a);
      this.d.setTextSize(paramFloat1);
      if (this.k != null) {
        this.d.setText(this.k);
      }
      for (;;)
      {
        this.d.setId(2131165281);
        this.d.setBackgroundColor(-1);
        Object localObject = new RelativeLayout.LayoutParams(-1, -2);
        ((RelativeLayout.LayoutParams)localObject).addRule(0, this.e.getId());
        ((RelativeLayout.LayoutParams)localObject).addRule(1, this.f.getId());
        ((RelativeLayout.LayoutParams)localObject).addRule(15);
        this.d.setTextColor(-16777216);
        this.d.setGravity(17);
        this.d.setSingleLine();
        this.d.setEllipsize(TextUtils.TruncateAt.END);
        this.c.addView(this.d, (ViewGroup.LayoutParams)localObject);
        this.e.setTextSize(paramFloat1);
        this.e.setGravity(17);
        this.f.setTextSize(paramFloat1);
        this.f.setGravity(17);
        localObject = new LinearLayout.LayoutParams(-1, -1);
        ((LinearLayout.LayoutParams)localObject).setMargins(0, 1, 0, 0);
        this.h.setLayoutParams((ViewGroup.LayoutParams)localObject);
        this.h.loadUrl(this.i);
        this.h.clearCache(false);
        return;
        this.d.setText("");
      }
      paramFloat1 = paramFloat2;
    }
  }
  
  void a(View.OnClickListener paramOnClickListener)
  {
    this.g -= 1;
    if ((this.g < 0) || (this.l.equals(this.i)) || (this.l.equals(this.j)) || (this.j == null))
    {
      b(paramOnClickListener);
      return;
    }
    if (this.h.canGoBack())
    {
      this.h.goBack();
      return;
    }
    e();
  }
  
  void a(String paramString1, String paramString2)
  {
    try
    {
      if (this.h != null)
      {
        this.h.clearHistory();
        this.h.clearView();
      }
      this.k = new String(paramString2.getBytes("UTF8"), "UTF8");
      this.i = new String(paramString1);
      this.g = 0;
      return;
    }
    catch (Exception paramString1)
    {
      paramString1.printStackTrace();
    }
  }
  
  void b(View.OnClickListener paramOnClickListener)
  {
    e();
  }
  
  boolean b()
  {
    return this.i != null;
  }
  
  void c()
  {
    a();
    e();
    System.gc();
  }
  
  void d()
  {
    this.b.bringToFront();
    this.b.setVisibility(0);
    this.b.requestFocus();
  }
  
  void e()
  {
    ((InputMethodManager)this.a.getSystemService("input_method")).hideSoftInputFromWindow(this.h.getWindowToken(), 2);
    this.b.setVisibility(8);
    this.c.removeView(this.d);
    this.d = null;
    if ((!this.a.getNavibar()) && (this.a._izDevGetBuild_SDK_INT() >= 19)) {
      this.a.setupMainWindowDisplayMode();
    }
    this.i = null;
    this.k = null;
    this.j = null;
  }
}


/* Location:              C:\adcap\Pad2\jd-gui-windows-1.4.0\classes-dex2jar.jar!\jp\gungho\padEN\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */