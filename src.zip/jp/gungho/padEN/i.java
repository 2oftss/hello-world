package jp.gungho.padEN;

import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.graphics.Color;
import android.text.InputFilter;
import android.text.InputFilter.LengthFilter;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.TextView;
import java.lang.reflect.Field;

public class i
{
  public AppDelegate a;
  LinearLayout b;
  RelativeLayout c;
  TextView d;
  TextView e;
  EditText f;
  TextView g;
  Button h;
  Button i;
  boolean j;
  boolean k;
  String l;
  String m;
  String n;
  String o;
  
  public i(AppDelegate paramAppDelegate)
  {
    this.a = paramAppDelegate;
    this.k = false;
    this.j = false;
    this.l = null;
    this.m = null;
    this.n = null;
    this.o = null;
    this.b = new LinearLayout(this.a);
    this.b.setBackgroundColor(-16777216);
    this.b.setOrientation(1);
    this.c = new RelativeLayout(this.a);
    this.c.setBackgroundColor(-1);
    this.i = new Button(this.a);
    this.i.setTextSize(14.0F);
    this.i.setText("Cancel");
    this.i.setId(2131165280);
    this.i.setBackgroundColor(-1);
    this.i.setTextColor(Color.rgb(0, 122, 255));
    this.i.setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        i.this.b(this);
      }
    });
    paramAppDelegate = new RelativeLayout.LayoutParams(-2, -2);
    this.c.addView(this.i, paramAppDelegate);
    this.g = new TextView(this.a);
    this.g.setTextSize(14.0F);
    this.g.setText("Write Mail");
    this.g.setId(2131165281);
    this.g.setBackgroundColor(-1);
    paramAppDelegate = new RelativeLayout.LayoutParams(-2, -2);
    paramAppDelegate.addRule(13);
    this.g.setTextColor(-16777216);
    this.c.addView(this.g, paramAppDelegate);
    this.h = new Button(this.a);
    this.h.setTextSize(14.0F);
    this.h.setText("　Done　");
    this.h.setId(2131165279);
    this.h.setBackgroundColor(-1);
    paramAppDelegate = new RelativeLayout.LayoutParams(-2, -2);
    paramAppDelegate.addRule(11);
    this.h.setTextColor(Color.rgb(0, 122, 255));
    this.h.setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        i.this.a(this);
      }
    });
    this.c.addView(this.h, paramAppDelegate);
    this.b.addView(this.c, new LinearLayout.LayoutParams(-1, -2));
    this.b.setVisibility(4);
    this.e = new TextView(this.a);
    this.e.setTextSize(14.0F);
    this.e.setText("");
    this.e.setHint("");
    this.e.setBackgroundColor(-1);
    this.e.setTextColor(-16777216);
    this.b.addView(this.e, new LinearLayout.LayoutParams(-1, -2));
    this.d = new TextView(this.a);
    this.d.setTextSize(14.0F);
    this.d.setText("");
    this.d.setBackgroundColor(-1);
    this.d.setTextColor(-16777216);
    this.d.setHintTextColor(Color.parseColor("#88000000"));
    this.b.addView(this.d, new LinearLayout.LayoutParams(-1, -2));
    this.f = new EditText(this.a);
    this.f.setTextSize(14.0F);
    this.f.setText("");
    this.f.setBackgroundColor(-1);
    try
    {
      paramAppDelegate = TextView.class.getDeclaredField("mCursorDrawableRes");
      paramAppDelegate.setAccessible(true);
      paramAppDelegate.set(this.f, Integer.valueOf(2131099778));
      this.f.setTextColor(-16777216);
      this.f.setFilters(new InputFilter[] { new InputFilter.LengthFilter(256) });
      this.b.addView(this.f, new LinearLayout.LayoutParams(-1, -1));
      return;
    }
    catch (Exception paramAppDelegate)
    {
      for (;;)
      {
        paramAppDelegate.printStackTrace();
      }
    }
  }
  
  void a()
  {
    this.k = true;
    this.j = false;
    this.l = null;
    this.m = null;
    this.n = null;
    this.o = null;
  }
  
  void a(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
  {
    paramFloat1 = 20.0F;
    paramFloat2 = paramFloat3 / 640.0F;
    paramFloat2 = paramFloat4 / 960.0F * 14.0F;
    if (paramFloat2 > 20.0F) {}
    for (;;)
    {
      this.g.setTextSize(paramFloat1);
      this.h.setTextSize(paramFloat1);
      this.h.setGravity(16);
      this.i.setTextSize(paramFloat1);
      this.e.setTextSize(14.0F);
      this.e.setText(this.l);
      LinearLayout.LayoutParams localLayoutParams = new LinearLayout.LayoutParams(-1, -2);
      localLayoutParams.setMargins(0, 1, 0, 0);
      this.e.setLayoutParams(localLayoutParams);
      this.d.setTextSize(14.0F);
      this.d.setHint(this.m);
      localLayoutParams = new LinearLayout.LayoutParams(-1, -2);
      localLayoutParams.setMargins(0, 1, 0, 0);
      this.d.setLayoutParams(localLayoutParams);
      this.f.setTextSize(14.0F);
      this.f.setText("");
      this.f.setHint("");
      localLayoutParams = new LinearLayout.LayoutParams(-1, -1);
      localLayoutParams.setMargins(0, 1, 0, 0);
      this.f.setLayoutParams(localLayoutParams);
      this.f.setGravity(51);
      return;
      paramFloat1 = paramFloat2;
    }
  }
  
  void a(View.OnClickListener paramOnClickListener)
  {
    paramOnClickListener = this.a.izUtf8GetUcs2Code(this.f.getText().toString());
    paramOnClickListener = this.a.padVulgarityCheck(paramOnClickListener);
    if (paramOnClickListener != null)
    {
      this.f.setText(paramOnClickListener);
      paramOnClickListener = new AlertDialog.Builder(this.a);
      paramOnClickListener.setTitle(this.n);
      paramOnClickListener.setMessage(this.o);
      paramOnClickListener.setPositiveButton("OK", new DialogInterface.OnClickListener()
      {
        public void onClick(DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt) {}
      });
      paramOnClickListener.create();
      paramOnClickListener.show();
      return;
    }
    d();
    this.j = true;
  }
  
  void a(String paramString1, String paramString2, String paramString3, String paramString4)
  {
    try
    {
      this.l = new String(paramString1.getBytes("UTF8"), "UTF8");
      this.m = new String(paramString3.getBytes("UTF8"), "UTF8");
      this.n = new String(paramString2.getBytes("UTF8"), "UTF8");
      this.o = new String(paramString4.getBytes("UTF8"), "UTF8");
      return;
    }
    catch (Exception paramString1)
    {
      paramString1.printStackTrace();
    }
  }
  
  void b()
  {
    a();
    d();
    System.gc();
  }
  
  void b(View.OnClickListener paramOnClickListener)
  {
    d();
  }
  
  void c()
  {
    this.b.setVisibility(0);
    ((InputMethodManager)this.a.getSystemService("input_method")).showSoftInput(this.f, 0);
  }
  
  void d()
  {
    ((InputMethodManager)this.a.getSystemService("input_method")).hideSoftInputFromWindow(this.f.getWindowToken(), 2);
    this.b.setVisibility(8);
    if ((!this.a.getNavibar()) && (this.a._izDevGetBuild_SDK_INT() >= 19)) {
      this.a.setupMainWindowDisplayMode();
    }
    this.l = null;
    this.m = null;
    this.n = null;
    this.o = null;
    this.k = false;
  }
  
  String e()
  {
    if (this.f.getVisibility() == 0) {
      try
      {
        String str = new String(this.f.getText().toString());
        return str;
      }
      catch (Exception localException)
      {
        localException.printStackTrace();
      }
    }
    return null;
  }
  
  boolean f()
  {
    return this.j;
  }
  
  boolean g()
  {
    return this.k;
  }
}


/* Location:              C:\adcap\Pad2\jd-gui-windows-1.4.0\classes-dex2jar.jar!\jp\gungho\padEN\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */