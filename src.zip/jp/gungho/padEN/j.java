package jp.gungho.padEN;

class j
{
  int a;
  boolean b;
  boolean c;
  boolean d;
  boolean e;
  String f;
  String g;
  int h;
  int i;
  int j;
  int k;
  int l;
  int m;
  int n;
  int o;
  double p;
  float q;
  
  j()
  {
    a();
  }
  
  public void a()
  {
    this.a = 0;
    this.b = false;
    this.c = false;
    this.d = false;
    this.e = false;
    this.f = null;
    this.g = null;
    this.h = 0;
    this.i = 0;
    this.k = 0;
    this.l = 0;
    this.m = 0;
    this.o = 0;
  }
}


/* Location:              C:\adcap\Pad2\jd-gui-windows-1.4.0\classes-dex2jar.jar!\jp\gungho\padEN\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */